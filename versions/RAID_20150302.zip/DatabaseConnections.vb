Option Strict On
Option Explicit On

Public NotInheritable Class DatabaseConnections




    Public Function ConnectToDB(ByVal UserName As String, ByVal Password As String) As Integer
        '* If successful, return 0, if error, return -1
        '*
        '* Global Variables Referenced:
        '*       DBCon1
        '*       dbrec1
        '*

        Try
            '
            'Define ADO Objects:
            DBCON2 = New ADODB.Connection
            dbrec2 = New ADODB.Recordset

            'Open The connection to Oracle:

            Dim TNS_INFO As String

            TNS_INFO = "(DESCRIPTION=" & _
                               "(ADDRESS_LIST=" & _
                               "(ADDRESS=(PROTOCOL=TCP)" & _
                               "(HOST=" & DBServer & ")" & _
                               "(PORT=1521)))" & _
                               "(CONNECT_DATA=(SID=" & DBSid & ")" & _
                               "(SERVER=DEDICATED)))"

            DBCON2.Open("Provider=MSDAORA.1;" & _
                               "Data Source=" & TNS_INFO & ";" & _
                               "user id=" & UserName & ";" & _
                               "password=" & Password)


            'Define the recordset objects:
            dbrec2 = New ADODB.Recordset

            'Set Return Code:
            ConnectToDB = 0
            '
        Catch
            ConnectToDB = -1
        End Try

    End Function



    Public Sub DisplayDatabaseConnectionError(ByVal strDB As String)
        MsgBox("Error encountered when connecting to " & strDB & " Database  " & vbCrLf & vbCrLf & Err.Description, , "Database Connection Error")
    End Sub

    Public Function ConnectToAccessDB(ByVal strCompletePathAndFileName As String) As Integer
        '* If successful, return 0, if error, return -1
        '*
        '* Global Variables Referenced:
        '*       DBConAccess
        '*       dbRecAccess
        '*



        Try
            '
            'Define ADO Objects:
            DBCON1 = New ADODB.Connection
            dbrec1 = New ADODB.Recordset


            strConnectStringMDB = "Provider=Microsoft.Jet.OLEDB.4.0;" & _
                          "Data Source=" & strCompletePathAndFileName & ";" & _
                          "User Id=admin;" & _
                          "Password=;"

            'Open The connection to Access:
            DBCON1.Open(strConnectStringMDB)
            'Define the recordset object:
            dbrec1 = New ADODB.Recordset

            'Set Return Code:
            ConnectToAccessDB = 0
            '
        Catch

            ConnectToAccessDB = -1

        End Try

    End Function

    
End Class