﻿Option Explicit On
Option Strict On

Imports System.Reflection.MethodBase    'used to get procedure name for error logging

Module modDatabasePatches

    Dim AvailableDatabasePatches() As String = {"v0.47"}
    Public Sub DisplayAvailableDatabasePatches()
        Dim strText As String = String.Empty

        For Each patch As String In AvailableDatabasePatches
            strText &= patch & vbCrLf
        Next

        MessageBox.Show(strText, "Available Database Patches", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Public Sub ApplyDatabasePatches(ByVal strAppVersion As String)
        If UCase(strAppVersion) = "V0.47" Then
            If Adox_AddColumn_Text("CUST_PALLET", "PLC_USERID", 50, True, False) = True Then
                WriteLog(gcstrINFO, strAppVersion & " Database Patch Applied")
            End If
        End If

        If UCase(strAppVersion) = "V0.60" Then
            If Adox_AddColumn_Text("CUST_PALLET", "BASE_ULID", 50, True, False) = True Then
                WriteLog(gcstrINFO, strAppVersion & " Database Patch Applied - Added CUST_PALLET.BASE_ULID")
            End If
        End If
    End Sub




End Module
