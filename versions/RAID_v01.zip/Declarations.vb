Option Strict On
Option Explicit On
Imports Microsoft.VisualBasic
Imports System.Net

Module Declarations



    Public gstrIniFileName As String
    Public gstrPassIniSection As String

    Public gbNewInboundData As Boolean
    Public gbNewOutboundData As Boolean

    Public gstrSocketPort() As String
    Public ciMaxSocketListeningPorts As Integer = 10

    Public giKeepLogDays As Integer



    'color setting
    Public colorFore As Color
    Public colorBack As Color
    Public cstrLogFilePrefix As String = Application.ProductName & "_"

    'Variables to hold UserName,Password, and Oracle TNS Name:
    Public DBUserName As String
    Public DBPassword As String
    Public DBServer As String
    Public DBSid As String


    'ADO DB Objects:
    Public DBCON1 As ADODB.Connection
    Public dbrec1 As ADODB.Recordset
    Public DBCON2 As ADODB.Connection
    Public dbrec2 As ADODB.Recordset


    Public oDataBaseConnection As DatabaseConnections
    Public gstrDatabaseType As String

    Public IniEntries() As IniType
    Public IniRecordCount As Integer

    'these are for outbound
    Public gstrSetSocketServerIPtoMyIP As String
    Public gstrSocketServerIP As String
    Public gstrSocketServerPort As String
    Public gstrDefaultFolderForXMLFiles As String
    Public gstrXSDFileName As String
    Public gstrLastXMLSent As String


    'xml messaging settings
    Public gstrXML_WCS_ID As String

    Public gstrIPAddressOverrideLocalPC As String

    'timer related
    Public giReplenAutoScanIntervalSeconds As Integer
    Public giPickingAutoScanIntervalSeconds As Integer
    Public giAutoHeartBeatSendIntervalMilliSeconds As Integer

    'unit load creation
    Public giLastULIDUsed As Integer
    Public gstrULIDPrefix As String

    'infeed configuration
    Public gstrFPDSSubsitCharacter As String
    Public FPDSLocations As String()
    Public FPDSLocationsRecordCount As Integer
    Public gstrFPDSLocationsSQL As String

    Public Structure IniType
        Dim SectionName As String
        Dim KeyName As String
        Dim Value As String
    End Structure
    Public ULsOnFPDSRecordCount As Integer
    Public ULsOnFPDS() As ULsOnFPDSType
    Public Structure ULsOnFPDSType
        Dim ULID As String
        Dim LOCATN As String
        Dim UL_STACOD As String
        Dim CTRL_DATE As String
    End Structure

    Public UlsKnownToAsrsOnFPDSRecordCount As Integer
    Public UlsKnownToAsrsOnFPDS() As UlsKnownToAsrsOnFPDSType
    Public Structure UlsKnownToAsrsOnFPDSType
        Dim CUST_ID As String
        Dim CTRL_DATE As String
    End Structure

    Public Sub Ini_Main()

        Dim lpSectionName As String
        Dim oini As ini

        oini = New ini

        IniRecordCount = 0
        ReDim IniEntries(0)

        gstrIniFileName = Application.StartupPath & "\" & Application.ProductName & ".ini"

        'Get Data for the Config Section of the ini file
        lpSectionName = "Config"
        Call iniConfig(oini, gstrIniFileName, lpSectionName)


        'Get Data for the Base Socket Communications of the ini file
        lpSectionName = "SocketCommunication"
        Call iniSocketCommunication(oini, gstrIniFileName, lpSectionName)

        'Get the listeneing port data
        lpSectionName = "SocketListeningPorts"
        Call iniSocketListeningPorts(oini, gstrIniFileName, lpSectionName)

        'Get Data for the LastDblogin of the ini file
        lpSectionName = "LastDBLogin"
        Call iniLastDBLogin(oini, gstrIniFileName, lpSectionName)

        'Get Data for the Infeed of the ini file
        lpSectionName = "Infeed"
        Call iniInfeed(oini, gstrIniFileName, lpSectionName)

    End Sub

    Private Sub AddIniKeyNametoIniArray(ByRef lpSectionName As String, ByRef lpKeyName As String, ByRef strValue As String)
        IniRecordCount += 1
        ReDim Preserve IniEntries(IniRecordCount)
        With IniEntries(IniRecordCount)
            IniEntries(IniRecordCount).SectionName = lpSectionName
            IniEntries(IniRecordCount).KeyName = lpKeyName
            IniEntries(IniRecordCount).Value = strValue
        End With
    End Sub

    Private Sub iniConfig(ByVal oini As ini, ByVal strIniFileName As String, ByVal lpSectionName As String)
        Dim lpKeyName As String
        Dim strValue As String

        On Error GoTo ErrorHandler

        lpKeyName = "DatabaseType"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcstrACCESS, strIniFileName)
        gstrDatabaseType = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        lpKeyName = "KeepLogDays"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "7", strIniFileName)
        giKeepLogDays = CInt(strValue)
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)


        lpKeyName = "DefaultFolderForXMLFiles"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "c:\", strIniFileName)
        gstrDefaultFolderForXMLFiles = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        lpKeyName = "XSDFileName"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcstrNA, strIniFileName)
        gstrXSDFileName = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        lpKeyName = "WCS_ID"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "PBLWCS", strIniFileName)
        gstrXML_WCS_ID = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)


        lpKeyName = "AutoHeartBeatSendIntervalMilliSeconds"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "5000", strIniFileName)
        giAutoHeartBeatSendIntervalMilliSeconds = CInt(strValue)
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)


        Exit Sub

ErrorHandler:

        'Call inisubsiteSectionErrorHandler(Str$(Err.Number) & gcstrCommaSpace & Err.Description & vbCrLf & vbCrLf,
        '    lpKeyname, strinifilename, lpSectionName)

    End Sub
    Private Sub iniSocketCommunication(ByVal oini As ini, ByVal strIniFileName As String, ByVal lpSectionName As String)
        Dim lpKeyName As String
        Dim strValue As String

        On Error GoTo ErrorHandler

        lpKeyName = "IPAddressOverrideLocalPC"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "", strIniFileName)
        gstrIPAddressOverrideLocalPC = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        lpKeyName = "SetSocketServerIPtoMyIP"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "N", strIniFileName)
        gstrSetSocketServerIPtoMyIP = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        lpKeyName = "SocketServerIP"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "155.155.155.155", strIniFileName)
        If gstrSetSocketServerIPtoMyIP = gcstrY Then
            gstrSocketServerIP = GetIPAddress()
        Else
            gstrSocketServerIP = strValue
        End If
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, gstrSocketServerIP)

        lpKeyName = "SocketServerPort"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "13002", strIniFileName)
        gstrSocketServerPort = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        Exit Sub

ErrorHandler:

        'Call inisubsiteSectionErrorHandler(Str$(Err.Number) & gConvert.ToStringCommaSpace & Err.Description & vbCrLf & vbCrLf,
        '    lpKeyname, strinifilename, lpSectionName)

    End Sub
    Private Sub iniSocketListeningPorts(ByVal oini As ini, ByVal strIniFileName As String, ByVal lpSectionName As String)
        Dim lpKeyName As String
        Dim strValue As String

        Dim x As Integer

        On Error GoTo ErrorHandler


        ReDim gstrSocketPort(ciMaxSocketListeningPorts)

        For x = 1 To ciMaxSocketListeningPorts

            lpKeyName = "ListenPort" & x.ToString
            strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "0", strIniFileName)
            gstrSocketPort(x) = strValue

            Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        Next


        Exit Sub

ErrorHandler:

        'Call inisubsiteSectionErrorHandler(Str$(Err.Number) & gConvert.ToStringCommaSpace & Err.Description & vbCrLf & vbCrLf,
        '    lpKeyname, strinifilename, lpSectionName)

    End Sub
    Private Sub iniInfeed(ByVal oini As ini, ByVal strIniFileName As String, ByVal lpSectionName As String)
        Dim lpKeyName As String
        Dim strValue As String
        Dim x As Integer

        Try

            lpKeyName = "FPDSSubsitCharacter"
            strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "0", strIniFileName)
            gstrFPDSSubsitCharacter = strValue
            Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

            lpKeyName = "FPDSLocations"
            strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcstrNA, strIniFileName).ToUpper
            strValue = Strings.Replace(strValue, " ", String.Empty)
            Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

            ReDim FPDSLocations(0)
            FPDSLocationsRecordCount = 0

            If Strings.Len(strValue) > 0 And strValue <> gcstrNA Then
                FPDSLocations = strValue.Split(gcCharComma)
                FPDSLocationsRecordCount = FPDSLocations.GetUpperBound(0) + 1

            End If

            gstrFPDSLocationsSQL = String.Empty
            For x = 1 To FPDSLocationsRecordCount
                If x > 1 Then
                    gstrFPDSLocationsSQL &= gcstrComma
                End If
                gstrFPDSLocationsSQL &= gcstrApos & Trim(FPDSLocations(x - 1)) & gcstrApos   'zero based array

            Next


        Catch

        End Try

    End Sub
    Private Sub iniLastDBLogin(ByVal oini As ini, ByVal strIniFileName As String, ByVal lpSectionName As String)
        Dim lpKeyName As String
        Dim strValue As String

        On Error GoTo ErrorHandler

        lpKeyName = "DBServer"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, vbNullString, strIniFileName)
        DBServer = strValue

        lpKeyName = "DBSid"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "rtcis", strIniFileName)
        DBSid = strValue

        lpKeyName = "DBUser"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, vbNullString, strIniFileName)
        DBUserName = strValue

        Exit Sub

ErrorHandler:

        'Call inisubsiteSectionErrorHandler(Str$(Err.Number) & gConvert.ToStringCommaSpace & Err.Description & vbCrLf & vbCrLf,
        '    lpKeyname, strinifilename, lpSectionName)

    End Sub
    Public Function LogFileName() As String
        Dim strMonth As String
        Dim strDay As String
        Dim charPad As Char

        charPad = Convert.ToChar(gcStrZero)

        strMonth = Month(Now).ToString.PadLeft(2, charPad)
        strDay = Microsoft.VisualBasic.Day(Now).ToString.PadLeft(2, charPad)

        LogFileName = My.Application.Info.DirectoryPath & "\" & cstrLogFilePrefix & Year(Now) & strMonth & strDay & ".log"

    End Function


    Public Function GetIPAddress() As String

      

        If Len(gstrIPAddressOverrideLocalPC) < 3 Then
            'no override
            Return GetLocalIP()
        Else
            Return gstrIPAddressOverrideLocalPC
        End If

    
    End Function
    Function GetLocalIP() As String
        Dim IPList As System.Net.IPHostEntry = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName)
        Dim IpAddress As System.Net.IPAddress
        For Each IPAddress In IPList.AddressList


            'Only return IPv4 routable IPs       
            If (IPAddress.AddressFamily = Sockets.AddressFamily.InterNetwork) AndAlso (Not IsPrivateIP(IPAddress.ToString)) Then


                Return IPAddress.ToString
            End If
        Next
        Return ""
    End Function
    Function IsPrivateIP(ByVal CheckIP As String) As Boolean
        Dim Quad1, Quad2 As Integer
        Quad1 = CInt(CheckIP.Substring(0, CheckIP.IndexOf(".")))
        Quad2 = CInt(CheckIP.Substring(CheckIP.IndexOf(".") + 1).Substring(0, CheckIP.IndexOf(".")))
        Select Case Quad1
            Case 10
                Return True
            Case 172
                If Quad2 >= 16 And Quad2 <= 31 Then Return True
            Case 192
                If Quad2 = 168 Then Return True
        End Select
        Return False
    End Function


    Public Sub WriteLog(ByVal strAction As String, ByVal strText As String)
        Dim FilePath As String

        Try
            FilePath = LogFileName()
            My.Computer.FileSystem.WriteAllText(FilePath, Now & " | " & strAction.PadRight(15, Convert.ToChar(" ")) & strText.Trim & vbCrLf, True)
        Catch

        Finally

        End Try
    End Sub
    Public Sub WriteLogAckResponse(ByVal strAction As String, ByVal strText As String)
        Dim FilePath As String
        Dim charPad As Char
        Dim strMonth As String
        Dim strDay As String

        Try


            charPad = Convert.ToChar(gcStrZero)

            strMonth = Month(Now).ToString.PadLeft(2, charPad)
            strDay = Microsoft.VisualBasic.Day(Now).ToString.PadLeft(2, charPad)

            FilePath = My.Application.Info.DirectoryPath & "\" & "ACK" & cstrLogFilePrefix & Year(Now) & strMonth & strDay & ".log"

            My.Computer.FileSystem.WriteAllText(FilePath, Now & " | " & strAction.PadRight(15, Convert.ToChar(" ")) & strText.Trim & vbCrLf, True)
        Catch

        Finally

        End Try
    End Sub

    Public Function Mod10CheckDigit(ByVal Barcode As String) As Integer
        Dim i As Integer
        Dim TotalOdd As Integer
        Dim TotalEven As Integer
        Dim Total As Integer
        Dim strTotalRightOneChar As String
        Dim iRightCharVal As Integer

        Try
            Barcode = Trim(Barcode)
            'get odd numbers
            For i = 1 To Len(Barcode) Step 2
                TotalOdd += Convert.ToInt16(Mid(Barcode, i, 1))
            Next i
            TotalOdd *= 3

            'get even numbers
            i = 0
            For i = 2 To Len(Barcode) Step 2
                TotalEven += Convert.ToInt16(Mid(Barcode, i, 1))
            Next i

            Total = TotalOdd + TotalEven
            strTotalRightOneChar = Right(Convert.ToString(Total), 1)


            iRightCharVal = Convert.ToInt16(IIf(strTotalRightOneChar = gcStrZero, "10", strTotalRightOneChar))


            Mod10CheckDigit = 10 - iRightCharVal

        Catch

            'dont set anything
        End Try
    End Function



    Public Function RandomNumber(ByVal low As Integer, ByVal high As Integer) As Integer
        Static RandomNumGen As New System.Random
        Return RandomNumGen.Next(low, high)
    End Function

    Public Sub ProcessGridDeSelectAll(ByVal oGrid As AxMSFlexGridLib.AxMSFlexGrid)
        Dim x As Integer

        oGrid.Col = 0

        For x = 1 To oGrid.Rows - 1
            oGrid.Row = x
            oGrid.set_TextMatrix(x, 0, vbNullString)
        Next
    End Sub

    Public Sub ProcessGridSelectAll(ByVal oGrid As AxMSFlexGridLib.AxMSFlexGrid)
        Dim x As Integer

        oGrid.Col = 0

        'only select non errored rows visible rows
        For x = 1 To oGrid.Rows - 1
            oGrid.Row = x
            If oGrid.get_RowHeight(x) > 0 Then
                If Len(oGrid.get_TextMatrix(x, 1)) > 0 Then

                    'only allow selection of items that are not in the pick step
                    '  If Convert.ToInt32(oGrid.get_TextMatrix(x, 2)) <> giPickStepNumber Then
                    oGrid.set_TextMatrix(x, 0, gcstrY)
                    'End If
                End If
            End If
        Next
    End Sub

    Public Sub ProcessGridMouseDown(ByVal oGrid As AxMSFlexGridLib.AxMSFlexGrid, ByVal iMouseButton As Integer)
        Dim strText As String
        Dim iRowSel As Integer
        Dim iColSel As Integer
        Dim strNewValue As String
        Dim strCurValue As String
        Dim strColHeader As String
        Dim iMsgResult As Integer


        iRowSel = oGrid.MouseRow
        iColSel = oGrid.MouseCol

        'first row is header row
        If iRowSel = 0 Then Exit Sub

        strText = Trim(oGrid.get_TextMatrix(iRowSel, iColSel))

        If iMouseButton = 2 Then

            'Save to clipboard 
            Clipboard.SetDataObject(strText)

        ElseIf iColSel = 0 Then

            'toggle the selection flag
            If oGrid.get_TextMatrix(iRowSel, 0) = gcstrY Then
                oGrid.set_TextMatrix(iRowSel, 0, vbNullString)
            Else
                oGrid.set_TextMatrix(iRowSel, 0, gcstrY)
            End If

        Else

            'Get the column header
            strColHeader = oGrid.get_TextMatrix(0, iColSel)

            'allow user to temporarily override status
            strCurValue = oGrid.get_TextMatrix(iRowSel, iColSel)

            strNewValue = InputBox(strColHeader & " Value:", "Override Value", strCurValue)
            If Strings.Len(strNewValue) = 0 Then
                iMsgResult = MessageBox.Show("Keep the Original Value of " & strCurValue & "?", "Null Value Detected", MessageBoxButtons.YesNo)

                If iMsgResult = Windows.Forms.DialogResult.Yes Then
                    oGrid.set_TextMatrix(iRowSel, iColSel, strCurValue)
                Else
                    oGrid.set_TextMatrix(iRowSel, iColSel, strNewValue)
                End If

            Else
                oGrid.set_TextMatrix(iRowSel, iColSel, strNewValue)
            End If

            'End If

        End If
    End Sub
End Module