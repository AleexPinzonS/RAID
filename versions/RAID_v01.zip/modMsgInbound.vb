Option Explicit On
Option Strict On

Imports System
Imports System.IO
Imports System.Xml
Imports System.Xml.Schema


Module modMsgInbound
    '$PROBHIDE NOT_READ
    Public Structure Confirm_Heartbeat

        Dim HDR_SESSIONKEY As String
        Dim HDR_MESSAGEID As String
        Dim HDR_TIMESTAMP As String

        Dim strText As String
    End Structure

    Public Structure MessageHeader
        Dim WCS_ID As String
        Dim Message_Id As String
        Dim TimeStamp As String
    End Structure

    Public Structure Set_Carton_Status

        Dim HDR_SESSIONKEY As String
        Dim HDR_MESSAGEID As String
        Dim HDR_TIMESTAMP As String

        Dim strSSCC As String
        Dim strStatus As String

    End Structure

    Public Structure Msg8

        Dim HDR_SESSIONKEY As String
        Dim HDR_MESSAGEID As String
        Dim HDR_TIMESTAMP As String

        Dim strMsgTyp As String
        Dim strCust_ID As String
        Dim strBrand_Code As String
        Dim strBrand_Desc As String
        Dim strCode_Date As String
        Dim strPallet_Type As String
        Dim strHold_Status As String
        Dim strActiv_Input_Location As String
        Dim strUser_Id As String
        Dim strCtrl_Date As String

    End Structure
 

    Public NotInheritable Class XMLReadIt

        Public Sub ParseXML(ByVal strData As String)
            Dim XMLContext As New XmlParserContext(Nothing, Nothing, String.Empty, XmlSpace.None, System.Text.Encoding.UTF8)
            Dim reader As New XmlTextReader(strData, XmlNodeType.Document, XMLContext)



            Try

                gbNewInboundData = True

                If Len(gstrXSDFileName) > 0 And gstrXSDFileName <> "NA" Then
                    'verify the XML against a XSD

                    'Create the XmlSchemaSet class.
                    Dim sc As XmlSchemaSet = New XmlSchemaSet()

                    ' Add the schema to the collection.
                    sc.Add(Nothing, My.Application.Info.DirectoryPath & "\" & gstrXSDFileName)

                    ' Set the validation settings.
                    Dim settings As XmlReaderSettings = New XmlReaderSettings()
                    settings.ValidationType = ValidationType.Schema
                    settings.Schemas = sc
                    AddHandler settings.ValidationEventHandler, AddressOf ValidationCallBack

                    ' Create the XmlReader object.
                    Dim parsereader As System.Xml.XmlReader = System.Xml.XmlReader.Create(New System.IO.StringReader(strData), settings)

                    ' Parse the file. 
                    'this just validatres if the XML matches the XSD specification
                    'errors trigger the ValidationCallBack routine
                    While parsereader.Read()
                    End While
                End If

                'use the XML Text Reader

                'Disable whitespace so that you don't have to read over whitespaces
                reader.WhitespaceHandling = WhitespaceHandling.None

                'read the xml declaration and advance to root tag
                reader.Read()


                If Strings.InStr(reader.Name.ToUpper, "XML") > 0 Then
                    'if this line is the xml declaration then need to read another line
                    'read the root tag
                    reader.Read()
                    'reader.ReadString()
                Else
                    'no xml declaration, we have the root tag
                End If

                'determine what the xml is and route to its routine
                Select Case reader.Name.ToUpper

                    Case "Confirm_HeartBeat".ToUpper
                        Dim structXML As Confirm_Heartbeat
                        structXML = ReadXML_Confirm_Heartbeat(reader)

                        WriteLog(gcstrProcessed, "Heartbeat Message = " & structXML.strText)

                    Case "A8".ToUpper
                        Dim structXML As Msg8
                        structXML = ReadXML_Msg8(reader)

                        WriteLog(gcstrProcessed, "Msg8 for ULID " & structXML.strCust_ID)



                End Select

            Catch

                WriteLog(gcstrError, "ParseXML: " & Err.Description)
            Finally

            End Try
        End Sub

        ' Display any validation errors.
        Private Shared Sub ValidationCallBack(ByVal sender As Object, ByVal e As ValidationEventArgs)
            WriteLog(gcstrError, "InvalidXML: " & e.Message)
        End Sub

    End Class

    Public Function ReadXML_Confirm_Heartbeat(ByVal myReader As XmlReader) As Confirm_Heartbeat

        Dim strElement As String = vbNullString
        Dim strTextString As String = String.Empty
        Dim struct As New Confirm_Heartbeat
        Dim structXMLMessageHeader As MessageHeader

        'Load the Loop
        While Not myReader.EOF

            'Go to the next line
            myReader.Read()

            strElement = myReader.Name.ToUpper

            If myReader.IsStartElement = True Then

                If myReader.Depth > 1 Then
                    strTextString = myReader.ReadString
                End If

                Select Case strElement

                    Case gcstrMessageHeaderElement

                        structXMLMessageHeader = ReadXML_MessageHeader(myReader)

                        struct.HDR_SESSIONKEY = structXMLMessageHeader.WCS_ID
                        struct.HDR_MESSAGEID = structXMLMessageHeader.Message_Id
                        struct.HDR_TIMESTAMP = structXMLMessageHeader.TimeStamp

                    Case "TEXT"
                        struct.strText = strTextString


                End Select
            End If



        End While

        Return struct

    End Function

    Public Function ReadXML_MessageHeader(ByVal myReader As XmlReader) As MessageHeader
        Dim strElement As String
        Dim strTextString As String
        Dim struct As New MessageHeader



        'Load the Loop
        While Not myReader.EOF
            'Go to the next line
            myReader.Read()


            strTextString = myReader.ReadString
            strElement = myReader.Name.ToUpper


            ' If Len(strElement) = 0 And Len(strTextString) > 0 Then
            ' strElement = "WCS_ID"
            'End If

            Select Case strElement

                Case "WCS_ID"
                    struct.WCS_ID = strTextString
                Case "MESSAGE_ID"
                    struct.Message_Id = strTextString
                Case "TIMESTAMP"
                    struct.TimeStamp = strTextString


                    Exit While

            End Select

        End While

        Return struct
    End Function

    Private Sub WriteLog(ByVal strAction As String, ByVal strText As String)
        Dim FilePath As String

        Try
            FilePath = LogFileName()
            My.Computer.FileSystem.WriteAllText(FilePath, Now & " | " & strAction.PadRight(15, Convert.ToChar(" ")) & strText.Trim & vbCrLf, True)
        Catch

        Finally

        End Try
    End Sub

    Public Function ReadXML_Msg8(ByVal myReader As XmlReader) As Msg8

        Dim strElement As String = vbNullString
        Dim strTextString As String = String.Empty
        Dim struct As New Msg8
        Dim iPreviousReadNestDepth As Integer = 99    'force high
        Dim structXMLMessageHeader As MessageHeader

        'Load the Loop
        While Not myReader.EOF

            'Go to the next line
            myReader.Read()

            'if the xml depth is less than the previous read, then back at a element without data
            'if a ReadString would be executed  things get hosed up, so avoid that via following check

            strElement = myReader.Name.ToUpper

            If myReader.IsStartElement = True Then
                If myReader.Depth > 1 And myReader.Depth >= iPreviousReadNestDepth Then
                    strTextString = myReader.ReadString
                End If


                Select Case strElement

                    Case "ULID"
                        struct.strCust_ID = strTextString

                    Case "BRAND_CODE"
                        struct.strBrand_Code = strTextString

                    Case "BRAND_DESCRIPTION"
                        struct.strBrand_Desc = strTextString

                    Case "CODE_DATE"
                        struct.strCode_Date = strTextString

                    Case "PALLET_TYPE"
                        struct.strPallet_Type = strTextString

                    Case "UL_HOLD_STATUS_CODE"
                        struct.strHold_Status = strTextString

                    Case gcstrMessageHeaderElement

                        structXMLMessageHeader = ReadXML_MessageHeader(myReader)

                        struct.HDR_SESSIONKEY = structXMLMessageHeader.WCS_ID
                        struct.HDR_MESSAGEID = structXMLMessageHeader.Message_Id
                        struct.HDR_TIMESTAMP = structXMLMessageHeader.TimeStamp


                End Select


            End If

            iPreviousReadNestDepth = myReader.Depth


        End While

        Return struct

    End Function


End Module
