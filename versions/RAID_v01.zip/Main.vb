Option Explicit On
Option Strict Off
Imports Microsoft.VisualBasic
Imports System.Reflection.MethodBase    'used to get procedure name for error logging



Public Class Main

    Public SocketServer As AsynchronousSocketListener
    Public SecondSocketServer As AsynchronousSocketListener
    Const bBypassDB As Boolean = False
    Public dbConStatus As Integer
    Public dbConStatusAccess As Integer
    Public piTabSelected As Integer
    Public bToggle As Boolean
    Public pstrPLNumb As String
    Public PromptForUserConfirmation As String = True
    Public SendHeartbeatAutomatically As Boolean = False

    Private Sub Main_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        SocketServer.CloseSockets()
        SecondSocketServer.CloseSockets()
    End Sub



    Private Sub Main_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        'Ensure that the user doesn't mistakenly close 

        Dim iMsgResult As DialogResult
        iMsgResult = (MessageBox.Show("Are you sure you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2))
        If iMsgResult = Windows.Forms.DialogResult.Yes Then
            e.Cancel = False
            SaveLastXMLSent()
            End
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub SaveLastXMLSent()
        'save the Last XML Sent at form closing to use in the XML editor form

        Dim myStream As New System.IO.StreamWriter(My.Application.Info.DirectoryPath & "\" & gcstrLastXMLSentFileName, True)
        myStream.Write(gstrLastXMLSent)
        myStream.Close()
    End Sub

    Private Sub Main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Startup()
    End Sub
    Private Sub Startup()
        Dim x As Integer
        Dim strVersion As String
        Dim strSocket As String

        'Set the variables for color
        colorFore = System.Drawing.Color.Black
        colorBack = System.Drawing.Color.White

        strVersion = "v" & System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).FileMajorPart & "." & System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).FileMinorPart

        Me.Text = Application.ProductName & Space(1) & strVersion & Space(2) & "(ASRS Emulator)"

        PositionFormatStartup()

        WriteLog("Startup ", vbNullString)

        'use the configuration settings
        Ini_Main()

        'fix the tab page colors - issue with settign this on the page properties always revert to white  arrghh
        TabPage1.BackColor = Color.FromKnownColor(KnownColor.Control)
        TabPage2.BackColor = Color.FromKnownColor(KnownColor.Control)
        TabPage3.BackColor = Color.FromKnownColor(KnownColor.Control)
        TabPage4.BackColor = Color.FromKnownColor(KnownColor.Control)
        TabPage5.BackColor = Color.FromKnownColor(KnownColor.Control)

        'set initial state of various buttons
        btnInfeedAutoScanOff.BackColor = Color.Red
        btnCartonAutoScanOff.BackColor = Color.Red

        'Present User Form to Login into DATABASE
        Dim formLogin As New frmLoginDB
        formLogin.ShowDialog()
        ConnectToDatabases()

        'start socket listener(s)

        For x = 1 To gstrSocketPort.GetUpperBound(0)
            'should always be 1

            strSocket = gstrSocketPort(x)

            If IsNumeric(strSocket) Then
                If CInt(strSocket) > 0 Then
                    SocketServer = New AsynchronousSocketListener(gstrSocketPort(x))
                End If

            End If
        Next


        'Write the version and settings to the log file
        WriteLog("START", Strings.StrDup(60, "-"))
        WriteLog("Version ", String.Format("Version {0}", My.Application.Info.Version.ToString))
        WriteLog("MyIP ", GetLocalIP)
        For x = 1 To IniRecordCount
            WriteLog("Setting", IniEntries(x).KeyName & "=" & IniEntries(x).Value)
        Next

        ToolStripStatusLblConnections.Text = "Host Connection:" & Space(1) & gstrSocketServerIP & Space(2) & "Port: " & gstrSocketServerPort

        'Display the first tabs data
        piTabSelected = 1
        GetandDisplayInfeedData()

        RefreshLog()
    End Sub

    Private Sub RefreshLog()
        'display the contents of today's log file to the main screen
        Dim FilePath As String

        Try
            'log file 1
            FilePath = LogFileName()

            txtLog.Text = My.Computer.FileSystem.ReadAllText(FilePath)

            txtLog.SelectionStart = txtLog.TextLength
            txtLog.ScrollToCaret()


            butRefresh.BackColor = Color.FromKnownColor(KnownColor.Control)
            ToolStripStatusLabelRefresh.Visible = False

            'highlight errors
            SearchLog("ERROR ", Color.Red) 'with the space to avoid finding ini parameters!


        Catch
            ' move on

        End Try
    End Sub
    Private Sub SearchLog(ByVal SearchText As String, ByVal HighLightColor As Color)
        Try
            Dim textEnd As Integer = txtLog.TextLength
            Dim index As Integer = 0
            Dim lastIndex As Integer = txtLog.Text.LastIndexOf(SearchText)

            While index < lastIndex
                txtLog.Find(SearchText, index, textEnd, RichTextBoxFinds.None)
                txtLog.SelectionBackColor = HighLightColor
                txtLog.SelectionColor = Color.White
                index = txtLog.Text.IndexOf(SearchText, index) + 1
            End While
        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try

    End Sub


    Private Sub MainToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MainToolStripMenuItem.Click
        'ensure sync with ini file
        Call Ini_Main()
        gstrPassIniSection = "Config"

        Dim formConfig As New frmConfig
        formConfig.ShowDialog()
    End Sub

    Private Sub WriteLog(ByVal strAction As String, ByVal strText As String)
        Dim FilePath As String

        Try
            If Len(strText) = 0 Then Exit Sub

            FilePath = LogFileName()
            My.Computer.FileSystem.WriteAllText(FilePath, Now & " | " & strAction.PadRight(15, Convert.ToChar(" ")) & strText.Trim & vbCrLf, True)
        Catch

        Finally
            tmrRefreshLog.Enabled = True
        End Try
    End Sub


    Private Sub DeleteOldLogFiles()
        Dim DaysOld As Integer
        Dim DeleteTime As DateTime

        Try

            DaysOld = giKeepLogDays
            DeleteTime = Today.AddDays(DaysOld * -1)

            For Each fullFilePath As String In My.Computer.FileSystem.GetFiles(My.Application.Info.DirectoryPath)
                If Strings.Right(fullFilePath.ToUpper, 4) = ".LOG" Then
                    If Strings.InStr(fullFilePath, cstrLogFilePrefix) > 1 Then

                        Dim fiFile As New System.IO.FileInfo(fullFilePath)
                        If fiFile.Exists Then
                            If fiFile.LastWriteTime < DeleteTime Then
                                fiFile.Delete()
                            End If

                        End If

                    End If
                End If
                Debug.Print(fullFilePath)
            Next

        Catch ex As Exception
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        Finally
            WriteLog("Purged Logs", "Older than " & DeleteTime)

        End Try
    End Sub

    Private Sub DeleteOldLogsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteOldLogsToolStripMenuItem.Click
        DeleteOldLogFiles()
    End Sub

    Private Sub ConnectToDatabases()

        Dim strDatabase As String = Application.ProductName & ".mdb"

        Try

            'Make the database connection with the above parameters
            If bBypassDB = False Then

                oDataBaseConnection = New DatabaseConnections

                strDatabase = Application.ProductName & ".mdb"
                'DBCON2
                dbConStatus = oDataBaseConnection.ConnectToAccessDB( _
                                         Application.StartupPath & "\" & strDatabase)
                If dbConStatus = -1 Then
                    Call oDataBaseConnection.DisplayDatabaseConnectionError( _
                       strDatabase)
                End If



                'oracle  dbcon2
                strDatabase = "RTCIS"
                dbConStatus = oDataBaseConnection.ConnectToDB(DBUserName, DBPassword)

                If dbConStatus = -1 Then
                    Call oDataBaseConnection.DisplayDatabaseConnectionError( _
                        strDatabase)
                End If


            End If
        Catch
            SubError("ConnectToDatabase (" & strDatabase & ") ", Err.Description)
        End Try

    End Sub

    Private Sub SubError(ByVal strSub As String, ByVal strErr As String)
        MessageBox.Show("Error in SubRoutine: " & strSub & _
                   vbCrLf & vbCrLf & strErr, "Program Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub


    Private Sub SendXMLFromFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SendXMLFromFileToolStripMenuItem.Click
        Dim strFilename As String
        Dim strXML As String

        Try
            strFilename = InputBox("Enter Complete Filepath and Filename including Extension:", "Specify File", gstrDefaultFolderForXMLFiles)

            If Len(strFilename) > 0 Then
                strXML = My.Computer.FileSystem.ReadAllText(strFilename)

                WriteLog("Sending", strFilename)

                SendRequest(strXML)
            End If
        Catch
            MessageBox.Show("Error with XML" & vbCrLf & vbCrLf & Err.Description, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try

    End Sub

    Private Sub tmrRefreshLog_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrRefreshLog.Tick
        Try
            If gbNewInboundData = True Then
                butRefresh.BackColor = Color.Green
                ToolStripStatusLabelRefresh.Visible = True

                If chkAutoRefresh.Checked = True Then
                    tmrBlink.Enabled = True
                    RefreshLog()
                End If

            End If

            If gbNewOutboundData = True Then
                If chkAutoRefresh.Checked = True Then
                    RefreshLog()
                End If

            End If

            gbNewInboundData = False
            gbNewOutboundData = False


        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Err.Description)
        Finally

        End Try
    End Sub

    Private Sub SendHeartbeatToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SendHeartbeatToolStripMenuItem.Click
        SendHeartbeat()
    End Sub
    Private Sub SendHeartbeat()
        WriteLog("Send", "Heartbeat")
        Dim strTest As String = CreateXMLHeartbeat(Now.ToString)

        SendRequest(strTest)
        gbNewOutboundData = True
    End Sub

    Private Sub ServiceStepsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ServiceStepsToolStripMenuItem.Click
        'close all popup windows

        Dim objType As Type() = Reflection.Assembly.GetExecutingAssembly.GetTypes()
        Dim x As Integer
        Try

            For x = Application.OpenForms.Count - 1 To 0 Step -1

                'MessageBox.Show(Application.OpenForms.Item(x).Name)
                If Application.OpenForms.Item(x).Name = "frmStepDetail" Or _
                  Application.OpenForms.Item(x).Name = "frmXMLEditor" Then

                    Application.OpenForms.Item(x).Close()
                End If
            Next

        Catch ex As Exception
            MessageBox.Show("Error Closing Popups" & ex.Message)
        Finally

        End Try

    End Sub


    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        Dim formAbout As New AboutBox1

        AboutBox1.ShowDialog()
    End Sub

    Private Sub TabPage1_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabPage1.Enter
        If piTabSelected <> 1 Then

        End If

        piTabSelected = 1

    End Sub


    Private Sub butRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butRefresh.Click
        RefreshLog()
    End Sub

    Private Sub tmrBlink_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrBlink.Tick
        Static iCount As Integer

        iCount += 1
        If iCount > 6 Then

            tmrBlink.Enabled = False
            ToolStripStatusLabelRefresh.Visible = False
            ToolStripStatusLabelRefresh.BackColor = Color.FromKnownColor(KnownColor.Control)
            iCount = 0
        Else
            ToolStripStatusLabelRefresh.Visible = True
            Select Case iCount
                Case 1, 3, 5
                    ToolStripStatusLabelRefresh.BackColor = Color.Green
                Case Else
                    ToolStripStatusLabelRefresh.BackColor = Color.FromKnownColor(KnownColor.Control)

            End Select

        End If

    End Sub

    Private Sub SocketCommunicationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SocketCommunicationToolStripMenuItem.Click

        'ensure sync with ini file
        Call Ini_Main()
        gstrPassIniSection = "SocketCommunication"
        Dim formConfig As New frmConfig
        formConfig.ShowDialog()

    End Sub

    Public Function DisplayNextUnitLoadID() As String
        Dim strULIDSuffix As String
        Dim strULIDNoCheckDigit As String
        Dim strCheckDigit As String
        Dim pad As Char

        Try
            strULIDSuffix = Convert.ToString(giLastULIDUsed + 1)

            pad = "0"c
            strULIDSuffix = strULIDSuffix.PadLeft(9, pad)

            strULIDNoCheckDigit = gstrULIDPrefix & strULIDSuffix


            strCheckDigit = Convert.ToString(Mod10CheckDigit(strULIDNoCheckDigit))
            DisplayNextUnitLoadID = strULIDNoCheckDigit & strCheckDigit
        Catch
            DisplayNextUnitLoadID = String.Empty
        End Try

    End Function



    Private Sub flxGrid1_MouseDownEvent(ByVal sender As Object, ByVal e As AxMSFlexGridLib.DMSFlexGridEvents_MouseDownEvent) Handles flxGrid1.MouseDownEvent
        ProcessGridMouseDown(CType(sender, AxMSFlexGrid), e.button)
    End Sub



    Private Sub TabPage1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage1.Click
        '    FillSSCCServicesGrouped()
    End Sub


    Private Sub TabPage3_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabPage3.Enter
        If piTabSelected <> 1 Then

        End If

        piTabSelected = 3


    End Sub





    Private Sub XMLEditorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles XMLEditorToolStripMenuItem.Click
        Dim formXMLEditor As New frmXMLEditor
        formXMLEditor.Show()
    End Sub

    Private Sub PositionFormatStartup()
        Dim iOffset As Integer
        Dim workingRectangle As System.Drawing.Rectangle = Screen.PrimaryScreen.WorkingArea

        ' Set the size of the form slightly less than size of rectangle.  the working area does not include the task bar
        Me.Size = New System.Drawing.Size(workingRectangle.Width - iOffset, workingRectangle.Height - iOffset)

        ' Set the location so the entire form is visible.
        Me.Location = New System.Drawing.Point(iOffset, iOffset)

    End Sub






    Private Sub flxGrid4_MouseDownEvent(ByVal sender As Object, ByVal e As AxMSFlexGridLib.DMSFlexGridEvents_MouseDownEvent) Handles flxGrid4.MouseDownEvent
        ProcessGridMouseDown(CType(sender, AxMSFlexGrid), e.button)
    End Sub


    Private Sub SearchLogToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchLogToolStripMenuItem.Click
        Dim UserSearchText As String = String.Empty

        UserSearchText = InputBox("Search Text:", "Specify Case Sensitive Search Text", String.Empty)

        If Len(UserSearchText) > 0 Then
            SearchLog(UserSearchText, Color.Green)
        End If

    End Sub


    Private Sub PromptForUserConfirmationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PromptForUserConfirmationToolStripMenuItem.Click
        If PromptForUserConfirmationToolStripMenuItem.Checked = True Then
            PromptForUserConfirmation = True

        Else
            PromptForUserConfirmation = False


        End If
    End Sub

    Private Sub SendHeartbeatAutomaticallyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SendHeartbeatAutomaticallyToolStripMenuItem.Click
        If SendHeartbeatAutomaticallyToolStripMenuItem.Checked = True Then
            SendHeartbeatAutomatically = True
            ToolStripStatusLabelHeartBeatOn.Visible = True
            SendHeartbeat()

        Else
            SendHeartbeatAutomatically = False
            ToolStripStatusLabelHeartBeatOn.Visible = False


        End If
    End Sub

    Private Sub tmrHeartbeat_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrHeartbeat.Tick
        tmrHeartbeat.Interval = giAutoHeartBeatSendIntervalMilliSeconds

        If SendHeartbeatAutomatically = True Then
            SendHeartbeat()
        End If
    End Sub


    Private Sub SocketListeningPortsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SocketListeningPortsToolStripMenuItem.Click
        'ensure sync with ini file
        Call Ini_Main()
        gstrPassIniSection = "SocketListeningPorts"
        Dim formConfig As New frmConfig
        formConfig.ShowDialog()
    End Sub


    Private Sub cmdRefreshInfeed_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRefreshInfeed.Click
        GetandDisplayInfeedData()

        FillUlsKnownToAsrsOnFPDS()    'dave move later
    End Sub

    Private Sub GetandDisplayInfeedData()
        FillUlsOnFPDS()
        DisplayULsOnFPDS()
    End Sub

    Private Sub FillUlsOnFPDS()
        Dim strSQL As String
        Try
            ''dave hardcode!
            strSQL = "select ULID, LOCATN, NVL(UL_STACOD,0) UL_STACOD, CTRL_DATE " & _
                "from UNITLD " & _
                "where " & _
                 "locatn in (" & gstrFPDSLocationsSQL & ") " & _
                "and subsit='" & gstrFPDSSubsitCharacter & "' " & _
                "order by CTRL_DATE desc"

            ' Open the Recordset using the select string:
            dbrec2.Open(strSQL, DBCON2)

            ULsOnFPDSRecordCount = 0
            ReDim ULsOnFPDS(0)

            Do Until dbrec2.EOF

                ' Populate the Location array by parsing through the recordset one row at a time:
                ULsOnFPDSRecordCount += 1
                ReDim Preserve ULsOnFPDS(ULsOnFPDSRecordCount)

                With ULsOnFPDS(ULsOnFPDSRecordCount)

                    .ULID = Convert.ToString(dbrec2.Fields("ULID").Value)
                    .LOCATN = Convert.ToString(dbrec2.Fields("LOCATN").Value)
                    .UL_STACOD = Convert.ToString(dbrec2.Fields("UL_STACOD").Value)
                    .CTRL_DATE = Convert.ToString(dbrec2.Fields("CTRL_DATE").Value)

                End With

                dbrec2.MoveNext()

            Loop

            'Close Recordset:
            dbrec2.Close()

        Catch ex As Exception
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        FillUlsOnFPDS()
    End Sub

    Private Sub InfeedToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InfeedToolStripMenuItem.Click
        'ensure sync with ini file
        Call Ini_Main()
        gstrPassIniSection = "Infeed"
        Dim formConfig As New frmConfig
        formConfig.ShowDialog()
    End Sub

    Private Sub DisplayULsOnFPDS()
        Dim x As Integer
        Dim y As Integer

        Try
            flxGrid1.Rows = 1
            flxGrid1.Rows = 2
            flxGrid1.Cols = 6
            flxGrid1.Row = 0
            For y = 1 To flxGrid1.Cols
                flxGrid1.Col = y - 1
                flxGrid1.Text = vbNullString

                Select Case flxGrid1.Col

                    Case 0
                        flxGrid1.set_ColWidth(flxGrid1.Col, 500)

                    Case 1, 2
                        flxGrid1.set_ColWidth(flxGrid1.Col, 2000)

                    Case Else
                        flxGrid1.set_ColWidth(flxGrid1.Col, 1000)

                End Select

            Next

            flxGrid1.Redraw = False

            ' Initialize the Grid by defining the headers:
            flxGrid1.Rows = 2
            flxGrid1.Row = 0

            flxGrid1.Col = 0
            flxGrid1.Text = "Sel"
            flxGrid1.Col = 1
            flxGrid1.Text = "Ctrl_Date"
            flxGrid1.Col = 2
            flxGrid1.Text = "ULID"
            flxGrid1.Col = 3
            flxGrid1.Text = "Location"
            flxGrid1.Col = 4
            flxGrid1.Text = "UL_Stacod"
            flxGrid1.Col = 5
            flxGrid1.Text = "Bypass Code"



            For x = 1 To ULsOnFPDSRecordCount

                flxGrid1.Row += 1

                flxGrid1.Col = 1
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & ULsOnFPDS(x).CTRL_DATE

                flxGrid1.Col = 2
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & ULsOnFPDS(x).ULID

                flxGrid1.Col = 3
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & ULsOnFPDS(x).LOCATN

                flxGrid1.Col = 4
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & ULsOnFPDS(x).UL_STACOD

                flxGrid1.Col = 5
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & gcStrZero        'Always defauly bypass code to 0

             

                flxGrid1.Rows += 1

            Next


            'remove last blank row
            flxGrid1.Rows -= 1
            flxGrid1.Col = 0
            ' flxGrid1.Sort = flexSortNumericAscending
        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
            RefreshLog()
        Finally

            flxGrid1.Redraw = True

        End Try
    End Sub

    Private Sub cmdInfeedSelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdInfeedSelectAll.Click
        ProcessGridSelectAll(flxGrid1)
    End Sub

    Private Sub cmdInfeedDeSelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdInfeedDeSelectAll.Click
        ProcessGridDeSelectAll(flxGrid1)
    End Sub

    Private Sub SendMsg5forUL(ByVal strULID As String, ByVal strUL_STACOD As String, ByVal strBYPCOD As String)

        Dim strXML As String
        Dim bUpdateSuccess As Boolean

        Try

            strXML = CreateXML_Msg5(strULID, strUL_STACOD, strBYPCOD)
            SendRequest(strXML)

            gbNewOutboundData = True   'set the log refresh flag

            bUpdateSuccess = InsertULInto_CUST_PALLET(strULID)

            If bUpdateSuccess = False Then
                '   WriteLog("Error", "ASRS Database Failed UL Insertion for " & strULID)
            End If

        Catch
        End Try
    End Sub

    Private Sub InfeedAdvance(ByVal bUserPrompt As Boolean)
        Dim x As Integer
        Dim shMsgbox As MsgBoxResult
        Dim strULID As String

        Try

            If bUserPrompt = True Then

                shMsgbox = MsgBox("Send Msg5 for Selected ULID(s) ?", MsgBoxStyle.YesNo, "Confirm Infeed Processing")

                If shMsgbox = MsgBoxResult.No Then
                    Exit Sub
                End If

            End If

            For x = 1 To flxGrid1.Rows - 1

                If flxGrid1.get_TextMatrix(x, 0) = gcstrY Then
                    'convert ULID 19 to ULID if necessary
                    strULID = flxGrid1.get_TextMatrix(x, 2)
                    If strULID.Length = 19 Then

                        strULID &= Convert.ToString(Mod10CheckDigit(strULID))
                    End If

                    'do the advance
                    SendMsg5forUL(strULID, flxGrid1.get_TextMatrix(x, 4), flxGrid1.get_TextMatrix(x, 5))
                End If
            Next

        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        Finally

            If bUserPrompt = True Then
                GetandDisplayInfeedData()
            End If

        End Try
    End Sub

    Private Sub cmdInfeedAdvance_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdInfeedAdvance.Click
        InfeedAdvance(True)
    End Sub

    Public Function InsertULInto_CUST_PALLET(ByVal strULID As String) As Boolean

        Dim strSql As String

        Try

            strSql = "INSERT INTO CUST_PALLET " & _
            "(CUST_ID) values ('" & _
            strULID & "')"

            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If

            InsertULInto_CUST_PALLET = True

        Catch
            InsertULInto_CUST_PALLET = False
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & strULID & Space(1) & Err.Description)

        End Try

    End Function

    Private Sub FillUlsKnownToAsrsOnFPDS()
        Dim strSQL As String
        Try
            ''dave hardcode!
            strSQL = "select CUST_ID, CTRL_DATE " & _
                "from CUST_PALLET " & _
                "where " & _
                 "retro_loc is null " & _
                "order by CTRL_DATE desc"

            ' Open the Recordset using the select string:
            dbrec1.Open(strSQL, DBCON1)

            UlsKnownToAsrsOnFPDSRecordCount = 0
            ReDim UlsKnownToAsrsOnFPDS(0)

            Do Until dbrec1.EOF

                ' Populate the Location array by parsing through the recordset one row at a time:
                UlsKnownToAsrsOnFPDSRecordCount += 1
                ReDim Preserve UlsKnownToAsrsOnFPDS(UlsKnownToAsrsOnFPDSRecordCount)

                With UlsKnownToAsrsOnFPDS(UlsKnownToAsrsOnFPDSRecordCount)

                    .CUST_ID = Convert.ToString(dbrec1.Fields("CUST_ID").Value)
                    .CTRL_DATE = Convert.ToString(dbrec1.Fields("CTRL_DATE").Value)

                End With

                dbrec1.MoveNext()

            Loop

            'Close Recordset:
            dbrec1.Close()

        Catch ex As Exception
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try

    End Sub
End Class
