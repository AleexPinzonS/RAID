Option Explicit On
Option Strict On

Imports System.Net.Sockets
Imports System.Net
Imports System.Text
Imports System.XML
Imports System.IO
Module modMsgOutbound

    Public Sub SendRequest(ByVal strText As String)

        Dim tcpClient As New System.Net.Sockets.TcpClient
        Dim dtSendTimeStamp As Date
        Dim charPad As Char = Convert.ToChar(gcStrZero)
        Dim strBars As String

        Try

            gbNewOutboundData = True
            WriteLog("Sending", "..." & vbCrLf & strText)

            '"Localhost" string is used when the client and the listener are on the same computer.
            'If the listener is listening at a computer that is different from the client, provide the host name of the computer
            'where the listener is listening.
            tcpClient.Connect(IPAddress.Parse(gstrSocketServerIP), CInt(gstrSocketServerPort))


            ' Uses the GetStream public method to return the NetworkStream.

            Dim netStream As NetworkStream = tcpClient.GetStream()
            If netStream.CanWrite Then
                Dim sendBytes As [Byte]() = Encoding.UTF8.GetBytes(strText & vbCr & vbLf & vbLf)
                netStream.Write(sendBytes, 0, sendBytes.Length)
                dtSendTimeStamp = Now
            Else
                WriteLog("NetStream_Write", "You cannot write data to this stream.")

                tcpClient.Close()
                ' Closing the tcpClient instance does not close the network stream.
                netStream.Close()
                Return
            End If
            If netStream.CanRead Then

                ' Reads the NetworkStream into a byte buffer.
                Dim bytes(tcpClient.ReceiveBufferSize) As Byte
                ' Read can return anything from 0 to numBytesToRead. 
                ' This method blocks until at least one byte is read.
                netStream.Read(bytes, 0, CInt(tcpClient.ReceiveBufferSize))

                ' Returns the data received from the host to the console.
                Dim returndata As String = Encoding.ASCII.GetString(bytes)

                If (Now - dtSendTimeStamp).Seconds > 0 Then
                    strBars = "".PadRight(10, "X"c)
                Else
                    strBars = "".PadRight(CInt((Now - dtSendTimeStamp).Milliseconds / 100), "X"c)
                    ' Dim i As Integer = CInt((Now - dtSendTimeStamp).Milliseconds / 100)

                End If
              
                WriteLog("Response", ProcessAckNakResponse(returndata) & "|" & (Now - dtSendTimeStamp).Seconds.ToString & "." & (Now - dtSendTimeStamp).Milliseconds.ToString.PadLeft(3, charPad))
                WriteLogAckResponse(strBars, (Now - dtSendTimeStamp).Seconds.ToString & "." & (Now - dtSendTimeStamp).Milliseconds.ToString.PadLeft(3, charPad))

            Else
                WriteLog("NetStream_Read", "You cannot read data on this stream.")
                tcpClient.Close()
                ' Closing the tcpClient instance does not close the network stream.
                netStream.Close()
                Return
            End If

            ' Uses the Close public method to close the network stream and socket.
            tcpClient.Close()

            gstrLastXMLSent = strText

        Catch
            gbNewInboundData = True
            WriteLog(gcstrError, "No Response to Send - Is remote application started/reachable?")
        End Try
    End Sub

   
    Public Function ProcessAckNakResponse(ByVal strResponse As String) As String
        If Strings.Left(strResponse, 1) = "A" Then
            ProcessAckNakResponse = "A"
        Else
            ProcessAckNakResponse = "N"
        End If
    End Function
    Public Function CreateXMLHeartbeat(ByVal strText As String) As String
        Dim memory_stream As New MemoryStream
        Dim xml_text_writer As New XmlTextWriter(memory_stream, System.Text.Encoding.UTF8)
        Dim strTestXMl As String

        ' Use indentation to make the result look nice.
        xml_text_writer.Formatting = Formatting.Indented
        xml_text_writer.Indentation = 4

        ' Write the XML declaration.
        xml_text_writer.WriteStartDocument(True)

        ' Start the Message Detail node.
        xml_text_writer.WriteStartElement("Check_HeartBeat".ToUpper)

        'Message Header
        CreateXMLMessageHeader(memory_stream, xml_text_writer)


        xml_text_writer.WriteStartElement("Check_HeartBeat_Data".ToUpper)

        ' Write the Heartbeat text
        xml_text_writer.WriteStartElement("TEXT".ToUpper)
        xml_text_writer.WriteString(strText)
        xml_text_writer.WriteEndElement()

        ' End the CheckHeartBeatData
        xml_text_writer.WriteEndElement()

        ' End the Check_HeartBeat
        xml_text_writer.WriteEndElement()


        ' End the document.
        xml_text_writer.WriteEndDocument()
        xml_text_writer.Flush()

        ' Use a StreamReader to display the result.
        Dim stream_reader As New StreamReader(memory_stream)

        memory_stream.Seek(0, SeekOrigin.Begin)
        strTestXMl = stream_reader.ReadToEnd()

        ' Close the XmlTextWriter.
        xml_text_writer.Close()

        CreateXMLHeartbeat = strTestXMl
    End Function


    Public Function CreateXML_Msg5(ByVal strULID As String, ByVal strUL_STACOD As String, ByVal strBYPCOD As String) As String
        Dim memory_stream As New MemoryStream
        Dim xml_text_writer As New XmlTextWriter(memory_stream, System.Text.Encoding.UTF8)
        Dim strTextXMl As String

        ' Use indentation to make the result look nice.
        xml_text_writer.Formatting = Formatting.Indented
        xml_text_writer.Indentation = 4

        ' Write the XML declaration.
        xml_text_writer.WriteStartDocument(True)

        'Root Tag
        xml_text_writer.WriteStartElement("MSG5".ToUpper)

        'Message Header
        CreateXMLMessageHeader(memory_stream, xml_text_writer)


        'Segment tag
        xml_text_writer.WriteStartElement("ULDATA".ToUpper)

        ' Write the lineitems
        xml_text_writer.WriteStartElement("ULID")
        xml_text_writer.WriteString(strULID)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("UL_STACOD")
        xml_text_writer.WriteString(strUL_STACOD)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("ULWEIGHT")
        xml_text_writer.WriteString(gcStrZero)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("BYPCOD")
        xml_text_writer.WriteString(strBYPCOD)
        xml_text_writer.WriteEndElement()


        ' End outer element
        xml_text_writer.WriteEndElement()

        'End outer element
        xml_text_writer.WriteEndElement()


        ' End the document.
        xml_text_writer.WriteEndDocument()
        xml_text_writer.Flush()

        ' Use a StreamReader to display the result.
        Dim stream_reader As New StreamReader(memory_stream)

        memory_stream.Seek(0, SeekOrigin.Begin)
        strTextXMl = stream_reader.ReadToEnd()

        ' Close the XmlTextWriter.
        xml_text_writer.Close()

        CreateXML_Msg5 = strTextXMl
    End Function
    Public Sub CreateXMLMessageHeader(ByVal memory_stream As MemoryStream, ByVal xml_text_writer As XmlTextWriter)

        '<MessageHeader>
        '<WCS_ID>RTCIS</WCS_ID>    
        '<Message_Id>00000000000000000001</Message_Id>    
        ' <Timestamp>20091007 15:00:00</Timestamp>    
        '</MessageHeader> 


        'Root Tag
        xml_text_writer.WriteStartElement(gcstrMessageHeaderElement)

        ' Write the lineitems
        xml_text_writer.WriteStartElement("WCS_ID")
        xml_text_writer.WriteString(gstrXML_WCS_ID)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("MESSAGE_ID")
        xml_text_writer.WriteString(Format(Now, "yyyyMMddHHmmssffff"))
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("TIMESTAMP")
        'xml_text_writer.WriteString(Format(Now, "s"))   XML format
        xml_text_writer.WriteString(Format(Now, "yyyyMMddHHmmss")) 'oracle format
        xml_text_writer.WriteEndElement()

        ' End root element
        xml_text_writer.WriteEndElement()


    End Sub

End Module
