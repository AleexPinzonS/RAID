Option Strict On
Option Explicit On
Imports System.Windows.Forms
Imports VB = Microsoft.VisualBasic

Public Class frmConfig

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub DisplayIniSection()
        'Dim flxGrid1 As Object
        Dim x As Integer
        Dim y As Integer
        flxGrid1.Rows = 2
        flxGrid1.Cols = 2
        flxGrid1.Row = 1


        For y = 1 To flxGrid1.Cols
            flxGrid1.Col = y - 1
            flxGrid1.set_ColAlignment(flxGrid1.Col, Convert.ToInt16(MSFlexGridLib.AlignmentSettings.flexAlignLeftCenter))

            'ensure row 1 is blank
            flxGrid1.Text = vbNullString
            Select Case flxGrid1.Col
                Case 0
                    flxGrid1.set_ColWidth(flxGrid1.Col, 2500)

                Case 1
                    flxGrid1.set_ColWidth(flxGrid1.Col, 8500)
            End Select
        Next


        ' Initialize the Grid by defining the headers:
        flxGrid1.Row = 0
        flxGrid1.Col = 0
        flxGrid1.Text = "Parameter"
        flxGrid1.Col = 1
        flxGrid1.Text = "Setting"

        For x = 1 To IniRecordCount
            If IniEntries(x).SectionName = gstrPassIniSection Then
                flxGrid1.Row += 1
                flxGrid1.Col = 0
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & IniEntries(x).KeyName
                flxGrid1.Col = 1
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & IniEntries(x).Value

                flxGrid1.Rows += 1
            End If
        Next

        'get rid of last blank grid row
        flxGrid1.Rows -= 1

    End Sub

    Private Sub ModifyEntry(ByRef iRowSel As Integer, ByRef bAddingEntry As Boolean)


        Dim strValue As String
        Dim strParameter As String
        Dim strInputBox As String
        Dim lpSectionName As String
        Dim oini As ini

        oini = New ini

        If iRowSel = 0 Then Exit Sub


        strParameter = Trim(flxGrid1.get_TextMatrix(iRowSel, 0))
        strValue = Trim(flxGrid1.get_TextMatrix(iRowSel, 1))

        strInputBox = InputBox(vbNullString, strParameter, strValue)

        'Did user change value
        If strInputBox <> strValue And Len(strInputBox) > 0 Then
            'save to grid
            flxGrid1.set_TextMatrix(iRowSel, 1, Trim(strInputBox))

            'write to ini
            lpSectionName = gstrPassIniSection
            Call oini.ProfileSaveItem(lpSectionName, strParameter, UCase(strInputBox), gstrIniFileName)

            'reread ini file data to get changes
            Call Ini_Main()

        ElseIf Len(strInputBox) = 0 Then
            'should really fix this ...but oh well
            'save to grid
            Dim iMsgResult As DialogResult
            iMsgResult = (MessageBox.Show("Are you sure you want to clear the values?", "Set Null Value?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2))
            If iMsgResult = Windows.Forms.DialogResult.Yes Then


                flxGrid1.set_TextMatrix(iRowSel, 1, Trim(strInputBox))

                'write to ini
                lpSectionName = gstrPassIniSection
                Call oini.ProfileSaveItem(lpSectionName, strParameter, UCase(strInputBox), gstrIniFileName)

                'reread ini file data to get changes
                Call Ini_Main()
            End If

            Else
                If bAddingEntry = True Then
                    'User canceled, need to get rid of grid row

                    flxGrid1.Rows -= 1
                End If
            End If

Error_Renamed:


    End Sub
    Private Sub frmConfig_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Me.Text = gstrPassIniSection
        Call DisplayIniSection()
    End Sub

    Private Sub flxGrid1_MouseDownEvent1(ByVal sender As Object, ByVal e As AxMSFlexGridLib.DMSFlexGridEvents_MouseDownEvent) Handles flxGrid1.MouseDownEvent
        Dim iRowSel As Integer


        iRowSel = flxGrid1.RowSel

        'can't select header of last blank line
        If iRowSel = 0 Then Exit Sub

        Call ModifyEntry(iRowSel, False)

    End Sub


    Private Sub flxGrid1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles flxGrid1.Enter

    End Sub
End Class
