Option Explicit On
Option Strict On

Imports System.Net.Sockets
Imports System.Net
Imports System.Text
Imports System.XML
Imports System.IO
Module modMsgOutbound

    Public Sub SendRequest(ByVal strText As String)

        Dim tcpClient As New System.Net.Sockets.TcpClient
        Dim dtSendTimeStamp As Date
        Dim charPad As Char = Convert.ToChar(gcStrZero)
        Dim strBars As String

        Try

            gbNewOutboundData = True
            WriteLog("Sending", "..." & vbCrLf & strText)

            '"Localhost" string is used when the client and the listener are on the same computer.
            'If the listener is listening at a computer that is different from the client, provide the host name of the computer
            'where the listener is listening.
            tcpClient.Connect(IPAddress.Parse(gstrSocketServerIP), CInt(gstrSocketServerPort))


            ' Uses the GetStream public method to return the NetworkStream.

            Dim netStream As NetworkStream = tcpClient.GetStream()
            If netStream.CanWrite Then
                Dim sendBytes As [Byte]() = Encoding.UTF8.GetBytes(strText & vbCr & vbLf & vbLf)
                netStream.Write(sendBytes, 0, sendBytes.Length)
                dtSendTimeStamp = Now
            Else
                WriteLog("NetStream_Write", "You cannot write data to this stream.")

                tcpClient.Close()
                ' Closing the tcpClient instance does not close the network stream.
                netStream.Close()
                Return
            End If
            If netStream.CanRead Then

                ' Reads the NetworkStream into a byte buffer.
                Dim bytes(tcpClient.ReceiveBufferSize) As Byte
                ' Read can return anything from 0 to numBytesToRead. 
                ' This method blocks until at least one byte is read.
                netStream.Read(bytes, 0, CInt(tcpClient.ReceiveBufferSize))

                ' Returns the data received from the host to the console.
                Dim returndata As String = Encoding.ASCII.GetString(bytes)

                If (Now - dtSendTimeStamp).Seconds > 0 Then
                    strBars = "".PadRight(10, "X"c)
                Else
                    strBars = "".PadRight(CInt((Now - dtSendTimeStamp).Milliseconds / 100), "X"c)
                    ' Dim i As Integer = CInt((Now - dtSendTimeStamp).Milliseconds / 100)

                End If
              
                WriteLog("Response", ProcessAckNakResponse(returndata) & "|" & (Now - dtSendTimeStamp).Seconds.ToString & "." & (Now - dtSendTimeStamp).Milliseconds.ToString.PadLeft(3, charPad))
                WriteLogAckResponse(strBars, (Now - dtSendTimeStamp).Seconds.ToString & "." & (Now - dtSendTimeStamp).Milliseconds.ToString.PadLeft(3, charPad))

            Else
                WriteLog("NetStream_Read", "You cannot read data on this stream.")
                tcpClient.Close()
                ' Closing the tcpClient instance does not close the network stream.
                netStream.Close()
                Return
            End If

            ' Uses the Close public method to close the network stream and socket.
            tcpClient.Close()

            gstrLastXMLSent = strText

        Catch
            gbNewInboundData = True
            WriteLog(gcstrError, "No Response to Send - Is remote application started/reachable?")
        End Try
    End Sub

   
    Public Function ProcessAckNakResponse(ByVal strResponse As String) As String
        If Strings.Left(strResponse, 1) = "A" Then
            ProcessAckNakResponse = "A"
        Else
            ProcessAckNakResponse = "N"
        End If
    End Function
    Public Function CreateXMLHeartbeat(ByVal strText As String) As String
        Dim memory_stream As New MemoryStream
        Dim xml_text_writer As New XmlTextWriter(memory_stream, System.Text.Encoding.UTF8)
        Dim strTestXMl As String

        ' Use indentation to make the result look nice.
        xml_text_writer.Formatting = Formatting.Indented
        xml_text_writer.Indentation = 4

        ' Write the XML declaration.
        xml_text_writer.WriteStartDocument(True)

        ' Start the Message Detail node.
        xml_text_writer.WriteStartElement("Check_HeartBeat".ToUpper)

        'Message Header
        CreateXMLMessageHeader(memory_stream, xml_text_writer)


        xml_text_writer.WriteStartElement("Check_HeartBeat_Data".ToUpper)

        ' Write the Heartbeat text
        xml_text_writer.WriteStartElement("TEXT".ToUpper)
        xml_text_writer.WriteString(strText)
        xml_text_writer.WriteEndElement()

        ' End the CheckHeartBeatData
        xml_text_writer.WriteEndElement()

        ' End the Check_HeartBeat
        xml_text_writer.WriteEndElement()


        ' End the document.
        xml_text_writer.WriteEndDocument()
        xml_text_writer.Flush()

        ' Use a StreamReader to display the result.
        Dim stream_reader As New StreamReader(memory_stream)

        memory_stream.Seek(0, SeekOrigin.Begin)
        strTestXMl = stream_reader.ReadToEnd()

        ' Close the XmlTextWriter.
        xml_text_writer.Close()

        CreateXMLHeartbeat = strTestXMl
    End Function


    Public Function CreateXML_Move_Case(ByVal strSSCC As String, ByVal strLocatn As String, ByVal strWH_ID As String) As String
        Dim memory_stream As New MemoryStream
        Dim xml_text_writer As New XmlTextWriter(memory_stream, System.Text.Encoding.UTF8)
        Dim strTextXMl As String

        ' Use indentation to make the result look nice.
        xml_text_writer.Formatting = Formatting.Indented
        xml_text_writer.Indentation = 4

        ' Write the XML declaration.
        xml_text_writer.WriteStartDocument(True)

        'Root Tag
        xml_text_writer.WriteStartElement("Move_Case".ToUpper)

        'Message Header
        CreateXMLMessageHeader(memory_stream, xml_text_writer)


        'Segment tag
        xml_text_writer.WriteStartElement("Case_Data".ToUpper)

        ' Write the lineitems
        xml_text_writer.WriteStartElement("SSCC")
        xml_text_writer.WriteString(strSSCC)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("LOCATION")
        xml_text_writer.WriteString(strLocatn)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("WH_ID")
        xml_text_writer.WriteString(strWH_ID)
        xml_text_writer.WriteEndElement()


        ' End outer element
        xml_text_writer.WriteEndElement()

        'End outer element
        xml_text_writer.WriteEndElement()


        ' End the document.
        xml_text_writer.WriteEndDocument()
        xml_text_writer.Flush()

        ' Use a StreamReader to display the result.
        Dim stream_reader As New StreamReader(memory_stream)

        memory_stream.Seek(0, SeekOrigin.Begin)
        strTextXMl = stream_reader.ReadToEnd()

        ' Close the XmlTextWriter.
        xml_text_writer.Close()

        CreateXML_Move_Case = strTextXMl
    End Function
    Public Sub CreateXMLMessageHeader(ByVal memory_stream As MemoryStream, ByVal xml_text_writer As XmlTextWriter)

        '<MessageHeader>
        '<WCS_ID>RTCIS</WCS_ID>    
        '<Message_Id>00000000000000000001</Message_Id>    
        ' <Timestamp>20091007 15:00:00</Timestamp>    
        '</MessageHeader> 


        'Root Tag
        xml_text_writer.WriteStartElement(gcstrMessageHeaderElement)

        ' Write the lineitems
        xml_text_writer.WriteStartElement("WCS_ID")
        xml_text_writer.WriteString(gstrXML_WCS_ID)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("MESSAGE_ID")
        xml_text_writer.WriteString(Format(Now, "yyyyMMddHHmmssffff"))
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("TIMESTAMP")
        'xml_text_writer.WriteString(Format(Now, "s"))   XML format
        xml_text_writer.WriteString(Format(Now, "yyyyMMddHHmmss")) 'oracle format
        xml_text_writer.WriteEndElement()

        ' End root element
        xml_text_writer.WriteEndElement()


    End Sub

    Public Function CreateXML_Set_Carton_Information(ByVal strSSCC As String, ByVal strStatus As String, ByVal strWeight As String, ByVal strService As String, _
            ByVal strWGTVAL As String, ByVal strWGTVALTYP As String, ByVal strWGTDIFF As String, ByVal strWGTTOL As String) As String
        Dim memory_stream As New MemoryStream
        Dim xml_text_writer As New XmlTextWriter(memory_stream, System.Text.Encoding.UTF8)
        Dim strTextXMl As String

        ' Use indentation to make the result look nice.
        xml_text_writer.Formatting = Formatting.Indented
        xml_text_writer.Indentation = 4

        ' Write the XML declaration.
        xml_text_writer.WriteStartDocument(True)

        'Root Tag
        xml_text_writer.WriteStartElement("Set_Carton_Information".ToUpper)

        'Message Header
        CreateXMLMessageHeader(memory_stream, xml_text_writer)


        'Segment tag
        xml_text_writer.WriteStartElement("Carton_Data".ToUpper)

        ' Write the lineitems

        xml_text_writer.WriteStartElement("SSCC")
        xml_text_writer.WriteString(strSSCC)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("STATUS")
        xml_text_writer.WriteString(strStatus)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("SERVICE")
        xml_text_writer.WriteString(strService)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("LOCATION")
        xml_text_writer.WriteString(String.Empty)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("WH_ID")
        xml_text_writer.WriteString(String.Empty)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("WEIGHT")
        xml_text_writer.WriteString(strWeight)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("WGTVAL")
        xml_text_writer.WriteString(strWGTVAL)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("WGTVALTYP")
        xml_text_writer.WriteString(strWGTVALTYP)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("WGTDIFF")
        xml_text_writer.WriteString(strWGTDIFF)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("WGTTOL")
        xml_text_writer.WriteString(strWGTTOL)
        xml_text_writer.WriteEndElement()

        ' End outer element
        xml_text_writer.WriteEndElement()

        'End outer element
        xml_text_writer.WriteEndElement()


        ' End the document.
        xml_text_writer.WriteEndDocument()
        xml_text_writer.Flush()

        ' Use a StreamReader to display the result.
        Dim stream_reader As New StreamReader(memory_stream)

        memory_stream.Seek(0, SeekOrigin.Begin)
        strTextXMl = stream_reader.ReadToEnd()

        ' Close the XmlTextWriter.
        xml_text_writer.Close()

        CreateXML_Set_Carton_Information = strTextXMl
    End Function
    


    Public Function CreateXML_Pick_Carton_Error(ByVal strSSCC As String, ByVal strError As String, ByVal strStatus As String) As String

        Dim memory_stream As New MemoryStream
        Dim xml_text_writer As New XmlTextWriter(memory_stream, System.Text.Encoding.UTF8)
        Dim strTextXMl As String

        ' Use indentation to make the result look nice.
        xml_text_writer.Formatting = Formatting.Indented
        xml_text_writer.Indentation = 4

        ' Write the XML declaration.
        xml_text_writer.WriteStartDocument(True)

        'Root Tag
        xml_text_writer.WriteStartElement("Pick_Carton_Error".ToUpper)

        'Message Header
        CreateXMLMessageHeader(memory_stream, xml_text_writer)


        'Segment tag
        xml_text_writer.WriteStartElement("Carton_Data".ToUpper)

        ' Write the lineitems
        xml_text_writer.WriteStartElement("SSCC")
        xml_text_writer.WriteString(strSSCC)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("ERROR")
        xml_text_writer.WriteString(strError)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("STATUS")
        xml_text_writer.WriteString(strStatus)
        xml_text_writer.WriteEndElement()

        ' End outer element
        xml_text_writer.WriteEndElement()

        'End outer element
        xml_text_writer.WriteEndElement()


        ' End the document.
        xml_text_writer.WriteEndDocument()
        xml_text_writer.Flush()

        ' Use a StreamReader to display the result.
        Dim stream_reader As New StreamReader(memory_stream)

        memory_stream.Seek(0, SeekOrigin.Begin)
        strTextXMl = stream_reader.ReadToEnd()

        ' Close the XmlTextWriter.
        xml_text_writer.Close()

        CreateXML_Pick_Carton_Error = strTextXMl
    End Function

    Public Function CreateXML_SCANNED_GMC_INFORMATION(ByVal strSSCC As String, ByVal iGrayMarketCount As Integer) As String

        Dim memory_stream As New MemoryStream
        Dim xml_text_writer As New XmlTextWriter(memory_stream, System.Text.Encoding.UTF8)
        Dim strTextXMl As String

        Dim x As Integer
        Dim iRandomNumber As Integer
        Dim iRandomNumber2 As Integer

        ' Use indentation to make the result look nice.
        xml_text_writer.Formatting = Formatting.Indented
        xml_text_writer.Indentation = 4

        ' Write the XML declaration.
        xml_text_writer.WriteStartDocument(True)

        'Root Tag
        xml_text_writer.WriteStartElement("SCANNED_GMC_INFORMATION".ToUpper)

        'Message Header
        CreateXMLMessageHeader(memory_stream, xml_text_writer)


        For x = 1 To iGrayMarketCount


            'Segment tag
            xml_text_writer.WriteStartElement("Carton_Data".ToUpper)

            ' Write the lineitems
            xml_text_writer.WriteStartElement("SSCC")
            xml_text_writer.WriteString(strSSCC)
            xml_text_writer.WriteEndElement()

            xml_text_writer.WriteStartElement("GMC")
            iRandomNumber = RandomNumber(11111, 99999)
            iRandomNumber2 = RandomNumber(11111, 99999)
            xml_text_writer.WriteString(iRandomNumber.ToString & iRandomNumber2.ToString)
            xml_text_writer.WriteEndElement()

            xml_text_writer.WriteStartElement("USR_ID")
            xml_text_writer.WriteString(gstrPickingUser_Id)
            xml_text_writer.WriteEndElement()

            ' End outer element
            xml_text_writer.WriteEndElement()
        Next

        'End outer element
        xml_text_writer.WriteEndElement()


        ' End the document.
        xml_text_writer.WriteEndDocument()
        xml_text_writer.Flush()

        ' Use a StreamReader to display the result.
        Dim stream_reader As New StreamReader(memory_stream)

        memory_stream.Seek(0, SeekOrigin.Begin)
        strTextXMl = stream_reader.ReadToEnd()

        ' Close the XmlTextWriter.
        xml_text_writer.Close()

        CreateXML_SCANNED_GMC_INFORMATION = strTextXMl
    End Function

    Public Function CreateXML_Pick_Item(ByVal strSSCC As String, ByVal strItemCode As String, ByVal strLocation As String, _
    ByVal strWH_ID As String, ByVal strUOM As String, ByVal strQty As String, ByVal strService As String, Optional ByVal strUser_ID As String = "") As String

        'DAVE this needs totally revised
        'HOW:
        'using XML message (Pick_Item) that contains the following information
        '            Movement_Type(Pick)
        'From (Pick Face) 
        'To (Carton SSCC)  
        '            Item()
        '            Quantity(Moved)
        '            UOM(IT)
        'Service (Last Pick)


        Dim memory_stream As New MemoryStream
        Dim xml_text_writer As New XmlTextWriter(memory_stream, System.Text.Encoding.UTF8)
        Dim strTextXMl As String

        ' Use indentation to make the result look nice.
        xml_text_writer.Formatting = Formatting.Indented
        xml_text_writer.Indentation = 4

        ' Write the XML declaration.
        xml_text_writer.WriteStartDocument(True)

        'Root Tag
        xml_text_writer.WriteStartElement("Pick_Item".ToUpper)

        'Message Header
        CreateXMLMessageHeader(memory_stream, xml_text_writer)


        'Segment tag
        xml_text_writer.WriteStartElement("Carton_Data".ToUpper)

        ' Write the lineitems
        xml_text_writer.WriteStartElement("SSCC")
        xml_text_writer.WriteString(strSSCC)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("ITEM")
        xml_text_writer.WriteString(strItemCode)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("LOCATION")
        xml_text_writer.WriteString(strLocation)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("WH_ID")
        xml_text_writer.WriteString(strWH_ID)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("UOM")
        xml_text_writer.WriteString(strUOM)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("PICKED_QTY")
        xml_text_writer.WriteString(strQty)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("SERVICE")
        xml_text_writer.WriteString(strService)
        xml_text_writer.WriteEndElement()

        xml_text_writer.WriteStartElement("USER_ID")
        xml_text_writer.WriteString(strUser_ID)
        xml_text_writer.WriteEndElement()

        ' End outer element
        xml_text_writer.WriteEndElement()

        'End outer element
        xml_text_writer.WriteEndElement()


        ' End the document.
        xml_text_writer.WriteEndDocument()
        xml_text_writer.Flush()

        ' Use a StreamReader to display the result.
        Dim stream_reader As New StreamReader(memory_stream)

        memory_stream.Seek(0, SeekOrigin.Begin)
        strTextXMl = stream_reader.ReadToEnd()

        ' Close the XmlTextWriter.
        xml_text_writer.Close()

        CreateXML_Pick_Item = strTextXMl
    End Function

End Module
