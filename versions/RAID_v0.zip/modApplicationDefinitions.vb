Option Explicit On
Option Strict On

Public Module modApplicationDefinitions
    'basic strings
    Public Const gcstrError As String = "ERROR"
    Public Const gcstrNA As String = "NA"

    Public Const gcstrY As String = "Y"

    Public Const gcstrProcessed As String = "Processed"
    Public Const gcstrUNEXPECTED As String = "UNEXPECTED"
    Public Const gcstrACCESS As String = "ACCESS"
    Public Const gcstrSet_Carton_Status As String = "Set_Carton_Status"
    Public Const gcstrSet_Location_Status As String = "SET_LOCATION_STATUS"
    Public Const gcstrIgnore_Error As String = "IGNORE_ERROR"
    Public Const gcstrMessageHeaderElement As String = "MESSAGE_HEADER"

    Public Const gcstrOracleDateTimeFormat As String = "yyyyMMdd HH:mm:ss"

    Public Const gcstrCartonPathError As String = "E"
    Public Const gcstrCartonPathGood As String = "G"

    Public Const gcStrZero As String = "0"

    'Characters
    Public Const gcCharComma As Char = ","c
    Public Const gcCharZero As Char = "0"c

    Public Const gcstrLastXMLSentFileName As String = "LastXMLSent.txt"

    Public Const gcstrG01 As String = "G01"
    Public Const gcstrG02 As String = "G02"
    Public Const gcstrG03 As String = "G03"
    Public Const gcstrG04 As String = "G04"
    Public Const gcstrG05 As String = "G05"
    Public Const gcstrG06 As String = "G06"
    Public Const gcstrG07 As String = "G07"
    Public Const gcstrG08 As String = "G08"
    Public Const gcstrG09 As String = "G09"
    Public Const gcstrG10 As String = "G10"

    Public Const gcstrE01 As String = "E01"
    Public Const gcstrE02 As String = "E02"
    Public Const gcstrE03 As String = "E03"
    Public Const gcstrE04 As String = "E04"
    Public Const gcstrE05 As String = "E05"
    Public Const gcstrE06 As String = "E06"
    Public Const gcstrE07 As String = "E07"
    Public Const gcstrE08 As String = "E08"
    Public Const gcstrE09 As String = "E09"
    Public Const gcstrE10 As String = "E10"
End Module
