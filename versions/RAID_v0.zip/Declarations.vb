Option Strict On
Option Explicit On
Imports Microsoft.VisualBasic
Imports System.Net

Module Declarations



    Public gstrIniFileName As String
    Public gstrPassIniSection As String

    Public gbNewInboundData As Boolean
    Public gbNewOutboundData As Boolean

    Public gstrSocketPort() As String
    Public ciMaxSocketListeningPorts As Integer = 10

    Public giKeepLogDays As Integer



    'color setting
    Public colorFore As Color
    Public colorBack As Color
    Public cstrLogFilePrefix As String = Application.ProductName & "_"

    'Variables to hold UserName,Password, and Oracle TNS Name:
    Public DBUserName As String
    Public DBPassword As String
    Public DBServer As String
    Public DBSid As String


    'ADO DB Objects:
    Public DBCON1 As ADODB.Connection
    Public dbrec1 As ADODB.Recordset
    Public DBCON2 As ADODB.Connection
    Public dbrec2 As ADODB.Recordset


    Public oDataBaseConnection As DatabaseConnections
    Public gstrDatabaseType As String

    Public IniEntries() As IniType
    Public IniRecordCount As Integer

    'these are for outbound
    Public gstrSetSocketServerIPtoMyIP As String
    Public gstrSocketServerIP As String
    Public gstrSocketServerPort As String
    Public gstrDefaultFolderForXMLFiles As String
    Public gstrXSDFileName As String
    Public gstrLastXMLSent As String


    'xml messaging settings
    Public gstrXML_WCS_ID As String

    Public gstrIPAddressOverrideLocalPC As String

    'timer related
    Public giReplenAutoScanIntervalSeconds As Integer
    Public giPickingAutoScanIntervalSeconds As Integer
    Public giAutoHeartBeatSendIntervalMilliSeconds As Integer

    'unit load creation
    Public giLastULIDUsed As Integer
    Public gstrULIDPrefix As String

    'picking
    Public gstrPickingAutoScanErrorPercent As String
    Public gstrPickingUser_Id As String
    Public gstrStepForPopupForm As String

    Public CartonOkStatusTempProgression As String()
    Public CartonOkStatusProgression() As CartonProgressionType
    Public CartonOkStatusProgressionRecordCount As Integer

    Public CartonErrStatusTempProgression As String()
    Public CartonErrStatusProgression() As CartonProgressionType
    Public CartonErrStatusProgressionRecordCount As Integer

    'replen
    Public RequestCaseMoveRecordCount As Integer
    Public RequestCaseMove() As Request_Case_MoveType

    Public ReplenIntermediateLocations As String()
    Public ReplenIntermediateLocationsRecordCount As Integer


    Public PBLLocationRecordCount As Integer
    Public PBLLocation() As PBLLocationType

    Public gbValidatePickCartonBusiness As Boolean
    Public gbValidatePickCartonGMS_FLAG As Boolean

    'weight Tolerance
    Public gstrWeightToleranceUpperPercent As String
    Public gstrWeightToleranceUpperMaximum As String
    Public gstrWeightToleranceUpperMinimum As String
    Public gstrWeightToleranceLowerPercent As String
    Public gstrWeightToleranceLowerMaximum As String
    Public gstrWeightToleranceLowerMinimum As String

    Public Structure PBLLocationType
        Dim WH_ID As String
        Dim Location As String
        Dim Ctrl_Date As String
        Dim Status As String
        Dim Reason As String
    End Structure


    Public Structure Request_Case_MoveType
        Dim SSCC As String
        Dim Locatn As String
        Dim WH_ID As String
    End Structure
    Public Structure CartonProgressionType
        Dim StepName As String
        Dim Description As String
        Dim UserSelectedErrorRoute As Boolean
    End Structure
    Public PblReplenRecordCount As Integer
    Public PblReplen() As PblReplenType
    Public Structure PblReplenType
        Dim ULID As String
        Dim SSCC As String
        Dim Locatn As String
        Dim Ctrl_Date As String
        Dim StepNumber As String
        Dim PblLocatn As String
        Dim WH_ID As String
    End Structure
    Public SSCCServicesForStepDisplayRecordCount As Integer
    Public SSCCServicesForStepDisplay() As SSCCServicesType
    Public SSCCServicesRecordCount As Integer
    Public SSCCServices() As SSCCServicesType
    Public Structure SSCCServicesType
        Dim SSCC As String
        Dim OpStep As String
        Dim Wave As String
    End Structure

    Public SSCCServicesGroupedRecordCount As Integer
    Public SSCCServicesGrouped() As SSCCServicesGroupedType
    Public Structure PickCartonBusinessType
        Dim Business As String
    End Structure

    Public PickCartonBusinessRecordCount As Integer
    Public PickCartonBusiness() As PickCartonBusinessType
    Public Structure PickCartonGMS_FLAGType
        Dim GMS_FLAG As String
    End Structure

    Public PickCartonGMS_FLAGRecordCount As Integer
    Public PickCartonGMS_FLAG() As PickCartonGMS_FLAGType
    Public Structure SSCCServicesGroupedType
        Dim CountOfSSCC As String
        Dim OpStep As String
    End Structure
    Public InsertRepackWave() As RepackWaveType
    Public InsertRepackWaveRecordCount As Integer
    Public RepackWave() As RepackWaveType
    Public RepackWaveRecordCount As Integer
    Public Structure RepackWaveType
        Dim Wave As String
        Dim SSCC As String
        Dim Itmcod As String
        Dim Pick_Quantity As String
        Dim PickedQty As String
        Dim iCartonRecordIndex As Integer
        Dim Carton_Type As String
        Dim Carrier_ID As String
        Dim Carrier_Move As String
        Dim Carrier_Type As String
        Dim Customer As String
        Dim Order As String
        Dim Late_Ship As String
        Dim Early_Ship As String
        Dim Priority As String
        Dim Status As String
        Dim Label_Url As String
        Dim WH_ID As String
        Dim Applied_Qty As String
        Dim Location As String
        Dim UOM As String
        Dim Weight As String
        Dim GMS_FLAG As String  'new for Bournemouth
        Dim TOT_PICK_WEIGHT As String 'new for Bournemouth
        Dim BUSINESS As String 'new for Bournemouth

    End Structure
    Public InsertService() As InsertServiceType
    Public InsertServiceRecordCount As Integer
    Public Structure InsertServiceType
        Dim SSCC As String
        Dim Service As String
    End Structure
    Public Ignore_Error() As Ignore_ErrorType
    Public Ignore_ErrorRecordCount As Integer
    Public Structure Ignore_ErrorType
        Dim SSCC As String
        Dim ERROR_CODE As String
    End Structure
    Public IgnoredErrors() As IgnoredErrorsType
    Public IgnoredErrorsRecordCount As Integer
    Public Structure IgnoredErrorsType
        Dim SSCC As String
        Dim ERROR_CODE As String
        Dim CTRL_DATE As String
    End Structure

    Public Structure IniType
        Dim SectionName As String
        Dim KeyName As String
        Dim Value As String
    End Structure

    Public Sub Ini_Main()

        Dim lpSectionName As String
        Dim oini As ini

        oini = New ini

        IniRecordCount = 0
        ReDim IniEntries(0)

        gstrIniFileName = Application.StartupPath & "\" & Application.ProductName & ".ini"

        'Get Data for the Config Section of the ini file
        lpSectionName = "Config"
        Call iniConfig(oini, gstrIniFileName, lpSectionName)


        'Get Data for the Base Socket Communications of the ini file
        lpSectionName = "SocketCommunication"
        Call iniSocketCommunication(oini, gstrIniFileName, lpSectionName)

        'Get the listeneing port data
        lpSectionName = "SocketListeningPorts"
        Call iniSocketListeningPorts(oini, gstrIniFileName, lpSectionName)

        'Get Data for the Replen Section of the ini file
        lpSectionName = "Replen"
        Call iniReplen(oini, gstrIniFileName, lpSectionName)

        'Get Data for the Replen Section of the ini file
        lpSectionName = "Picking"
        Call iniPicking(oini, gstrIniFileName, lpSectionName)

        'Get Data for the LastDblogin of the ini file
        lpSectionName = "LastDBLogin"
        Call iniLastDBLogin(oini, gstrIniFileName, lpSectionName)

    End Sub

    Private Sub AddIniKeyNametoIniArray(ByRef lpSectionName As String, ByRef lpKeyName As String, ByRef strValue As String)
        IniRecordCount += 1
        ReDim Preserve IniEntries(IniRecordCount)
        With IniEntries(IniRecordCount)
            IniEntries(IniRecordCount).SectionName = lpSectionName
            IniEntries(IniRecordCount).KeyName = lpKeyName
            IniEntries(IniRecordCount).Value = strValue
        End With
    End Sub

    Private Sub iniConfig(ByVal oini As ini, ByVal strIniFileName As String, ByVal lpSectionName As String)
        Dim lpKeyName As String
        Dim strValue As String

        On Error GoTo ErrorHandler

        lpKeyName = "DatabaseType"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcstrACCESS, strIniFileName)
        gstrDatabaseType = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        lpKeyName = "KeepLogDays"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "7", strIniFileName)
        giKeepLogDays = CInt(strValue)
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)


        lpKeyName = "DefaultFolderForXMLFiles"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "c:\", strIniFileName)
        gstrDefaultFolderForXMLFiles = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        lpKeyName = "XSDFileName"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcstrNA, strIniFileName)
        gstrXSDFileName = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        lpKeyName = "WCS_ID"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "PBLWCS", strIniFileName)
        gstrXML_WCS_ID = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)


        lpKeyName = "AutoHeartBeatSendIntervalMilliSeconds"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "5000", strIniFileName)
        giAutoHeartBeatSendIntervalMilliSeconds = CInt(strValue)
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)


        Exit Sub

ErrorHandler:

        'Call inisubsiteSectionErrorHandler(Str$(Err.Number) & gcstrCommaSpace & Err.Description & vbCrLf & vbCrLf,
        '    lpKeyname, strinifilename, lpSectionName)

    End Sub
    Private Sub iniSocketCommunication(ByVal oini As ini, ByVal strIniFileName As String, ByVal lpSectionName As String)
        Dim lpKeyName As String
        Dim strValue As String

        On Error GoTo ErrorHandler

        lpKeyName = "IPAddressOverrideLocalPC"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "", strIniFileName)
        gstrIPAddressOverrideLocalPC = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        '  lpKeyName = "SocketPort"
        ' strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "12999", strIniFileName)
        'gstrSocketPort = strValue
        'Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)


        lpKeyName = "SetSocketServerIPtoMyIP"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "N", strIniFileName)
        gstrSetSocketServerIPtoMyIP = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        lpKeyName = "SocketServerIP"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "155.155.155.155", strIniFileName)
        If gstrSetSocketServerIPtoMyIP = gcstrY Then
            gstrSocketServerIP = GetIPAddress()
        Else
            gstrSocketServerIP = strValue
        End If
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, gstrSocketServerIP)

        lpKeyName = "SocketServerPort"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "13002", strIniFileName)
        gstrSocketServerPort = strValue
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        Exit Sub

ErrorHandler:

        'Call inisubsiteSectionErrorHandler(Str$(Err.Number) & gConvert.ToStringCommaSpace & Err.Description & vbCrLf & vbCrLf,
        '    lpKeyname, strinifilename, lpSectionName)

    End Sub
    Private Sub iniSocketListeningPorts(ByVal oini As ini, ByVal strIniFileName As String, ByVal lpSectionName As String)
        Dim lpKeyName As String
        Dim strValue As String

        Dim x As Integer

        On Error GoTo ErrorHandler


        ReDim gstrSocketPort(ciMaxSocketListeningPorts)

        For x = 1 To ciMaxSocketListeningPorts

            lpKeyName = "ListenPort" & x.ToString
            strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "0", strIniFileName)
            gstrSocketPort(x) = strValue

            Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        Next


        Exit Sub

ErrorHandler:

        'Call inisubsiteSectionErrorHandler(Str$(Err.Number) & gConvert.ToStringCommaSpace & Err.Description & vbCrLf & vbCrLf,
        '    lpKeyname, strinifilename, lpSectionName)

    End Sub

    Private Sub iniLastDBLogin(ByVal oini As ini, ByVal strIniFileName As String, ByVal lpSectionName As String)
        Dim lpKeyName As String
        Dim strValue As String

        On Error GoTo ErrorHandler

        lpKeyName = "DBServer"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, vbNullString, strIniFileName)
        DBServer = strValue

        lpKeyName = "DBSid"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "rtcis", strIniFileName)
        DBSid = strValue

        lpKeyName = "DBUser"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, vbNullString, strIniFileName)
        DBUserName = strValue

        Exit Sub

ErrorHandler:

        'Call inisubsiteSectionErrorHandler(Str$(Err.Number) & gConvert.ToStringCommaSpace & Err.Description & vbCrLf & vbCrLf,
        '    lpKeyname, strinifilename, lpSectionName)

    End Sub
    Public Function LogFileName() As String
        Dim strMonth As String
        Dim strDay As String
        Dim charPad As Char

        charPad = Convert.ToChar(gcStrZero)

        strMonth = Month(Now).ToString.PadLeft(2, charPad)
        strDay = Microsoft.VisualBasic.Day(Now).ToString.PadLeft(2, charPad)

        LogFileName = My.Application.Info.DirectoryPath & "\" & cstrLogFilePrefix & Year(Now) & strMonth & strDay & ".log"

    End Function

    Public Function SecondLogFileName() As String
        Dim strMonth As String
        Dim strDay As String
        Dim charPad As Char

        charPad = Convert.ToChar(gcStrZero)

        strMonth = Month(Now).ToString.PadLeft(2, charPad)
        strDay = Microsoft.VisualBasic.Day(Now).ToString.PadLeft(2, charPad)

        SecondLogFileName = My.Application.Info.DirectoryPath & "\" & cstrLogFilePrefix & "2_" & Year(Now) & strMonth & strDay & ".log"

    End Function

    Public Function GetIPAddress() As String

      

        If Len(gstrIPAddressOverrideLocalPC) < 3 Then
            'no override
            Return GetLocalIP()
        Else
            Return gstrIPAddressOverrideLocalPC
        End If

    
    End Function
    Function GetLocalIP() As String
        Dim IPList As System.Net.IPHostEntry = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName)
        Dim IpAddress As System.Net.IPAddress
        For Each IPAddress In IPList.AddressList


            'Only return IPv4 routable IPs       
            If (IPAddress.AddressFamily = Sockets.AddressFamily.InterNetwork) AndAlso (Not IsPrivateIP(IPAddress.ToString)) Then


                Return IPAddress.ToString
            End If
        Next
        Return ""
    End Function
    Function IsPrivateIP(ByVal CheckIP As String) As Boolean
        Dim Quad1, Quad2 As Integer
        Quad1 = CInt(CheckIP.Substring(0, CheckIP.IndexOf(".")))
        Quad2 = CInt(CheckIP.Substring(CheckIP.IndexOf(".") + 1).Substring(0, CheckIP.IndexOf(".")))
        Select Case Quad1
            Case 10
                Return True
            Case 172
                If Quad2 >= 16 And Quad2 <= 31 Then Return True
            Case 192
                If Quad2 = 168 Then Return True
        End Select
        Return False
    End Function


    Public Sub WriteLog(ByVal strAction As String, ByVal strText As String)
        Dim FilePath As String

        Try
            FilePath = LogFileName()
            My.Computer.FileSystem.WriteAllText(FilePath, Now & " | " & strAction.PadRight(15, Convert.ToChar(" ")) & strText.Trim & vbCrLf, True)
        Catch

        Finally

        End Try
    End Sub
    Public Sub WriteLogAckResponse(ByVal strAction As String, ByVal strText As String)
        Dim FilePath As String
        Dim charPad As Char
        Dim strMonth As String
        Dim strDay As String

        Try


            charPad = Convert.ToChar(gcStrZero)

            strMonth = Month(Now).ToString.PadLeft(2, charPad)
            strDay = Microsoft.VisualBasic.Day(Now).ToString.PadLeft(2, charPad)

            FilePath = My.Application.Info.DirectoryPath & "\" & "ACK" & cstrLogFilePrefix & Year(Now) & strMonth & strDay & ".log"

            My.Computer.FileSystem.WriteAllText(FilePath, Now & " | " & strAction.PadRight(15, Convert.ToChar(" ")) & strText.Trim & vbCrLf, True)
        Catch

        Finally

        End Try
    End Sub

    Public Function Mod10CheckDigit(ByVal Barcode As String) As Integer
        Dim i As Integer
        Dim TotalOdd As Integer
        Dim TotalEven As Integer
        Dim Total As Integer
        Dim strTotalRightOneChar As String
        Dim iRightCharVal As Integer

        Try
            Barcode = Trim(Barcode)
            'get odd numbers
            For i = 1 To Len(Barcode) Step 2
                TotalOdd += Convert.ToInt16(Mid(Barcode, i, 1))
            Next i
            TotalOdd *= 3

            'get even numbers
            i = 0
            For i = 2 To Len(Barcode) Step 2
                TotalEven += Convert.ToInt16(Mid(Barcode, i, 1))
            Next i

            Total = TotalOdd + TotalEven
            strTotalRightOneChar = Right(Convert.ToString(Total), 1)


            iRightCharVal = Convert.ToInt16(IIf(strTotalRightOneChar = gcStrZero, "10", strTotalRightOneChar))


            Mod10CheckDigit = 10 - iRightCharVal

        Catch

            'dont set anything
        End Try
    End Function

    Private Sub iniReplen(ByVal oini As ini, ByVal strIniFileName As String, ByVal lpSectionName As String)
        Dim lpKeyName As String
        Dim strValue As String
        Dim iValue As Integer

        On Error GoTo ErrorHandler

        lpKeyName = "ReplenAutoScanIntervalSeconds"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "5", strIniFileName).ToUpper

        'validate the number so the timer wont blow up
        If IsNumeric(strValue) Then
            iValue = CInt(strValue)
            If iValue <= 0 Then
                iValue = 5
            End If
        Else
            iValue = 5
        End If

        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, iValue.ToString)

        giReplenAutoScanIntervalSeconds = iValue


        lpKeyName = "ReplenIntermediateLocations"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcstrNA, strIniFileName).ToUpper
        strValue = Strings.Replace(strValue, " ", String.Empty)
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        ReDim ReplenIntermediateLocations(0)
        ReplenIntermediateLocationsRecordCount = 0

        If Strings.Len(strValue) > 0 And strValue <> gcstrNA Then
            ReplenIntermediateLocations = strValue.Split(gcCharComma)
            ReplenIntermediateLocationsRecordCount = ReplenIntermediateLocations.GetUpperBound(0) + 1
        End If


        Exit Sub

ErrorHandler:

        'Call inisubsiteSectionErrorHandler(Str$(Err.Number) & gcstrCommaSpace & Err.Description & vbCrLf & vbCrLf,
        '    lpKeyname, strinifilename, lpSectionName)

    End Sub


    Private Sub iniPicking(ByVal oini As ini, ByVal strIniFileName As String, ByVal lpSectionName As String)
        Dim lpKeyName As String
        Dim strValue As String
        Dim iValue As Integer

        Dim strArrayValues As String()

        Dim x As Integer

        On Error GoTo ErrorHandler

        lpKeyName = "PickingAutoScanIntervalSeconds"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "5", strIniFileName).ToUpper

        'validate the number so the timer wont blow up
        If IsNumeric(strValue) Then
            iValue = CInt(strValue)
            If iValue <= 0 Then
                iValue = 5
            End If
        Else
            iValue = 5
        End If

        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, iValue.ToString)

        giPickingAutoScanIntervalSeconds = iValue

        lpKeyName = "PickingAutoScanErrorPercent"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcStrZero, strIniFileName).ToUpper
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)
        gstrPickingAutoScanErrorPercent = strValue

        lpKeyName = "PickingUser_Id"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "", strIniFileName).ToUpper
        If strValue = "0" Then strValue = String.Empty
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)
        gstrPickingUser_Id = strValue

        lpKeyName = "CartonOkStatusProgression"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcstrNA, strIniFileName).ToUpper
        strValue = Strings.Trim(strValue)
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        ReDim CartonOkStatusProgression(0)
        CartonOkStatusProgressionRecordCount = 0

        If Strings.Len(strValue) > 0 And strValue <> gcstrNA Then
            CartonOkStatusTempProgression = strValue.Split(gcCharComma)
            CartonOkStatusProgressionRecordCount = CartonOkStatusTempProgression.GetUpperBound(0) + 1

            For x = 1 To CartonOkStatusProgressionRecordCount
                ReDim Preserve CartonOkStatusProgression(x)
                With CartonOkStatusProgression(x)
                    .StepName = gcstrCartonPathGood & x.ToString.PadLeft(2, gcCharZero)
                    .Description = CartonOkStatusTempProgression(x - 1)
                End With
            Next

        End If

        lpKeyName = "CartonErrStatusProgression"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcstrNA, strIniFileName).ToUpper
        strValue = Strings.Trim(strValue)
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        ReDim CartonErrStatusProgression(0)
        CartonErrStatusProgressionRecordCount = 0

        If Strings.Len(strValue) > 0 And strValue <> gcstrNA Then
            CartonErrStatusTempProgression = strValue.Split(gcCharComma)
            CartonErrStatusProgressionRecordCount = CartonErrStatusTempProgression.GetUpperBound(0) + 1

            For x = 1 To CartonOkStatusProgressionRecordCount
                ReDim Preserve CartonErrStatusProgression(x)
                With CartonErrStatusProgression(x)
                    .StepName = gcstrCartonPathError & x.ToString.PadLeft(2, gcCharZero)
                    .Description = CartonErrStatusTempProgression(x - 1)
                End With
            Next
        End If

        lpKeyName = "ValidatePickCartonBusiness"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcstrY, strIniFileName).ToUpper.Trim
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)
        If strValue = "Y" Then
            gbValidatePickCartonBusiness = True
        Else
            gbValidatePickCartonBusiness = False
        End If

        lpKeyName = "PickCartonBusinessValues"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcstrNA, strIniFileName).ToUpper.Trim
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        ReDim PickCartonBusiness(0)
        PickCartonBusinessRecordCount = 0

        If Strings.Len(strValue) > 0 And strValue <> gcstrNA Then
            strArrayValues = strValue.Split(gcCharComma)
            PickCartonBusinessRecordCount = strArrayValues.GetUpperBound(0) + 1

            For x = 1 To PickCartonBusinessRecordCount
                ReDim Preserve PickCartonBusiness(x)
                With PickCartonBusiness(x)
                    .Business = strArrayValues(x - 1)
                End With
            Next
        End If

        lpKeyName = "ValidatePickCartonGMS_FLAG"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcstrY, strIniFileName).ToUpper.Trim
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)
        If strValue = "Y" Then
            gbValidatePickCartonGMS_FLAG = True
        Else
            gbValidatePickCartonGMS_FLAG = False
        End If

        lpKeyName = "PickCartonGMS_FLAGValues"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, gcstrNA, strIniFileName).ToUpper.Trim
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)

        ReDim PickCartonGMS_FLAG(0)
        PickCartonGMS_FLAGRecordCount = 0

        If Strings.Len(strValue) > 0 And strValue <> gcstrNA Then
            strArrayValues = strValue.Split(gcCharComma)
            PickCartonGMS_FLAGRecordCount = strArrayValues.GetUpperBound(0) + 1

            For x = 1 To PickCartonGMS_FLAGRecordCount
                ReDim Preserve PickCartonGMS_FLAG(x)
                With PickCartonGMS_FLAG(x)
                    .GMS_FLAG = strArrayValues(x - 1)
                End With
            Next
        End If

        lpKeyName = "WeightToleranceUpperPercent"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "10", strIniFileName).ToUpper
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)
        gstrWeightToleranceUpperPercent = strValue

        lpKeyName = "WeightToleranceUpperMaximum"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "500", strIniFileName).ToUpper
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)
        gstrWeightToleranceUpperMaximum = strValue


        lpKeyName = "WeightToleranceUpperMinimum"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "100", strIniFileName).ToUpper
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)
        gstrWeightToleranceUpperMinimum = strValue


        lpKeyName = "WeightToleranceLowerPercent"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "5", strIniFileName).ToLower
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)
        gstrWeightToleranceLowerPercent = strValue

        lpKeyName = "WeightToleranceLowerMaximum"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "200", strIniFileName).ToLower
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)
        gstrWeightToleranceLowerMaximum = strValue


        lpKeyName = "WeightToleranceLowerMinimum"
        strValue = oini.ProfileGetItem(lpSectionName, lpKeyName, "50", strIniFileName).ToLower
        Call AddIniKeyNametoIniArray(lpSectionName, lpKeyName, strValue)
        gstrWeightToleranceLowerMinimum = strValue



        Exit Sub

ErrorHandler:



    End Sub

    Public Function SSCCServicesDescriptionFromOpStep(ByVal strStep As String) As String

        Dim iStepOnly As Integer

        SSCCServicesDescriptionFromOpStep = String.Empty   'initialize

        Try



            iStepOnly = CInt(Strings.Right(strStep, 2))

            If Strings.Left(strStep, 1) = gcstrCartonPathGood Then


                SSCCServicesDescriptionFromOpStep = CartonOkStatusProgression(iStepOnly).Description
            Else
                'is in error

                SSCCServicesDescriptionFromOpStep = CartonErrStatusProgression(iStepOnly).Description

            End If
        Catch
            WriteLog(gcstrError, "SSCCServicesDescriptionFromOpStep " & Err.Description)
        End Try

    End Function
    Public Function UpdateDBWithCartonAdvanceStep(ByVal strSSCC As String, ByVal strOpStep As String) As Boolean


        Dim strSql As String

        Try

            strSql = "Update Z_PBL_Wave " & _
                    "set opstep='" & strOpStep & "' " & _
                    " where " & _
                    "SSCC='" & strSSCC & "' "

            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If

            UpdateDBWithCartonAdvanceStep = True
        Catch
            UpdateDBWithCartonAdvanceStep = False
            WriteLog(gcstrError, "UpdateDBWithCartonAdvanceStep: " & Err.Description)
        End Try

    End Function

    Public Sub UpdateDBMoveAllErrorCartonsToLastErrorStep()


        Dim strSql As String
        Dim strOpstep As String

        Try

            strOpstep = "E" & CartonErrStatusProgressionRecordCount.ToString.PadLeft(2, Convert.ToChar(gcStrZero))


            strSql = "Update Z_PBL_Wave " & _
                    "set opstep='" & strOpstep & "' " & _
                    " where " & _
                    "opstep like 'E%' "

            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If


        Catch

            WriteLog(gcstrError, "UpdateDBMoveAllErrorCartonsToLastErrorStep: " & Err.Description)
        End Try

    End Sub
    Public Sub DeleteSSCCsinDbLastStep()


        Dim strSql As String
        Dim strOpstep As String

        Try

            strOpstep = "G" & CartonErrStatusProgressionRecordCount.ToString.PadLeft(2, Convert.ToChar(gcStrZero))


            strSql = "delete from Z_PBL_Wave " & _
                    "where opstep='" & strOpstep & "' "


            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If

            WriteLog(gcstrProcessed, "Deleted All SSCCs in the Last Step")

        Catch

            WriteLog(gcstrError, "DeleteSSCCsinDbLastStep: " & Err.Description)
        End Try

    End Sub

    Public Function RandomNumber(ByVal low As Integer, ByVal high As Integer) As Integer
        Static RandomNumGen As New System.Random
        Return RandomNumGen.Next(low, high)
    End Function

    Public Sub ProcessGridDeSelectAll(ByVal oGrid As AxMSFlexGridLib.AxMSFlexGrid)
        Dim x As Integer

        oGrid.Col = 0

        For x = 1 To oGrid.Rows - 1
            oGrid.Row = x
            oGrid.set_TextMatrix(x, 0, vbNullString)
        Next
    End Sub

    Public Sub ProcessGridSelectAll(ByVal oGrid As AxMSFlexGridLib.AxMSFlexGrid)
        Dim x As Integer

        oGrid.Col = 0

        'only select non errored rows visible rows
        For x = 1 To oGrid.Rows - 1
            oGrid.Row = x
            If oGrid.get_RowHeight(x) > 0 Then
                If Len(oGrid.get_TextMatrix(x, 1)) > 0 Then

                    'only allow selection of items that are not in the pick step
                    '  If Convert.ToInt32(oGrid.get_TextMatrix(x, 2)) <> giPickStepNumber Then
                    oGrid.set_TextMatrix(x, 0, gcstrY)
                    'End If
                End If
            End If
        Next
    End Sub

    Public Sub ProcessGridMouseDown(ByVal oGrid As AxMSFlexGridLib.AxMSFlexGrid, ByVal iMouseButton As Integer)
        Dim strText As String
        Dim iRowSel As Integer
        Dim iColSel As Integer
        Dim strNewValue As String
        Dim strCurValue As String
        Dim strColHeader As String
        Dim iMsgResult As Integer


        iRowSel = oGrid.MouseRow
        iColSel = oGrid.MouseCol

        'first row is header row
        If iRowSel = 0 Then Exit Sub

        strText = Trim(oGrid.get_TextMatrix(iRowSel, iColSel))

        If iMouseButton = 2 Then

            'Save to clipboard 
            Clipboard.SetDataObject(strText)

        ElseIf iColSel = 0 Then

            'toggle the selection flag
            If oGrid.get_TextMatrix(iRowSel, 0) = gcstrY Then
                oGrid.set_TextMatrix(iRowSel, 0, vbNullString)
            Else
                oGrid.set_TextMatrix(iRowSel, 0, gcstrY)
            End If

        Else

            'Get the column header
            strColHeader = oGrid.get_TextMatrix(0, iColSel)

            'allow user to temporarily override status
            strCurValue = oGrid.get_TextMatrix(iRowSel, iColSel)

            strNewValue = InputBox(strColHeader & " Value:", "Override Value", strCurValue)
            If Strings.Len(strNewValue) = 0 Then
                iMsgResult = MessageBox.Show("Keep the Original Value of " & strCurValue & "?", "Null Value Detected", MessageBoxButtons.YesNo)

                If iMsgResult = Windows.Forms.DialogResult.Yes Then
                    oGrid.set_TextMatrix(iRowSel, iColSel, strCurValue)
                Else
                    oGrid.set_TextMatrix(iRowSel, iColSel, strNewValue)
                End If

            Else
                oGrid.set_TextMatrix(iRowSel, iColSel, strNewValue)
            End If

            'End If

        End If
    End Sub
End Module