Option Explicit On
Option Strict Off
Imports Microsoft.VisualBasic
Imports System.Reflection.MethodBase    'used to get procedure name for error logging



Public Class Main

    Public SocketServer As AsynchronousSocketListener
    Public SecondSocketServer As AsynchronousSocketListener
    Const bBypassDB As Boolean = False
    Public dbConStatus As Integer
    Public dbConStatusAccess As Integer
    Public piTabSelected As Integer
    Public bToggle As Boolean
    Public pstrPLNumb As String
    Public PromptForUserConfirmation As String = True
    Public SendHeartbeatAutomatically As Boolean = False

    Private Sub Main_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        SocketServer.CloseSockets()
        SecondSocketServer.CloseSockets()
    End Sub



    Private Sub Main_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        'Ensure that the user doesn't mistakenly close 

        Dim iMsgResult As DialogResult
        iMsgResult = (MessageBox.Show("Are you sure you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2))
        If iMsgResult = Windows.Forms.DialogResult.Yes Then
            e.Cancel = False
            SaveLastXMLSent()
            End
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub SaveLastXMLSent()
        'save the Last XML Sent at form closing to use in the XML editor form

        Dim myStream As New System.IO.StreamWriter(My.Application.Info.DirectoryPath & "\" & gcstrLastXMLSentFileName, True)
        myStream.Write(gstrLastXMLSent)
        myStream.Close()
    End Sub

    Private Sub Main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Startup()
    End Sub
    Private Sub Startup()
        Dim x As Integer
        Dim strVersion As String
        Dim strSocket As String

        'Set the variables for color
        colorFore = System.Drawing.Color.Black
        colorBack = System.Drawing.Color.White

        strVersion = "v" & System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).FileMajorPart & "." & System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).FileMinorPart

        Me.Text = Application.ProductName & Space(1) & strVersion & Space(2) & "(Control System Emulator)"

        PositionFormatStartup()

        WriteLog("Startup ", vbNullString)

        'use the configuration settings
        Ini_Main()

        'fix the tab page colors - issue with settign this on the page properties always revert to white  arrghh
        TabPage1.BackColor = Color.FromKnownColor(KnownColor.Control)
        TabPage2.BackColor = Color.FromKnownColor(KnownColor.Control)
        TabPage3.BackColor = Color.FromKnownColor(KnownColor.Control)
        TabPage4.BackColor = Color.FromKnownColor(KnownColor.Control)
        TabPage5.BackColor = Color.FromKnownColor(KnownColor.Control)

        'set initial state of various buttons
        btnReplenAutoScanOff.BackColor = Color.Red
        btnCartonAutoScanOff.BackColor = Color.Red

        'Present User Form to Login into DATABASE
        Dim formLogin As New frmLoginDB
        formLogin.ShowDialog()
        ConnectToDatabase()

        'start socket listener(s)

        For x = 1 To gstrSocketPort.GetUpperBound(0)
            'should always be 1

            strSocket = gstrSocketPort(x)

            If IsNumeric(strSocket) Then
                If CInt(strSocket) > 0 Then
                    SocketServer = New AsynchronousSocketListener(gstrSocketPort(x))
                End If

            End If
        Next


        'Write the version and settings to the log file
        WriteLog("START", Strings.StrDup(60, "-"))
        WriteLog("Version ", String.Format("Version {0}", My.Application.Info.Version.ToString))
        WriteLog("MyIP ", GetLocalIP)
        For x = 1 To IniRecordCount
            WriteLog("Setting", IniEntries(x).KeyName & "=" & IniEntries(x).Value)
        Next

        ToolStripStatusLblConnections.Text = "Host Connection:" & Space(1) & gstrSocketServerIP & Space(2) & "Port: " & gstrSocketServerPort

        'Display the first tabs data
        piTabSelected = 1
        GetPBLReplenData()

        RefreshLog()
    End Sub

    Private Sub RefreshLog()
        'display the contents of today's log file to the main screen
        Dim FilePath As String

        Try
            'log file 1
            FilePath = LogFileName()

            txtLog.Text = My.Computer.FileSystem.ReadAllText(FilePath)

            txtLog.SelectionStart = txtLog.TextLength
            txtLog.ScrollToCaret()


            'log file 2  - DES refactor!
            FilePath = SecondLogFileName()

            txtLog2.Text = My.Computer.FileSystem.ReadAllText(FilePath)

            txtLog2.SelectionStart = txtLog.TextLength
            txtLog2.ScrollToCaret()


            butRefresh.BackColor = Color.FromKnownColor(KnownColor.Control)
            ToolStripStatusLabelRefresh.Visible = False

            'highlight errors
            SearchLog("ERROR ", Color.Red) 'with the space to avoid finding ini parameters!


        Catch
            ' move on

        End Try
    End Sub
    Private Sub SearchLog(ByVal SearchText As String, ByVal HighLightColor As Color)
        Try
            Dim textEnd As Integer = txtLog.TextLength
            Dim index As Integer = 0
            Dim lastIndex As Integer = txtLog.Text.LastIndexOf(SearchText)

            While index < lastIndex
                txtLog.Find(SearchText, index, textEnd, RichTextBoxFinds.None)
                txtLog.SelectionBackColor = HighLightColor
                txtLog.SelectionColor = Color.White
                index = txtLog.Text.IndexOf(SearchText, index) + 1
            End While
        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try

    End Sub


    Private Sub MainToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MainToolStripMenuItem.Click
        'ensure sync with ini file
        Call Ini_Main()
        gstrPassIniSection = "Config"

        Dim formConfig As New frmConfig
        formConfig.ShowDialog()
    End Sub

    Private Sub WriteLog(ByVal strAction As String, ByVal strText As String)
        Dim FilePath As String

        Try
            If Len(strText) = 0 Then Exit Sub

            FilePath = LogFileName()
            My.Computer.FileSystem.WriteAllText(FilePath, Now & " | " & strAction.PadRight(15, Convert.ToChar(" ")) & strText.Trim & vbCrLf, True)
        Catch

        Finally
            tmrRefreshLog.Enabled = True
        End Try
    End Sub


    Private Sub DeleteOldLogFiles()
        Dim DaysOld As Integer
        Dim DeleteTime As DateTime

        Try

            DaysOld = giKeepLogDays
            DeleteTime = Today.AddDays(DaysOld * -1)

            For Each fullFilePath As String In My.Computer.FileSystem.GetFiles(My.Application.Info.DirectoryPath)
                If Strings.Right(fullFilePath.ToUpper, 4) = ".LOG" Then
                    If Strings.InStr(fullFilePath, cstrLogFilePrefix) > 1 Then

                        Dim fiFile As New System.IO.FileInfo(fullFilePath)
                        If fiFile.Exists Then
                            If fiFile.LastWriteTime < DeleteTime Then
                                fiFile.Delete()
                            End If

                        End If

                    End If
                End If
                Debug.Print(fullFilePath)
            Next

        Catch ex As Exception
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        Finally
            WriteLog("Purged Logs", "Older than " & DeleteTime)

        End Try
    End Sub

    Private Sub DeleteOldLogsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteOldLogsToolStripMenuItem.Click
        DeleteOldLogFiles()
    End Sub

    Private Sub ConnectToDatabase()
        Try
            'Make the database connection with the above parameters
            If bBypassDB = False Then

                oDataBaseConnection = New DatabaseConnections


                If gstrDatabaseType = gcstrACCESS Then
                    dbConStatus = oDataBaseConnection.ConnectToAccessDB( _
                                             Application.StartupPath & "\" & Application.ProductName & ".mdb")


                    'dbConStatus = oDataBaseConnection.ConnectToSQLServerDB( _


                    '                            Application.StartupPath & "\" & Application.ProductName & ".mdf")

                Else
                    'oracle
                    dbConStatus = oDataBaseConnection.ConnectToDB(DBUserName, DBPassword)

                End If

                If dbConStatus = -1 Then
                    Call oDataBaseConnection.DisplayDatabaseConnectionError( _
                        gstrDatabaseType)
                End If


            End If
        Catch
            SubError("ConnectToDatabase (" & gstrDatabaseType & ") ", Err.Description)
        End Try

    End Sub

    Private Sub SubError(ByVal strSub As String, ByVal strErr As String)
        MessageBox.Show("Error in SubRoutine: " & strSub & _
                   vbCrLf & vbCrLf & strErr, "Program Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub


    Private Sub SendXMLFromFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SendXMLFromFileToolStripMenuItem.Click
        Dim strFilename As String
        Dim strXML As String

        Try
            strFilename = InputBox("Enter Complete Filepath and Filename including Extension:", "Specify File", gstrDefaultFolderForXMLFiles)

            If Len(strFilename) > 0 Then
                strXML = My.Computer.FileSystem.ReadAllText(strFilename)

                WriteLog("Sending", strFilename)

                SendRequest(strXML)
            End If
        Catch
            MessageBox.Show("Error with XML" & vbCrLf & vbCrLf & Err.Description, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try

    End Sub

    Private Sub tmrRefreshLog_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrRefreshLog.Tick
        Try
            If gbNewInboundData = True Then
                butRefresh.BackColor = Color.Green
                ToolStripStatusLabelRefresh.Visible = True

                If chkAutoRefresh.Checked = True Then
                    tmrBlink.Enabled = True
                    RefreshLog()
                End If

            End If

            If gbNewOutboundData = True Then
                If chkAutoRefresh.Checked = True Then
                    RefreshLog()
                End If

            End If

            gbNewInboundData = False
            gbNewOutboundData = False


        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Err.Description)
        Finally

        End Try
    End Sub

    Private Sub SendHeartbeatToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SendHeartbeatToolStripMenuItem.Click
        SendHeartbeat()
    End Sub
    Private Sub SendHeartbeat()
        WriteLog("Send", "Heartbeat")
        Dim strTest As String = CreateXMLHeartbeat(Now.ToString)

        SendRequest(strTest)
        gbNewOutboundData = True
    End Sub

    Private Sub ServiceStepsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ServiceStepsToolStripMenuItem.Click
        'close all popup windows

        Dim objType As Type() = Reflection.Assembly.GetExecutingAssembly.GetTypes()
        Dim x As Integer
        Try

            For x = Application.OpenForms.Count - 1 To 0 Step -1

                'MessageBox.Show(Application.OpenForms.Item(x).Name)
                If Application.OpenForms.Item(x).Name = "frmStepDetail" Or _
                  Application.OpenForms.Item(x).Name = "frmXMLEditor" Then

                    Application.OpenForms.Item(x).Close()
                End If
            Next

        Catch ex As Exception
            MessageBox.Show("Error Closing Popups" & ex.Message)
        Finally

        End Try

    End Sub


    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        Dim formAbout As New AboutBox1

        AboutBox1.ShowDialog()
    End Sub

    Private Sub TabPage1_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabPage1.Enter
        If piTabSelected <> 1 Then

        End If

        piTabSelected = 1

    End Sub


    Private Sub butRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butRefresh.Click
        RefreshLog()
    End Sub

    Private Sub tmrBlink_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrBlink.Tick
        Static iCount As Integer

        iCount += 1
        If iCount > 6 Then

            tmrBlink.Enabled = False
            ToolStripStatusLabelRefresh.Visible = False
            ToolStripStatusLabelRefresh.BackColor = Color.FromKnownColor(KnownColor.Control)
            iCount = 0
        Else
            ToolStripStatusLabelRefresh.Visible = True
            Select Case iCount
                Case 1, 3, 5
                    ToolStripStatusLabelRefresh.BackColor = Color.Green
                Case Else
                    ToolStripStatusLabelRefresh.BackColor = Color.FromKnownColor(KnownColor.Control)

            End Select

        End If

    End Sub

    Private Sub SocketCommunicationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SocketCommunicationToolStripMenuItem.Click

        'ensure sync with ini file
        Call Ini_Main()
        gstrPassIniSection = "SocketCommunication"
        Dim formConfig As New frmConfig
        formConfig.ShowDialog()

    End Sub

    Public Function DisplayNextUnitLoadID() As String
        Dim strULIDSuffix As String
        Dim strULIDNoCheckDigit As String
        Dim strCheckDigit As String
        Dim pad As Char

        Try
            strULIDSuffix = Convert.ToString(giLastULIDUsed + 1)

            pad = "0"c
            strULIDSuffix = strULIDSuffix.PadLeft(9, pad)

            strULIDNoCheckDigit = gstrULIDPrefix & strULIDSuffix


            strCheckDigit = Convert.ToString(Mod10CheckDigit(strULIDNoCheckDigit))
            DisplayNextUnitLoadID = strULIDNoCheckDigit & strCheckDigit
        Catch
            DisplayNextUnitLoadID = String.Empty
        End Try

    End Function
    Private Sub DeleteEmulatorDBLocationData()
        Dim strSQL As String
        Dim iMsgResult As DialogResult

        Try

            iMsgResult = MessageBox.Show("Ok to Delete Location Data?", "Confirm Emulator Data Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
            If iMsgResult = Windows.Forms.DialogResult.No Then Exit Sub

            strSQL = "delete from Z_PBL_LOCATION "

            DBCON1.Execute(strSQL)

            WriteLog("Success", GetCurrentMethod.Name)

        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
            RefreshLog()

        Finally

        End Try

    End Sub
    Private Sub DeleteEmulatorDBReplenData()
        Dim strSQL As String
        Dim iMsgResult As DialogResult

        Try

            iMsgResult = MessageBox.Show("Ok to Delete Replen Data?", "Confirm Emulator Data Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
            If iMsgResult = Windows.Forms.DialogResult.No Then Exit Sub

            strSQL = "delete from Z_PBL_REPLEN "

            DBCON1.Execute(strSQL)

            WriteLog("Success", "DeleteEmulatorDBReplenData ")

        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
            RefreshLog()

        Finally

        End Try

    End Sub
    Private Sub DeleteEmulatorDBPBLWave()
        Dim strSQL As String
        Dim iMsgResult As DialogResult

        Try

            iMsgResult = MessageBox.Show("Ok to Delete PBL Data?", "Confirm PBL Data Deletion", MessageBoxButtons.YesNo)

            If iMsgResult = Windows.Forms.DialogResult.Yes Then
                strSQL = "delete from Z_PBL_Wave "

                DBCON1.Execute(strSQL)

                strSQL = "delete from Z_PBL_Service "

                DBCON1.Execute(strSQL)

                WriteLog("Success", "Deleted Emulator DB PBL Data ")
            End If

        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
            RefreshLog()

        Finally

        End Try


    End Sub

    Private Sub GetPBLReplenData()
        FillPBLReplenArray()
        DisplayPBLReplenArray()
    End Sub

    Private Sub FillPBLReplenArray()
        Dim strSQL As String
        Dim strStepNumber As String

        Try

            'step 9 is completion step - other steps are intermediate locations
            strSQL = "select SSCC, LOCATN, CTRL_DATE, STEPNUMBER, PBL_LOCATN, WH_ID " & _
                "from Z_PBL_REPLEN " & _
                "where stepnumber <> '9' or stepnumber is null " & _
                "order by ctrl_Date desc, SSCC "


            ' Open the Recordset using the select string:
            dbrec1.Open(strSQL, DBCON1)

            PblReplenRecordCount = 0
            ReDim PblReplen(0)


            Do Until dbrec1.EOF

                ' Populate the PBLReplen array by parsing through the recordset one row at a time:
                PblReplenRecordCount += 1
                ReDim Preserve PblReplen(PblReplenRecordCount)

                With PblReplen(PblReplenRecordCount)


                    .SSCC = Convert.ToString(dbrec1.Fields("SSCC").Value)
                    .Locatn = Convert.ToString(dbrec1.Fields("LOCATN").Value)
                    .Ctrl_Date = Convert.ToString(dbrec1.Fields("CTRL_DATE").Value)
                    strStepNumber = Convert.ToString(dbrec1.Fields("STEPNUMBER").Value)
                    If Len(strStepNumber) = 0 Then
                        .StepNumber = gcStrZero
                    Else
                        .StepNumber = strStepNumber
                    End If
                    .PblLocatn = Convert.ToString(dbrec1.Fields("PBL_LOCATN").Value)
                    .WH_ID = Convert.ToString(dbrec1.Fields("WH_ID").Value)

                End With

                dbrec1.MoveNext()

            Loop

            'Close Recordset:
            dbrec1.Close()

        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
            RefreshLog()
        End Try

    End Sub

    Private Sub DisplayPBLReplenArray()
        Dim x As Integer
        Dim y As Integer

        Try
            flxGrid1.Rows = 1
            flxGrid1.Rows = 2
            flxGrid1.Cols = 7
            flxGrid1.Row = 0
            For y = 1 To flxGrid1.Cols
                flxGrid1.Col = y - 1
                flxGrid1.Text = vbNullString

                Select Case flxGrid1.Col

                    Case 0, 6
                        flxGrid1.set_ColWidth(flxGrid1.Col, 500)

                    Case 1, 3, 4, 5
                        flxGrid1.set_ColWidth(flxGrid1.Col, 2000)

                    Case Else
                        flxGrid1.set_ColWidth(flxGrid1.Col, 1000)

                End Select

            Next

            flxGrid1.Redraw = False

            ' Initialize the Grid by defining the headers:
            flxGrid1.Rows = 2
            flxGrid1.Row = 0

            flxGrid1.Col = 0
            flxGrid1.Text = "Sel"
            flxGrid1.Col = 1
            flxGrid1.Text = "Ctrl_Date"
            flxGrid1.Col = 2
            flxGrid1.Text = "WH_ID"
            flxGrid1.Col = 3
            flxGrid1.Text = "SSCC"
            flxGrid1.Col = 4
            flxGrid1.Text = "Final Dest"
            flxGrid1.Col = 5
            flxGrid1.Text = "PBL Location"
            flxGrid1.Col = 6
            flxGrid1.Text = "Step"


            For x = 1 To PblReplenRecordCount

                flxGrid1.Row += 1

                flxGrid1.Col = 1
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & PblReplen(x).Ctrl_Date

                flxGrid1.Col = 2
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & PblReplen(x).WH_ID

                flxGrid1.Col = 3
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & PblReplen(x).SSCC

                flxGrid1.Col = 4
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & PblReplen(x).Locatn

                flxGrid1.Col = 5
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & PblReplen(x).PblLocatn

                flxGrid1.Col = 6
                flxGrid1.CellBackColor = colorBack
                flxGrid1.CellForeColor = colorFore
                flxGrid1.Text = vbNullString & PblReplen(x).StepNumber

                flxGrid1.Rows += 1

            Next


            'remove last blank row
            flxGrid1.Rows -= 1
            flxGrid1.Col = 0
            ' flxGrid1.Sort = flexSortNumericAscending
        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
            RefreshLog()
        Finally

            flxGrid1.Redraw = True

        End Try
    End Sub

    Private Sub cmdRefreshReplen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRefreshReplen.Click
        FillPBLReplenArray()
        DisplayPBLReplenArray()
    End Sub


    Private Sub cmdReplenSelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReplenSelectAll.Click
        ProcessGridSelectAll(flxGrid1)
    End Sub


    Private Sub cmdReplenDeSelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReplenDeSelectAll.Click
        ProcessGridDeSelectAll(flxGrid1)
    End Sub

    Private Sub flxGrid1_MouseDownEvent(ByVal sender As Object, ByVal e As AxMSFlexGridLib.DMSFlexGridEvents_MouseDownEvent) Handles flxGrid1.MouseDownEvent
        ProcessGridMouseDown(CType(sender, AxMSFlexGrid), e.button)
    End Sub

    Private Sub ReplenishmentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReplenishmentToolStripMenuItem.Click
        'ensure sync with ini file
        Call Ini_Main()
        gstrPassIniSection = "Replen"
        Dim formConfig As New frmConfig
        formConfig.ShowDialog()
    End Sub

    Private Sub ReplenAdvance(ByVal bUserPrompt As Boolean)
        Dim x As Integer
        Dim shMsgbox As MsgBoxResult

        Try

            If bUserPrompt = True Then

                shMsgbox = MsgBox("Advance Selected SSCC(s) to Next Location?", MsgBoxStyle.YesNo, "Confirm SSCC Location Advance")

                If shMsgbox = MsgBoxResult.No Then
                    Exit Sub
                End If
            Else
                GetPBLReplenData()
                ProcessGridSelectAll(flxGrid1)

            End If

            For x = 1 To flxGrid1.Rows - 1

                If flxGrid1.get_TextMatrix(x, 0) = gcstrY Then
                    'do the advance
                    SSCCReplenAdvanceLocation(flxGrid1.get_TextMatrix(x, 3), flxGrid1.get_TextMatrix(x, 4), CInt(flxGrid1.get_TextMatrix(x, 6)), _
                        flxGrid1.get_TextMatrix(x, 2))
                End If
            Next

        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        Finally

            If bUserPrompt = True Then
                GetPBLReplenData()
            End If

        End Try
    End Sub

    Private Sub cmdReplenAdvance_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReplenAdvance.Click
        ReplenAdvance(PromptForUserConfirmation)
    End Sub

    Private Sub SSCCCartonAdvance_SetCartonInformation(ByVal strSSCC As String, ByVal strToStep As String, _
        ByVal strStatus As String, ByVal strWeight As String, ByVal strService As String)

        Dim strXML As String
        Dim bUpdateSuccess As Boolean

        Dim strWgtVal As String
        Dim sWgtTol As Single
        Dim strWgtValTtyp As String
        Dim sCartonWeightMultiplier As Single
        Dim sActualWeight As Single
        Dim sTheoreticalWeight As Single
        Dim sDiffWeight As Single
        Dim sUpperTolerance As Single
        Dim sLowerTolerance As Single



        Try

            If strWeight.Length = 0 Then
                strXML = CreateXML_Set_Carton_Information(strSSCC, strStatus, strWeight, strService, _
                            String.Empty, String.Empty, String.Empty, String.Empty)
            Else

                'get comcatneanted value from db
                strWgtValTtyp = GetCartonWgtValTypFromDB(strSSCC)

                If IsNumeric(txtCartonWeight.Text) Then
                    sCartonWeightMultiplier = Convert.ToSingle(txtCartonWeight.Text)
                Else
                    sCartonWeightMultiplier = 1
                End If

                'strWeight will be the theoretical weight
                sTheoreticalWeight = Convert.ToSingle(strWeight)
                sActualWeight = sTheoreticalWeight * sCartonWeightMultiplier
                sDiffWeight = sActualWeight - sTheoreticalWeight

                'calculate the tolerances based upon theoretical, but subject to a max and min
                If sDiffWeight > 0 Then
                    sUpperTolerance = Convert.ToSingle(gstrWeightToleranceUpperPercent) / 100 * sTheoreticalWeight
                    If sUpperTolerance > Convert.ToString(gstrWeightToleranceUpperMaximum) Then
                        sUpperTolerance = Convert.ToString(gstrWeightToleranceUpperMaximum)
                    ElseIf sUpperTolerance < Convert.ToString(gstrWeightToleranceUpperMinimum) Then
                        sUpperTolerance = Convert.ToString(gstrWeightToleranceUpperMinimum)
                    End If

                    sWgtTol = sUpperTolerance
                 
                Else
                    sLowerTolerance = Convert.ToSingle(gstrWeightToleranceLowerPercent) / 100 * sTheoreticalWeight
                    If sLowerTolerance > Convert.ToString(gstrWeightToleranceLowerMaximum) Then
                        sLowerTolerance = Convert.ToString(gstrWeightToleranceLowerMaximum)
                    ElseIf sLowerTolerance < Convert.ToString(gstrWeightToleranceLowerMinimum) Then
                        sLowerTolerance = Convert.ToString(gstrWeightToleranceLowerMinimum)
                    End If

                    sWgtTol = sLowerTolerance
                 

            End If

                sDiffWeight = Math.Abs(sDiffWeight)

                If sDiffWeight > sWgtTol Then
                    strWgtVal = "FAIL"
                Else
                    strWgtVal = "PASS"
                End If


                strXML = CreateXML_Set_Carton_Information(strSSCC, strStatus, sActualWeight.ToString, strService, _
                        strWgtVal, strWgtValTtyp, sDiffWeight.ToString, sWgtTol)
            End If
            SendRequest(strXML)

            gbNewOutboundData = True   'set the log refresh flag

            bUpdateSuccess = UpdateDBWithCartonAdvanceStep(strSSCC, strToStep)

            If bUpdateSuccess = True Then
                WriteLog("Sent", "Set_Carton_Information " & strSSCC & " to " & strStatus)


            End If

        Catch
        End Try
    End Sub

    Private Sub SSCCCartonAdvance_PickCartonError(ByVal strSSCC As String, ByVal strToStep As String, ByVal strError As String, ByVal strStatus As String)

        Dim strXML As String
        Dim bUpdateSuccess As Boolean

        Try

            strXML = CreateXML_Pick_Carton_Error(strSSCC, strError, strStatus)
            SendRequest(strXML)

            gbNewOutboundData = True   'set the log refresh flag

            bUpdateSuccess = UpdateDBWithCartonAdvanceStep(strSSCC, strToStep)

            If bUpdateSuccess = True Then
                WriteLog("Sent", "Pick_Carton_Error " & strSSCC & " to " & strStatus)

            End If

        Catch
        End Try
    End Sub

    Private Sub SSCCReplenAdvanceLocation(ByVal strSSCC As String, ByVal strLocatn As String, ByVal iOpStep As Integer, ByVal strWH_ID As String)

        Dim strXML As String
        Dim strOpStep As String
        Dim strDestLocatn As String

        Try

            'determine what to do based upon the location step
            If iOpStep >= 9 Then


                Exit Sub '( last step already completed)
            Else

                If iOpStep >= ReplenIntermediateLocationsRecordCount Then
                    'send to final destination
                    strDestLocatn = strLocatn
                    strOpStep = "9"

                Else
                    strOpStep = (iOpStep).ToString  'zero based array - get intermediate location
                    strDestLocatn = ReplenIntermediateLocations(iOpStep)
                    strOpStep = (iOpStep + 1).ToString  'now increment to update 

                End If

            End If

            strXML = CreateXML_Move_Case(strSSCC, strDestLocatn, strWH_ID)
            SendRequest(strXML)

            gbNewOutboundData = True   'set the log refresh flag

            UpdateDBWithReplenStep(strSSCC, strOpStep, strDestLocatn)

        Catch
        End Try
    End Sub
    Public Function UpdateDBWithReplenStep(ByVal strSSCC As String, ByVal strOpStep As String, ByVal strPBL_Locatn As String) As Boolean


        Dim strSql As String

        Try

            strSql = "Update Z_PBL_REPLEN " & _
                    "set stepnumber='" & strOpStep & "', " & _
                    "pbl_locatn='" & strPBL_Locatn & "' " & _
                    " where " & _
                    "SSCC='" & strSSCC & "' "

            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If

            UpdateDBWithReplenStep = True
        Catch
            UpdateDBWithReplenStep = False
            MsgBox("UpdateDBWithReplenStep: " & Err.Description)
            ' WriteLog(gcstrError, "(InsertWaveXMLIntoDB)  Wave: " & RepackWave(1).Wave & Space(2) & Err.Description)
        End Try

    End Function

    Public Function UpdateDBWithPickData(ByVal strSSCC As String, ByVal strItemCode As String, ByVal strQty As String) As Boolean

        Dim strSql As String

        Try

            strSql = "Update Z_PBL_Wave " & _
                    "set picked='" & strQty & "' " & _
                    " where " & _
                    "SSCC='" & strSSCC & "' " & _
                    "and itmcod='" & strItemCode & "' "

            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If


            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If
            UpdateDBWithPickData = True
        Catch
            UpdateDBWithPickData = False
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try

    End Function

    Private Sub DeleteEmulatorDBReplenDataToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteEmulatorDBReplenDataToolStripMenuItem.Click
        DeleteEmulatorDBReplenData()
        GetPBLReplenData()
    End Sub

    Private Sub btnReplenAutoScanOn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReplenAutoScanOn.Click
        chkAutoDataRefresh.Checked = False 'prevent duplicate data retrieves
        cmdRefreshReplen.Enabled = False
        chkAutoRefresh.Checked = True

        'setup the  timer
        tmrReplenScan.Interval = Convert.ToInt32(giReplenAutoScanIntervalSeconds * 1000)
        tmrReplenScan.Enabled = True

        'set auto button colors
        btnReplenAutoScanOn.BackColor = Color.LightGreen
        btnReplenAutoScanOff.BackColor = Color.FromKnownColor(KnownColor.Control)

        'display progress to user
        picWorking.Visible = True
        lblProgStatus.Text = "PBL Auto Replen starts in " & giReplenAutoScanIntervalSeconds & " secs"
        Me.Refresh()
    End Sub

    Private Sub btnReplenAutoScanOff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReplenAutoScanOff.Click
        ReplenAutoScanOff()
    End Sub

    Private Sub ReplenAutoScanOff()
        tmrReplenScan.Enabled = False
        cmdRefreshReplen.Enabled = True
        btnReplenAutoScanOn.BackColor = Color.FromKnownColor(KnownColor.Control)
        btnReplenAutoScanOff.BackColor = Color.Red
        picWorking.Visible = False
    End Sub


    Private Sub tmrReplenScan_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrReplenScan.Tick
        Try

            lblProgStatus.Text = "Replen Auto Scanning"

            ReplenAdvance(False)

        Catch
            ReplenAutoScanOff()
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        Finally


        End Try
    End Sub

    Private Sub GetPBLWavePickingData()
        FillPBLWavePickingData()
        '   DisplayRepackWaveData()   Dave - remarked out 20110629

    End Sub

    Private Sub FillPBLWavePickingData()
        Dim strSQL As String

        Try

            strSQL = "select WAVE ,SSCC, ITMCOD, PICK_QUANTITY, PICKED, LOCATION, WH_ID, UOM, GMS_FLAG, TOT_PICK_WEIGHT " & _
                "from Z_pbl_wave " & _
                "where (picked <> 'Y' or picked is null) " & _
                "order by wave, SSCC, itmcod "

            ' Open the Recordset using the select string:
            dbrec1.Open(strSQL, DBCON1)

            RepackWaveRecordCount = 0
            ReDim RepackWave(0)

            Do Until dbrec1.EOF

                ' Populate the RepackWave array by parsing through the recordset one row at a time:
                RepackWaveRecordCount += 1
                ReDim Preserve RepackWave(RepackWaveRecordCount)

                With RepackWave(RepackWaveRecordCount)
                    .Wave = Convert.ToString(dbrec1.Fields("WAVE").Value)
                    .SSCC = Convert.ToString(dbrec1.Fields("SSCC").Value)
                    .Itmcod = Convert.ToString(dbrec1.Fields("ITMCOD").Value)
                    .Pick_Quantity = Convert.ToString(dbrec1.Fields("PICK_QUANTITY").Value)
                    .PickedQty = Convert.ToString(dbrec1.Fields("PICKED").Value)
                    .Location = Convert.ToString(dbrec1.Fields("LOCATION").Value)
                    .WH_ID = Convert.ToString(dbrec1.Fields("WH_ID").Value)
                    .UOM = Convert.ToString(dbrec1.Fields("UOM").Value)
                    .GMS_FLAG = Convert.ToString(dbrec1.Fields("GMS_FLAG").Value)
                    .TOT_PICK_WEIGHT = Convert.ToString(dbrec1.Fields("TOT_PICK_WEIGHT").Value)

                End With

                dbrec1.MoveNext()

            Loop

            'Close Recordset:
            dbrec1.Close()

        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
            RefreshLog()
        End Try
    End Sub
    Private Sub GetSSCCServicesData()
        FillSSCCServices()
        DisplaySSCCServices()

    End Sub

    Private Sub butGetRepackWaveData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butGetRepackWaveData.Click
        GetPBLWavePickingData()
        GetSSCCServicesData()
    End Sub

    Private Sub TabPage1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage1.Click
        FillSSCCServicesGrouped()
    End Sub

    Private Sub FillSSCCServices()
        Dim strSQL As String
        Dim strStepNumber As String

        strSQL = "select distinct WAVE, SSCC, OpStep " & _
            "from z_pbl_wave " & _
            "order by Wave, SSCC"

        ' Open the Recordset using the select string:
        dbrec1.Open(strSQL, DBCON1)

        SSCCServicesRecordCount = 0
        ReDim SSCCServices(0)

        Do Until dbrec1.EOF

            ' Populate the SSCCServices array by parsing through the recordset one row at a time:
            SSCCServicesRecordCount += 1
            ReDim Preserve SSCCServices(SSCCServicesRecordCount)

            With SSCCServices(SSCCServicesRecordCount)

                .SSCC = Convert.ToString(dbrec1.Fields("SSCC").Value)
                .Wave = Convert.ToString(dbrec1.Fields("WAVE").Value)
                strStepNumber = Convert.ToString(dbrec1.Fields(2).Value)
                If Len(strStepNumber) = 0 Then
                    .OpStep = gcStrZero
                Else
                    .OpStep = strStepNumber
                End If
            End With

            dbrec1.MoveNext()

        Loop

        'Close Recordset:
        dbrec1.Close()

    End Sub



    Private Sub FillSSCCServicesGrouped()
        Dim strSQL As String

        strSQL = "Select OpStep, CountofSSCC from Z_VIEW_SSCCSERVICESGROUPED "

        ' Open the Recordset using the select string:
        dbrec1.Open(strSQL, DBCON1)

        SSCCServicesGroupedRecordCount = 0
        ReDim SSCCServicesGrouped(0)

        Do Until dbrec1.EOF

            ' Populate the SSCCServicesGrouped array by parsing through the recordset one row at a time:
            SSCCServicesGroupedRecordCount += 1
            ReDim Preserve SSCCServicesGrouped(SSCCServicesGroupedRecordCount)

            With SSCCServicesGrouped(SSCCServicesGroupedRecordCount)

                .OpStep = Convert.ToString(dbrec1.Fields("OpStep").Value)
                .CountOfSSCC = Convert.ToString(dbrec1.Fields("CountOfSSCC").Value)

            End With

            dbrec1.MoveNext()

        Loop

        'Close Recordset:
        dbrec1.Close()

    End Sub

    Private Sub DisplaySSCCServices()
        Dim x As Integer
        Dim y As Integer

        flxGrid2.Rows = 1
        flxGrid2.Rows = 2
        flxGrid2.Cols = 5
        flxGrid2.Row = 0
        For y = 1 To flxGrid2.Cols
            flxGrid2.Col = y - 1
            flxGrid2.Text = vbNullString
            Select Case flxGrid2.Col
                Case 0
                    flxGrid2.set_ColWidth(flxGrid2.Col, 350)

                Case 2, 4
                    flxGrid2.set_ColWidth(flxGrid2.Col, 2000)

                Case 3
                    flxGrid2.set_ColWidth(flxGrid2.Col, 600)

                Case 4, 5
                    flxGrid2.set_ColWidth(flxGrid2.Col, 1500)

                Case Else
                    flxGrid2.set_ColWidth(flxGrid2.Col, 1000)
            End Select
        Next

        flxGrid2.Redraw = False

        ' Initialize the Grid by defining the headers:
        flxGrid2.Rows = 2
        flxGrid2.Row = 0
        flxGrid2.Col = 0
        flxGrid2.Text = "Sel"
        flxGrid2.Col = 1
        flxGrid2.Text = "Wave"
        flxGrid2.Col = 2
        flxGrid2.Text = "SSCC"
        flxGrid2.Col = 3
        flxGrid2.Text = "Step"
        flxGrid2.Col = 4
        flxGrid2.Text = "Step Description"


        For x = 1 To SSCCServicesRecordCount

            flxGrid2.Row += 1

            flxGrid2.Col = 1
            flxGrid2.CellBackColor = colorBack
            flxGrid2.CellForeColor = colorFore
            flxGrid2.Text = vbNullString & SSCCServices(x).Wave

            flxGrid2.Col = 2
            flxGrid2.Text = vbNullString & SSCCServices(x).SSCC
            'Highlight the pick step so the user knows to clock on thenm
            Select Case SSCCServices(x).OpStep
                Case "G03", gcstrG04
                    flxGrid2.CellBackColor = Color.Green
                    flxGrid2.CellForeColor = Color.White

                Case Else
                    flxGrid2.CellBackColor = colorBack
                    flxGrid2.CellForeColor = colorFore
            End Select



            flxGrid2.Col = 3
            flxGrid2.CellBackColor = colorBack
            flxGrid2.CellForeColor = colorFore
            flxGrid2.Text = vbNullString & SSCCServices(x).OpStep

            flxGrid2.Col = 4
            flxGrid2.CellBackColor = colorBack
            flxGrid2.CellForeColor = colorFore
            flxGrid2.Text = vbNullString & SSCCServicesDescriptionFromOpStep(SSCCServices(x).OpStep)


            flxGrid2.Rows += 1

        Next

        'remove last blank row
        flxGrid2.Rows -= 1
        flxGrid2.Col = 0
        ' flxGrid2.Sort = flexSortNumericAscending

        flxGrid2.Redraw = True

    End Sub


    Private Sub PickingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PickingToolStripMenuItem.Click
        'ensure sync with ini file
        Call Ini_Main()
        gstrPassIniSection = "Picking"
        Dim formConfig As New frmConfig
        formConfig.ShowDialog()
    End Sub

    Private Sub cmdCartonSelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCartonSelectAll.Click
        ProcessGridSelectAll(flxGrid2)
    End Sub

    Private Sub cmdCartonDeSelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCartonDeSelectAll.Click
        ProcessGridDeSelectAll(flxGrid2)
    End Sub

    Private Sub cmdCartonAdvance_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCartonAdvance.Click

        CartonAdvance(PromptForUserConfirmation, gcstrCartonPathGood)
    End Sub

    Private Sub CartonAdvance(ByVal bUserPrompt As Boolean, ByVal strNextStatus As String)
        Dim x As Integer
        Dim shMsgbox As MsgBoxResult
        Dim strCurrentCartonStep As String
        Dim strSSCC As String
        Dim iLast_Pick As Integer

        Try

            If bUserPrompt = True Then

                shMsgbox = MsgBox("Advance Selected Cartons(s) to Next Step?", MsgBoxStyle.YesNo, "Confirm SSCC Advance")

                If shMsgbox = MsgBoxResult.No Then
                    Exit Sub
                End If
            Else
                GetPBLWavePickingData()
                GetSSCCServicesData()
                ProcessGridSelectAll(flxGrid2)

            End If

            For x = 1 To flxGrid2.Rows - 1
                If flxGrid2.get_TextMatrix(x, 0) = gcstrY Then
                    'do the advance
                    strSSCC = flxGrid2.get_TextMatrix(x, 2)
                    strCurrentCartonStep = flxGrid2.get_TextMatrix(x, 3)
                    SSCCCartonAdvance(strSSCC, strCurrentCartonStep, strNextStatus)
                End If
            Next

            '-- Auto Mode Carton Picking
            If bUserPrompt = False Then
                'in auto - find carton statuses that are either in launched G03 or picking G04

                For x = 1 To flxGrid2.Rows - 1

                    If flxGrid2.get_TextMatrix(x, 0) = gcstrY Then
                        strCurrentCartonStep = flxGrid2.get_TextMatrix(x, 3)
                        If strCurrentCartonStep = "G03" Or strCurrentCartonStep = gcstrG04 Then
                            'available for picking
                            strSSCC = flxGrid2.get_TextMatrix(x, 2)

                            'Display Picks for the selected SSCC
                            DisplayPBLPicking(strSSCC)

                            'now need to max pick all
                            PickSelectAll()

                            'do the picking
                            iLast_Pick = PBL_CheckSingleCartonForAllPicked(strSSCC) 'advance if all picks complete

                            PBL_PerformPicks(iLast_Pick)

                        End If
                    End If
                Next


            End If

        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        Finally

            If bUserPrompt = True Then
                GetSSCCServicesData()
            Else
                GetGraphicalData()
            End If

        End Try
    End Sub

    Private Sub SSCCCartonAdvance(ByVal strSSCC As String, ByVal strOpStep As String, ByVal strNextStepStatus As String)

        Dim bUpdateSuccess As Boolean

        Try

            'determine what to do based upon the Current step
            If Strings.Left(strOpStep, 1) = gcstrCartonPathError Then

                'advance if not at exception station
                If Strings.Right(strOpStep, 2) <> (CartonErrStatusProgressionRecordCount).ToString.PadLeft(2, Convert.ToChar(gcStrZero)) Then
                    'WCS just routes the case to exception (last)station w/o notifying WCS
                    '    strNextStep = gcstrCartonPathError & (CartonErrStatusProgressionRecordCount).ToString.PadLeft(2, Convert.ToChar(gcStrZero))
                    '    bUpdateSuccess = UpdateDBWithCartonAdvanceStep(strSSCC, strNextStep)
                    '    If bUpdateSuccess = True Then
                    '        WriteLog(gcstrProcessed, "Advanced " & strSSCC & " to " & SSCCServicesDescriptionFromOpStep(strNextStep))


                    '    End If
                End If

            Else
                'current status is good

                'added ability for user to force steps into error

                Select Case strOpStep
                    Case gcstrG01
                        If strNextStepStatus = gcstrCartonPathGood And CartonErrStatusProgression(2).UserSelectedErrorRoute = False Then
                            SSCCCartonAdvance_SetCartonInformation(strSSCC, gcstrG02, "RELEASED", String.Empty, String.Empty)
                        Else
                            'Pick_Carton_Error=Error
                            SSCCCartonAdvance_PickCartonError(strSSCC, gcstrE02, "WCS UNABLE TO PROCESS", gcstrError)
                        End If
                    Case gcstrG02
                        If strNextStepStatus = gcstrCartonPathGood Then
                            'set_carton_information=launched
                            SSCCCartonAdvance_SetCartonInformation(strSSCC, "G03", "LAUNCHED", String.Empty, String.Empty)

                        Else
                            'NA
                        End If

                    Case gcstrG03
                        'pick_item - control by pickign process   so send Pick_item
                        If strNextStepStatus = gcstrCartonPathGood Then

                        Else
                            'NA
                        End If

                        'OR  SET_CARTON_STATUS comes back with Pick_Error then send to exception

                    Case gcstrG04
                        'pick_item - control by pickign process   so send Pick_item =last_pick
                        If strNextStepStatus = gcstrCartonPathGood Then

                        Else
                            'NA
                        End If

                        'OR  SET_CARTON_STATUS comes back with exception then send to exception

                    Case gcstrG05
                        If strNextStepStatus = gcstrCartonPathGood Then
                            'SET_CARTON_STATUS received from WMS with Pick_complete

                        Else
                            'SET_CARTON_STATUS received from WMS with exception send to exception
                        End If

                    Case gcstrG06
                        If strNextStepStatus = gcstrCartonPathGood And CartonErrStatusProgression(7).UserSelectedErrorRoute = False Then
                            'SET_CARTON_INFORMATION Pick_complete
                            SSCCCartonAdvance_SetCartonInformation(strSSCC, gcstrG07, "PICK_COMPLETE", GetCartonWeightFromDB(strSSCC), String.Empty)

                        Else
                            'SET_CARTON_INFORMATION Weight Deviation Error
                            SSCCCartonAdvance_SetCartonInformation(strSSCC, gcstrE07, "WEIGHT_DEVIATION_ERROR", String.Empty, String.Empty)
                        End If

                    Case gcstrG07

                        'check to see if carton audit is required
                        If GetCartonAuditFromDB(strSSCC) = 1 Then
                            'audit is required
                            ' SSCCCartonAdvance_SetCartonInformation(strSSCC, "G08", "AUDIT", String.Empty, String.Empty)
                            bUpdateSuccess = UpdateDBWithCartonAdvanceStep(strSSCC, gcstrG08)
                            If bUpdateSuccess = True Then
                                WriteLog(gcstrProcessed, "Advanced " & strSSCC & " to " & SSCCServicesDescriptionFromOpStep(gcstrG08))
                            End If

                        Else

                            'audit is not required
                            If strNextStepStatus = gcstrCartonPathGood Then


                                ProcessGrayMarketScanning(strSSCC)

                                'SET_CARTON_INFORMATION = CARRIER LABEL 
                                SSCCCartonAdvance_SetCartonInformation(strSSCC, gcstrG09, "CARRIER_LABEL", GetCartonWeightFromDB(strSSCC), "MANIFEST")
                            Else
                                'NA
                            End If

                        End If


                   


                    Case gcstrG08
                        If strNextStepStatus = gcstrCartonPathGood Then


                            ProcessGrayMarketScanning(strSSCC)

                            'SET_CARTON_INFORMATION = CARRIER LABELED 
                            SSCCCartonAdvance_SetCartonInformation(strSSCC, gcstrG09, "CARRIER_LABEL", GetCartonWeightFromDB(strSSCC), "MANIFEST")

                        Else
                            'NA
                        End If

                    Case gcstrG09
                        If strNextStepStatus = gcstrCartonPathGood Then
                           Else
                            'NA
                        End If
                    Case gcstrG10
                        'last step


                End Select


            End If


            'Select Case strOpStep



        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)

        End Try
    End Sub

    Private Sub ProcessGrayMarketScanning(ByVal strSSCC As String)
        'Send New message for bournemouth, named SCANNED_GMC_INFORMATION

        Dim iGrayMarketCodesCount As Integer
        Dim strXML As String = String.Empty

        Try
            iGrayMarketCodesCount = GetCartonGMSFromDB(strSSCC)

            If iGrayMarketCodesCount > 0 Then


                strXML = CreateXML_SCANNED_GMC_INFORMATION(strSSCC, iGrayMarketCodesCount)

            End If
            SendRequest(strXML)

            gbNewOutboundData = True   'set the log refresh flag

            WriteLog("Sent", "SCANNED_GMC_INFORMATION for " & strSSCC & " with " & iGrayMarketCodesCount.ToString & " Items")

        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try
    End Sub



    Private Sub DisplayGraphicalSummary()
        Dim x As Integer = 1

        Try

            'need to set all values to zero to initialize
            SetupGraphicalSummary_SetLabelsToZero()

            DisplayErrorRoutingSelections(linE01)
            DisplayErrorRoutingSelections(linE02)
            DisplayErrorRoutingSelections(linE03)
            DisplayErrorRoutingSelections(linE04)
            DisplayErrorRoutingSelections(linE05)
            DisplayErrorRoutingSelections(linE06)
            DisplayErrorRoutingSelections(linE07)
            DisplayErrorRoutingSelections(linE08)
            DisplayErrorRoutingSelections(linE09)
            DisplayErrorRoutingSelections(linE10)





            For x = 1 To SSCCServicesGroupedRecordCount
                With SSCCServicesGrouped(x)

                    Select Case .OpStep     'there has to be a better way!
                        Case "G01"
                            UpdateSSCCGroupedLabel(lblG01, .CountOfSSCC)

                        Case gcstrG02
                            UpdateSSCCGroupedLabel(lblG02, .CountOfSSCC)

                        Case "G03"
                            UpdateSSCCGroupedLabel(lblG03, .CountOfSSCC)

                        Case gcstrG04
                            UpdateSSCCGroupedLabel(lblG04, .CountOfSSCC)

                        Case gcstrG05
                            UpdateSSCCGroupedLabel(lblG05, .CountOfSSCC)

                        Case gcstrG06
                            UpdateSSCCGroupedLabel(lblG06, .CountOfSSCC)

                        Case gcstrG07
                            UpdateSSCCGroupedLabel(lblG07, .CountOfSSCC)

                        Case gcstrG08
                            UpdateSSCCGroupedLabel(lblG08, .CountOfSSCC)

                        Case gcstrG09
                            UpdateSSCCGroupedLabel(lblG09, .CountOfSSCC)

                        Case gcstrG10
                            UpdateSSCCGroupedLabel(lblG10, .CountOfSSCC)

                        Case gcstrE01
                            UpdateSSCCGroupedLabel(lblE01, .CountOfSSCC)

                        Case gcstrE02
                            UpdateSSCCGroupedLabel(lblE02, .CountOfSSCC)

                        Case gcstrE03
                            UpdateSSCCGroupedLabel(lblE03, .CountOfSSCC)

                        Case gcstrE04
                            UpdateSSCCGroupedLabel(lblE04, .CountOfSSCC)

                        Case gcstrE05
                            UpdateSSCCGroupedLabel(lblE05, .CountOfSSCC)

                        Case gcstrE06
                            UpdateSSCCGroupedLabel(lblE06, .CountOfSSCC)

                        Case gcstrE07
                            UpdateSSCCGroupedLabel(lblE07, .CountOfSSCC)

                        Case gcstrE08
                            UpdateSSCCGroupedLabel(lblE08, .CountOfSSCC)

                        Case gcstrE09
                            UpdateSSCCGroupedLabel(lblE09, .CountOfSSCC)

                        Case gcstrE10
                            UpdateSSCCGroupedLabel(lblE10, .CountOfSSCC)

                    End Select
                End With

            Next

        Catch ex As Exception
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try

    End Sub
    Private Sub UpdateSSCCGroupedLabel(ByVal oLabel As Label, ByVal strText As String)
        Dim strPrevText As String

        Try
            strPrevText = oLabel.Tag.ToString
            oLabel.Text = strText

            If strPrevText <> strText Then
                If Strings.Mid(oLabel.Name, 4, 1) = gcstrCartonPathGood Then
                    oLabel.BackColor = Color.LightGreen
                Else
                    oLabel.BackColor = Color.Red

                End If
            Else
                oLabel.BackColor = System.Drawing.SystemColors.GrayText
            End If


        Catch ex As Exception
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try

    End Sub
    Private Sub SetupGraphicalSummary_SetLabelsToZero()
        InitializeSingleSummaryLabel(lblG01)
        InitializeSingleSummaryLabel(lblG02)
        InitializeSingleSummaryLabel(lblG03)
        InitializeSingleSummaryLabel(lblG04)
        InitializeSingleSummaryLabel(lblG05)
        InitializeSingleSummaryLabel(lblG06)
        InitializeSingleSummaryLabel(lblG07)
        InitializeSingleSummaryLabel(lblG08)
        InitializeSingleSummaryLabel(lblG09)
        InitializeSingleSummaryLabel(lblG10)

        InitializeSingleSummaryLabel(lblE01)
        InitializeSingleSummaryLabel(lblE02)
        InitializeSingleSummaryLabel(lblE03)
        InitializeSingleSummaryLabel(lblE04)
        InitializeSingleSummaryLabel(lblE05)
        InitializeSingleSummaryLabel(lblE06)
        InitializeSingleSummaryLabel(lblE07)
        InitializeSingleSummaryLabel(lblE08)
        InitializeSingleSummaryLabel(lblE09)
        InitializeSingleSummaryLabel(lblE10)

    End Sub
    Private Sub InitializeSingleSummaryLabel(ByVal oLabel As Label)
        oLabel.Tag = oLabel.Text   'store last value
        oLabel.Text = gcStrZero
        oLabel.BackColor = System.Drawing.SystemColors.GrayText

    End Sub
    Private Sub SetupGraphicalSummary_Lines(ByVal oPanel As Panel)
        oPanel.ForeColor = Color.Black
        oPanel.BackColor = Color.Black

    End Sub

    Private Sub SetupGraphicalSummary()

        'must be a simpler way  ...but since sontrol arrays no longer exist....

        Dim x As Integer
        Try

            SetupGraphicalSummary_Lines(linE01)
            SetupGraphicalSummary_Lines(linE02)
            SetupGraphicalSummary_Lines(linE03)

            linE04.ForeColor = System.Drawing.SystemColors.GrayText
            linE04.BackColor = System.Drawing.SystemColors.GrayText

            SetupGraphicalSummary_Lines(linE05)

            linE06.ForeColor = System.Drawing.SystemColors.GrayText
            linE06.BackColor = System.Drawing.SystemColors.GrayText

            SetupGraphicalSummary_Lines(linE07)

            SetupGraphicalSummary_Lines(linE08)
            SetupGraphicalSummary_Lines(linE09)

            linE10.ForeColor = System.Drawing.SystemColors.GrayText
            linE10.BackColor = System.Drawing.SystemColors.GrayText


            For x = 1 To CartonOkStatusProgressionRecordCount

                Select Case x
                    Case 1
                        lblG01Title.Text = CartonOkStatusProgression(x).Description
                    Case 2
                        lblG02Title.Text = CartonOkStatusProgression(x).Description
                    Case 3
                        lblG03Title.Text = CartonOkStatusProgression(x).Description
                    Case 4
                        lblG04Title.Text = CartonOkStatusProgression(x).Description
                    Case 5
                        lblG05Title.Text = CartonOkStatusProgression(x).Description
                    Case 6
                        lblG06Title.Text = CartonOkStatusProgression(x).Description
                    Case 7
                        lblG07Title.Text = CartonOkStatusProgression(x).Description
                    Case 8
                        lblG08Title.Text = CartonOkStatusProgression(x).Description
                    Case 9
                        lblG09Title.Text = CartonOkStatusProgression(x).Description
                    Case 10
                        lblG10Title.Text = CartonOkStatusProgression(x).Description
                End Select

            Next

            For x = 1 To CartonErrStatusProgressionRecordCount

                Select Case x
                    Case 1

                        If CartonErrStatusProgression(x).Description = gcstrNA Then
                            lblE01Title.Visible = False
                            linE01.Visible = False
                            lblE01.Visible = False
                        Else
                            lblE01Title.Text = CartonErrStatusProgression(x).Description
                            lblE01Title.Visible = True
                            linE01.Visible = True
                            lblE01.Visible = True
                        End If

                    Case 2
                        If CartonErrStatusProgression(x).Description = gcstrNA Then
                            lblE02Title.Visible = False
                            linE02.Visible = False
                            lblE02.Visible = False
                        Else
                            lblE02Title.Text = CartonErrStatusProgression(x).Description
                            lblE02Title.Visible = True
                            linE02.Visible = True
                            lblE02.Visible = True
                        End If
                    Case 3
                        If CartonErrStatusProgression(x).Description = gcstrNA Then
                            lblE03Title.Visible = False
                            linE03.Visible = False
                            lblE03.Visible = False
                        Else
                            lblE03Title.Text = CartonErrStatusProgression(x).Description
                            lblE03Title.Visible = True
                            linE03.Visible = True
                            lblE03.Visible = True
                        End If
                    Case 4
                        If CartonErrStatusProgression(x).Description = gcstrNA Then
                            lblE04Title.Visible = False
                            linE04.Visible = False
                            lblE04.Visible = False
                        Else
                            lblE04Title.Text = CartonErrStatusProgression(x).Description
                            lblE04Title.Visible = True
                            linE04.Visible = True
                            lblE04.Visible = True
                        End If
                    Case 5
                        If CartonErrStatusProgression(x).Description = gcstrNA Then
                            lblE05Title.Visible = False
                            linE05.Visible = False
                            lblE05.Visible = False
                        Else
                            lblE05Title.Text = CartonErrStatusProgression(x).Description
                            lblE05Title.Visible = True
                            linE05.Visible = True
                            lblE05.Visible = True
                        End If
                    Case 6
                        If CartonErrStatusProgression(x).Description = gcstrNA Then
                            lblE06Title.Visible = False
                            linE06.Visible = False
                            lblE06.Visible = False
                        Else
                            lblE06Title.Text = CartonErrStatusProgression(x).Description
                            lblE06Title.Visible = True
                            linE06.Visible = True
                            lblE06.Visible = True
                        End If
                    Case 7
                        If CartonErrStatusProgression(x).Description = gcstrNA Then
                            lblE07Title.Visible = False
                            linE07.Visible = False
                            lblE07.Visible = False
                        Else
                            lblE07Title.Text = CartonErrStatusProgression(x).Description
                            lblE07Title.Visible = True
                            linE07.Visible = True
                            lblE07.Visible = True
                        End If
                    Case 8
                        If CartonErrStatusProgression(x).Description = gcstrNA Then
                            lblE08Title.Visible = False
                            linE08.Visible = False
                            lblE08.Visible = False
                        Else
                            lblE08Title.Text = CartonErrStatusProgression(x).Description
                            lblE08Title.Visible = True
                            linE08.Visible = True
                            lblE08.Visible = True
                        End If
                    Case 9
                        If CartonErrStatusProgression(x).Description = gcstrNA Then
                            lblE09Title.Visible = False
                            linE09.Visible = False
                            lblE09.Visible = False
                        Else
                            lblE09Title.Text = CartonErrStatusProgression(x).Description
                            lblE09Title.Visible = True
                            linE09.Visible = True
                            lblE09.Visible = True
                        End If
                    Case 10
                        If CartonErrStatusProgression(x).Description = gcstrNA Then
                            lblE10Title.Visible = False
                            linE10.Visible = False
                            lblE10.Visible = False
                        Else
                            lblE10Title.Text = CartonErrStatusProgression(x).Description
                            lblE10Title.Visible = True
                            linE10.Visible = True
                            lblE10.Visible = True
                        End If

                End Select

            Next

        Catch ex As Exception
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try
    End Sub


    Private Sub TabPage3_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabPage3.Enter
        If piTabSelected <> 1 Then

        End If

        piTabSelected = 3
        SetupGraphicalSummary()

        GetGraphicalData()
    End Sub


    Private Sub butGetGraphicalData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butGetGraphicalData.Click
        GetGraphicalData()
    End Sub

    Private Sub GetGraphicalData()
        FillSSCCServicesGrouped()
        DisplayGraphicalSummary()
    End Sub


    Private Sub PickingAutoScanOff()

        tmrPicking.Enabled = False
        grpCartonControl.Enabled = True
        grpPickControl.Enabled = True
        butGetRepackWaveData.Enabled = True

        btnCartonAutoScanOn.BackColor = Color.FromKnownColor(KnownColor.Control)
        btnCartonAutoScanOff.BackColor = Color.Red
        picWorking.Visible = False
    End Sub

    Private Sub cmdCartonAdvanceError_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCartonAdvanceError.Click
        CartonAdvance(PromptForUserConfirmation, gcstrCartonPathError)
    End Sub

    Private Sub DisplayPBLPicking(ByVal strSSCC As String)
        Dim x As Integer
        Dim y As Integer

        flxGrid3.Rows = 1
        flxGrid3.Rows = 2
        flxGrid3.Cols = 10
        flxGrid3.Row = 0
        For y = 1 To flxGrid3.Cols
            flxGrid3.Col = y - 1
            flxGrid3.Text = vbNullString
            Select Case flxGrid3.Col
                Case 1
                    flxGrid3.set_ColWidth(flxGrid3.Col, 2000)

                Case 2, 6
                    flxGrid3.set_ColWidth(flxGrid3.Col, 380)
                Case 8
                    flxGrid3.set_ColWidth(flxGrid3.Col, 500)

                Case 99
                    flxGrid3.set_ColWidth(flxGrid3.Col, 0)


                Case Else
                    flxGrid3.set_ColWidth(flxGrid3.Col, 1000)
            End Select
        Next

        flxGrid3.Redraw = False

        ' Initialize the Grid by defining the headers:
        flxGrid3.Rows = 2
        flxGrid3.Row = 0
        flxGrid3.Col = 0
        flxGrid3.Text = "PckQty"
        flxGrid3.Col = 1
        flxGrid3.Text = "SSCC"
        flxGrid3.Col = 2
        flxGrid3.Text = "UOM"
        flxGrid3.Col = 3
        flxGrid3.Text = "ItemCode"
        flxGrid3.Col = 4
        flxGrid3.Text = "Location"
        flxGrid3.Col = 5
        flxGrid3.Text = "WH_ID"
        flxGrid3.Col = 6
        flxGrid3.Text = "Picked"
        flxGrid3.Col = 7
        flxGrid3.Text = "OrdQty"
        flxGrid3.Col = 8
        flxGrid3.Text = "GMS"
        flxGrid3.Col = 9
        flxGrid3.Text = "TotWgt"

        For x = 1 To RepackWaveRecordCount

            If strSSCC = RepackWave(x).SSCC Then
                flxGrid3.Row += 1

                flxGrid3.Col = 1
                flxGrid3.CellBackColor = colorBack
                flxGrid3.CellForeColor = colorFore
                flxGrid3.Text = vbNullString & RepackWave(x).SSCC

                flxGrid3.Col = 2
                flxGrid3.CellBackColor = colorBack
                flxGrid3.CellForeColor = colorFore
                flxGrid3.Text = vbNullString & RepackWave(x).UOM

                flxGrid3.Col = 3
                flxGrid3.CellBackColor = colorBack
                flxGrid3.CellForeColor = colorFore
                flxGrid3.Text = vbNullString & RepackWave(x).Itmcod

                flxGrid3.Col = 4
                flxGrid3.CellBackColor = colorBack
                flxGrid3.CellForeColor = colorFore
                flxGrid3.Text = vbNullString & RepackWave(x).Location

                flxGrid3.Col = 5
                flxGrid3.CellBackColor = colorBack
                flxGrid3.CellForeColor = colorFore
                flxGrid3.Text = vbNullString & RepackWave(x).WH_ID

                flxGrid3.Col = 6
                flxGrid3.CellBackColor = colorBack
                flxGrid3.CellForeColor = colorFore

                If Strings.Len(Trim(RepackWave(x).PickedQty)) = 0 Then
                    flxGrid3.Text = gcStrZero
                Else
                    flxGrid3.Text = vbNullString & RepackWave(x).PickedQty
                End If
                flxGrid3.Col = 7
                flxGrid3.CellBackColor = colorBack
                flxGrid3.CellForeColor = colorFore
                flxGrid3.Text = vbNullString & RepackWave(x).Pick_Quantity

                flxGrid3.Col = 8
                flxGrid3.CellBackColor = colorBack
                flxGrid3.CellForeColor = colorFore
                flxGrid3.Text = vbNullString & RepackWave(x).GMS_FLAG

                flxGrid3.Col = 9
                flxGrid3.CellBackColor = colorBack
                flxGrid3.CellForeColor = colorFore
                flxGrid3.Text = vbNullString & RepackWave(x).TOT_PICK_WEIGHT

                flxGrid3.Rows += 1
            End If
        Next

        'remove last blank row
        flxGrid3.Rows -= 1
        flxGrid3.Col = 0
        ' flxGrid3.Sort = flexSortNumericAscending

        flxGrid3.Redraw = True

    End Sub

    Private Sub flxGrid2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles flxGrid2.Enter

    End Sub

    Private Sub flxGrid2_MouseDownEvent(ByVal sender As Object, ByVal e As AxMSFlexGridLib.DMSFlexGridEvents_MouseDownEvent) Handles flxGrid2.MouseDownEvent
        Dim strText As String
        Dim iRowSel As Integer
        Dim iColSel As Integer
        Dim strStep As String


        iRowSel = flxGrid2.RowSel
        iColSel = flxGrid2.MouseCol

        'first row is header row
        If iRowSel = 0 Then Exit Sub

        strText = Trim(flxGrid2.get_TextMatrix(iRowSel, 2))
        strStep = Trim(flxGrid2.get_TextMatrix(iRowSel, 3))

        If strStep = "G03" Or strStep = gcstrG04 Then     'only allow pickign when in pickign steps
            grpPickControl.Enabled = True
        Else
            grpPickControl.Enabled = False
        End If

        If iColSel = 2 Then
            'Filter the unpicked array by the selected SSCC
            DisplayPBLPicking(strText)
        Else

            ProcessGridMouseDown(flxGrid2, e.button)
        End If
    End Sub

    Private Sub butPBLPick_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butPBLPick.Click
        Dim strSSCC As String
        Dim iLast_Pick As Integer
        Try

            If flxGrid3.Rows <= 1 Then

                MessageBox.Show("No Data to Pick", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If

            strSSCC = flxGrid3.get_TextMatrix(1, 1) ' current SSCC

            iLast_Pick = PBL_CheckSingleCartonForAllPicked(strSSCC) 'advance if all picks complete

            PBL_PerformPicks(iLast_Pick)

            GetPBLWavePickingData()
            GetSSCCServicesData()
            DisplayPBLPicking(strSSCC)

        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try
    End Sub

    Private Function PBL_CheckSingleCartonForAllPicked(ByVal strSSCC As String) As Integer

        Dim x As Integer
        Dim iLastRowSelectedforPick As Integer = -1

        PBL_CheckSingleCartonForAllPicked = -1
        Dim bQtyMatch As Boolean = True

        Dim iToPickQty As Integer
        Dim iOrderedQty As Integer
        Dim iPreviouslyPickedQty As Integer

        Try
            For x = 1 To flxGrid3.Rows - 1

                If Len(Trim(flxGrid3.get_TextMatrix(x, 0))) = 0 Then
                    iToPickQty = 0
                Else
                    iToPickQty = CInt(Trim(flxGrid3.get_TextMatrix(x, 0)))
                End If

                If Len(Trim(flxGrid3.get_TextMatrix(x, 6))) = 0 Then
                    iPreviouslyPickedQty = 0
                Else
                    iPreviouslyPickedQty = CInt(Trim(flxGrid3.get_TextMatrix(x, 6)))

                End If

                If Len(Trim(flxGrid3.get_TextMatrix(x, 7))) = 0 Then
                    iOrderedQty = 0
                Else
                    iOrderedQty = CInt(Trim(flxGrid3.get_TextMatrix(x, 7)))
                End If

                If iToPickQty + iPreviouslyPickedQty >= iOrderedQty Then


                Else
                    bQtyMatch = False

                End If
            Next

            If bQtyMatch = True Then
                UpdateDBWithCartonAdvanceStep(strSSCC, gcstrG05)  ' dave shoudl just index this versus hardcoding
                For x = 1 To flxGrid3.Rows - 1
                    If Len(Trim(flxGrid3.get_TextMatrix(x, 0))) > 0 Then
                        iLastRowSelectedforPick = x
                    End If
                Next

                PBL_CheckSingleCartonForAllPicked = iLastRowSelectedforPick
            Else
                UpdateDBWithCartonAdvanceStep(strSSCC, gcstrG04)  'in picking
            End If
        Catch

            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try
    End Function


    Private Sub flxGrid3_MouseDownEvent(ByVal sender As Object, ByVal e As AxMSFlexGridLib.DMSFlexGridEvents_MouseDownEvent) Handles flxGrid3.MouseDownEvent
        Dim strText As String
        Dim iRowSel As Integer
        Dim iColSel As Integer
        Static iSort As Integer
        Dim strUserQty As String
        Dim iOrderQty As Integer
        Dim iAlreadyPickedQty As Integer

        iRowSel = flxGrid3.MouseRow
        iColSel = flxGrid3.MouseCol

        If iSort = 0 Then
            iSort = 1
        End If

        'first row is header row sort on it
        If iRowSel = 0 Then
            flxGrid3.Col = iColSel
            If iSort = -1 Then
                flxGrid3.Sort = 8   'string descending
            Else
                flxGrid3.Sort = 7   'string ascending
            End If
            iSort *= -1
            Exit Sub
        End If


        strText = Trim(flxGrid3.get_TextMatrix(iRowSel, 0))
        If e.button = 2 Then
            'Save to clipboard 
            Clipboard.SetDataObject(strText)
        Else
            iAlreadyPickedQty = CInt(Trim(flxGrid3.get_TextMatrix(iRowSel, 6)))
            iOrderQty = CInt(Trim(flxGrid3.get_TextMatrix(iRowSel, 7)))

            'don;t default to a negative valeu if oevrpicked
            strUserQty = InputBox("Pick Qty:", "Enter Pick Qty", Math.Max((iOrderQty - iAlreadyPickedQty), 0).ToString)
            flxGrid3.set_TextMatrix(iRowSel, 0, strUserQty)

        End If
    End Sub

    Private Sub PBL_PerformPicks(ByVal iLast_Pick As Integer)
        Dim x As Integer
        Dim strQtyToPick As String = gcStrZero
        Dim strXML As String

        flxGrid3.Col = 0

        'summary data
        Dim iItemPicks As Integer = 0

        Dim clrOriginal As Color
        Dim strPikMsg As String
        Dim strItemCode As String = String.Empty
        Dim strSSCC As String = String.Empty
        Dim strQtyAlreadyPicked As String
        Dim strService As String = String.Empty
        Dim strWH_ID As String = String.Empty
        Dim strUOM As String = String.Empty
        Dim strLocation As String = String.Empty

        Try

            clrOriginal = grpPickControl.BackColor
            grpPickControl.BackColor = Color.Green
            grpPickControl.Refresh()
            For x = 1 To flxGrid3.Rows - 1

                If x = iLast_Pick Then              'this was a total pain in the butt due to bad design requirements
                    strService = "LAST_PICK"
                Else

                    strService = String.Empty

                End If

                strQtyToPick = flxGrid3.get_TextMatrix(x, 0)
                strSSCC = flxGrid3.get_TextMatrix(x, 1)
                strUOM = flxGrid3.get_TextMatrix(x, 2)
                strItemCode = flxGrid3.get_TextMatrix(x, 3)
                strLocation = flxGrid3.get_TextMatrix(x, 4)
                strWH_ID = flxGrid3.get_TextMatrix(x, 5)
                strQtyAlreadyPicked = flxGrid3.get_TextMatrix(x, 6)


                If Strings.Len(strQtyToPick) > 0 And Strings.Len(strQtyAlreadyPicked) > 0 Then
                    'perform a pick


                    'update the database with item pick qty
                    UpdateDBWithPickData(strSSCC, strItemCode, (CInt(strQtyToPick) + CInt(strQtyAlreadyPicked)).ToString)

                    'send the item pick for SSCC xml message
                    strXML = CreateXML_Pick_Item(strSSCC, strItemCode, strLocation, strWH_ID, strUOM, strQtyToPick, strService, gstrPickingUser_Id)

                    SendRequest(strXML)

                    iItemPicks += 1


                    If chkDelayPick.Checked = True Then
                        If IsNumeric(txtDelayPick.Text) Then
                            Threading.Thread.Sleep(Convert.ToInt16(txtDelayPick.Text))
                        End If
                    End If

                End If

            Next

            strPikMsg = strItemCode & " Qty: " & strQtyToPick & " for SSCC: " & strSSCC

            WriteLog("Pick Item", strPikMsg)
        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        Finally
            grpPickControl.BackColor = clrOriginal
        End Try
    End Sub

    Private Sub butPickSelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butPickSelectAll.Click
        PickSelectAll()
    End Sub
    Private Sub PickSelectAll()
        Dim x As Integer
        Dim strQty As String
        Dim iOrderQty As Integer
        Dim iAlreadyPickedQty As Integer
        Dim strOrderQty As String = String.Empty
        Dim strAlreadyPickedQty As String = String.Empty

        Try

            'set the pick qty to the expected pick qty 
            For x = 1 To flxGrid3.Rows - 1
                If flxGrid3.Cols < 6 Then

                    MessageBox.Show("No Picking Data to Select", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
                strAlreadyPickedQty = Trim(flxGrid3.get_TextMatrix(x, 6))

                If Strings.Len(strAlreadyPickedQty) > 0 Then            'ensure no cint errs on nulls
                    iAlreadyPickedQty = CInt(strAlreadyPickedQty)
                    strOrderQty = Trim(flxGrid3.get_TextMatrix(x, 7))

                    If Strings.Len(strOrderQty) > 0 Then

                        iOrderQty = CInt(strOrderQty)

                        strQty = (iOrderQty - iAlreadyPickedQty).ToString
                        flxGrid3.set_TextMatrix(x, 0, strQty)
                    End If
                End If
            Next

        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try

    End Sub

    Private Sub butPickDeSelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butPickDeSelectAll.Click
        Dim x As Integer
        Dim strQty As String

        'set the pick qty to the expected pick qty 
        For x = 1 To flxGrid3.Rows - 1
            strQty = String.Empty
            flxGrid3.set_TextMatrix(x, 0, strQty)
        Next
    End Sub

    Private Sub tmrPicking_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrPicking.Tick
        Dim iRandomError As Integer
        Try

            lblProgStatus.Text = "PBL Auto Pick"

            If gstrPickingAutoScanErrorPercent = gcStrZero Then
                CartonAdvance(False, gcstrCartonPathGood)
            Else

                iRandomError = RandomNumber(1, 100)
                If iRandomError <= CInt(gstrPickingAutoScanErrorPercent) Then
                    CartonAdvance(False, gcstrCartonPathError)
                Else
                    CartonAdvance(False, gcstrCartonPathGood)
                End If

            End If

        Catch
            PickingAutoScanOff()
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        Finally

        End Try
    End Sub


    Private Sub btnCartonAutoScanOn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCartonAutoScanOn.Click
        chkAutoDataRefresh.Checked = False 'prevent duplicate data retrieves
        grpCartonControl.Enabled = False
        grpPickControl.Enabled = False
        butGetRepackWaveData.Enabled = False

        chkAutoRefresh.Checked = True

        'setup the  timer
        tmrPicking.Interval = Convert.ToInt32(giPickingAutoScanIntervalSeconds * 1000)
        tmrPicking.Enabled = True

        'set auto button colors
        btnCartonAutoScanOn.BackColor = Color.LightGreen
        btnCartonAutoScanOff.BackColor = Color.FromKnownColor(KnownColor.Control)

        'display progress to user
        picWorking.Visible = True
        lblProgStatus.Text = "PBL Operation starts in " & giPickingAutoScanIntervalSeconds & " secs"
        Me.Refresh()
    End Sub

    Private Sub btnCartonAutoScanOff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCartonAutoScanOff.Click
        PickingAutoScanOff()
    End Sub

    Private Sub DeleteEmulatorPBLDataToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteEmulatorPBLDataToolStripMenuItem.Click
        DeleteEmulatorDBPBLWave()
        GetPBLWavePickingData()
        GetSSCCServicesData()
    End Sub





  

    Private Sub XMLEditorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles XMLEditorToolStripMenuItem.Click
        Dim formXMLEditor As New frmXMLEditor
        formXMLEditor.Show()
    End Sub

    Private Sub PositionFormatStartup()
        Dim iOffset As Integer
        Dim workingRectangle As System.Drawing.Rectangle = Screen.PrimaryScreen.WorkingArea

        ' Set the size of the form slightly less than size of rectangle.  the working area does not include the task bar
        Me.Size = New System.Drawing.Size(workingRectangle.Width - iOffset, workingRectangle.Height - iOffset)

        ' Set the location so the entire form is visible.
        Me.Location = New System.Drawing.Point(iOffset, iOffset)

    End Sub

    Private Sub linE01_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linE01.Click
        Dim oPanel As Panel
        oPanel = CType(sender, Panel)
        ProcessErrorLineSelection(oPanel)
    End Sub

    Private Sub DisplayErrorRoutingSelections(ByVal oPanel As Panel)

        Dim ArrayIndex As Integer

        ArrayIndex = CInt(Strings.Right(oPanel.Name, 2))


        If oPanel.BackColor = System.Drawing.SystemColors.GrayText Then Exit Sub

        If CartonErrStatusProgression(ArrayIndex).UserSelectedErrorRoute = True Then

            oPanel.BackColor = Color.Red
            oPanel.ForeColor = Color.Red
        Else
            oPanel.BackColor = Color.Black
            oPanel.ForeColor = Color.Black
        End If
    End Sub

    Private Sub ProcessErrorLineSelection(ByVal oPanel As Panel)
        Dim ErrorRouteChosen As Boolean
        Dim ArrayIndex As Integer

        ArrayIndex = CInt(Strings.Right(oPanel.Name, 2))

        'toggle the state color selection
        If oPanel.ForeColor = Color.Black Then
            oPanel.BackColor = Color.Red
            oPanel.ForeColor = Color.Red
            ErrorRouteChosen = True
        ElseIf oPanel.ForeColor = Color.Red Then
            oPanel.BackColor = Color.Black
            oPanel.ForeColor = Color.Black
            ErrorRouteChosen = False
        Else
            'don't do anything
            Exit Sub
        End If

        'udpate the user selection to use later in SSCC advance processing

        CartonErrStatusProgression(ArrayIndex).UserSelectedErrorRoute = ErrorRouteChosen

    End Sub

    Private Sub linE02_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linE02.Click
        Dim oPanel As Panel
        oPanel = CType(sender, Panel)
        ProcessErrorLineSelection(oPanel)
    End Sub

    Private Sub linE03_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linE03.Click
        Dim oPanel As Panel
        oPanel = CType(sender, Panel)
        ProcessErrorLineSelection(oPanel)
    End Sub

    Private Sub linE04_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linE04.Click
        Dim oPanel As Panel
        oPanel = CType(sender, Panel)
        ProcessErrorLineSelection(oPanel)
    End Sub

    Private Sub linE05_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linE05.Click
        Dim oPanel As Panel
        oPanel = CType(sender, Panel)
        ProcessErrorLineSelection(oPanel)
    End Sub

    Private Sub linE06_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linE06.Click
        Dim oPanel As Panel
        oPanel = CType(sender, Panel)
        ProcessErrorLineSelection(oPanel)
    End Sub

    Private Sub linE07_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linE07.Click
        Dim oPanel As Panel
        oPanel = CType(sender, Panel)
        ProcessErrorLineSelection(oPanel)
    End Sub

    Private Sub linE08_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linE08.Click
        Dim oPanel As Panel
        oPanel = CType(sender, Panel)
        ProcessErrorLineSelection(oPanel)
    End Sub

    Private Sub linE09_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linE09.Click
        Dim oPanel As Panel
        oPanel = CType(sender, Panel)
        ProcessErrorLineSelection(oPanel)
    End Sub

    Private Sub linE10_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linE10.Click
        Dim oPanel As Panel
        oPanel = CType(sender, Panel)
        ProcessErrorLineSelection(oPanel)
    End Sub


    Private Sub butMoveErrorsToLastStep_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butMoveErrorsToLastStep.Click
        'UpdateDBMoveAllErrorCartonsToLastErrorStep()
        DeleteSSCCsinDbLastStep()
        GetGraphicalData()
    End Sub


    Private Sub DeleteEmulatorDBLocationStatusDataToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteEmulatorDBLocationStatusDataToolStripMenuItem.Click
        DeleteEmulatorDBLocationData()
    End Sub


    Private Sub FillLocation()
        Dim strSQL As String

        strSQL = "select WH_ID, LOCATION, STATUS, REASON, CTRL_DATE " & _
            "from z_PBL_LOCATION " & _
            "order by CTRL_DATE desc"

        ' Open the Recordset using the select string:
        dbrec1.Open(strSQL, DBCON1)

        PBLLocationRecordCount = 0
        ReDim PBLLocation(0)

        Do Until dbrec1.EOF

            ' Populate the Location array by parsing through the recordset one row at a time:
            PBLLocationRecordCount += 1
            ReDim Preserve PBLLocation(PBLLocationRecordCount)

            With PBLLocation(PBLLocationRecordCount)

                .Location = Convert.ToString(dbrec1.Fields("LOCATION").Value)
                .WH_ID = Convert.ToString(dbrec1.Fields("WH_ID").Value)
                .Status = Convert.ToString(dbrec1.Fields("STATUS").Value)
                .Reason = Convert.ToString(dbrec1.Fields("REASON").Value)
                .Ctrl_Date = Convert.ToString(dbrec1.Fields("CTRL_DATE").Value)

            End With

            dbrec1.MoveNext()

        Loop

        'Close Recordset:
        dbrec1.Close()

    End Sub
    Private Function GetCartonWeightFromDB(ByVal strSSCC As String) As String
        Dim strSQL As String
        Try


            GetCartonWeightFromDB = 0

            strSQL = "select sumofWEIGHT " & _
                "from Z_VIEW_SSCCSUMMARY " & _
                "where SSCC='" & strSSCC & "' "

            ' Open the Recordset using the select string:
            dbrec1.Open(strSQL, DBCON1)



            Do Until dbrec1.EOF

                GetCartonWeightFromDB = Convert.ToString(dbrec1.Fields("SUMOFWEIGHT").Value)

                dbrec1.MoveNext()

            Loop

            'Close Recordset:
            dbrec1.Close()

        Catch
            GetCartonWeightFromDB = 0
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try
    End Function
    Private Function GetCartonWgtValTypFromDB(ByVal strSSCC As String) As String
        Dim strSQL As String
        Try


            GetCartonWgtValTypFromDB = 0

            strSQL = "select Carrier_Type, Business " & _
                "from Z_PBL_WAVE " & _
                "where SSCC='" & strSSCC & "' "

            ' Open the Recordset using the select string:
            dbrec1.Open(strSQL, DBCON1)



            Do Until dbrec1.EOF

                GetCartonWgtValTypFromDB = Convert.ToString(dbrec1.Fields("CARRIER_TYPE").Value) & "-" & _
                    Convert.ToString(dbrec1.Fields("BUSINESS").Value)

                dbrec1.MoveNext()

                Exit Do
                'since storing flat just need to get the first record as all records shoudl ahve same business/carrier type

            Loop

            'Close Recordset:
            dbrec1.Close()

        Catch
            GetCartonWgtValTypFromDB = 0
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try
    End Function
    Private Function GetCartonGMSFromDB(ByVal strSSCC As String) As String
        Dim strSQL As String
        Try


            GetCartonGMSFromDB = 0

            strSQL = "select itmcod  " & _
                "from Z_PBL_WAVE " & _
                "where SSCC='" & strSSCC & "' and GMS_FLAG='1'"

            ' Open the Recordset using the select string:
            dbrec1.Open(strSQL, DBCON1)



            Do Until dbrec1.EOF

                GetCartonGMSFromDB += 1

                dbrec1.MoveNext()

            Loop

            'Close Recordset:
            dbrec1.Close()

        Catch
            GetCartonGMSFromDB = 0
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try
    End Function

    Private Function GetCartonAuditFromDB(ByVal strSSCC As String) As String
        Dim strSQL As String
        Dim strCarton As String = String.Empty
        Try

            GetCartonAuditFromDB = 0

            strSQL = "select SSCC " & _
                "from Z_PBL_SERVICE " & _
                "where SSCC='" & strSSCC & "' and service='AUDIT' and SERVICE_STATUS<>'C'"

            ' Open the Recordset using the select string:
            dbrec1.Open(strSQL, DBCON1)

            Do Until dbrec1.EOF

                strCarton = Convert.ToString(dbrec1.Fields("SSCC").Value)

                dbrec1.MoveNext()

            Loop


            'Close Recordset:
            dbrec1.Close()

            If strCarton.Length > 0 Then GetCartonAuditFromDB = 1

        Catch
            GetCartonAuditFromDB = 0
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
        End Try
    End Function
    Private Sub DisplayLocationArray()
        Dim x As Integer
        Dim y As Integer

        Try
            flxGrid4.Rows = 1
            flxGrid4.Rows = 2
            flxGrid4.Cols = 6
            flxGrid4.Row = 0
            For y = 1 To flxGrid4.Cols
                flxGrid4.Col = y - 1
                flxGrid4.Text = vbNullString

                Select Case flxGrid4.Col

                    Case 0
                        flxGrid4.set_ColWidth(flxGrid4.Col, 500)

                    Case 1
                        flxGrid4.set_ColWidth(flxGrid4.Col, 2000)

                    Case Else
                        flxGrid4.set_ColWidth(flxGrid4.Col, 1000)

                End Select

            Next

            flxGrid4.Redraw = False

            ' Initialize the Grid by defining the headers:
            flxGrid4.Rows = 2
            flxGrid4.Row = 0

            flxGrid4.Col = 0
            flxGrid4.Text = "Sel"
            flxGrid4.Col = 1
            flxGrid4.Text = "Ctrl_Date"
            flxGrid4.Col = 2
            flxGrid4.Text = "WH_ID"
            flxGrid4.Col = 3
            flxGrid4.Text = "Location"
            flxGrid4.Col = 4
            flxGrid4.Text = "Status"
            flxGrid4.Col = 5
            flxGrid4.Text = "Reason"

            For x = 1 To PBLLocationRecordCount

                flxGrid4.Row += 1

                flxGrid4.Col = 1
                flxGrid4.CellBackColor = colorBack
                flxGrid4.CellForeColor = colorFore
                flxGrid4.Text = vbNullString & PBLLocation(x).Ctrl_Date

                flxGrid4.Col = 2
                flxGrid4.CellBackColor = colorBack
                flxGrid4.CellForeColor = colorFore
                flxGrid4.Text = vbNullString & PBLLocation(x).WH_ID

                flxGrid4.Col = 3
                flxGrid4.CellBackColor = colorBack
                flxGrid4.CellForeColor = colorFore
                flxGrid4.Text = vbNullString & PBLLocation(x).Location

                flxGrid4.Col = 4
                flxGrid4.CellBackColor = colorBack
                flxGrid4.CellForeColor = colorFore
                flxGrid4.Text = vbNullString & PBLLocation(x).Status

                flxGrid4.Col = 5
                flxGrid4.CellBackColor = colorBack
                flxGrid4.CellForeColor = colorFore
                flxGrid4.Text = vbNullString & PBLLocation(x).Reason

                flxGrid4.Rows += 1

            Next


            'remove last blank row
            flxGrid4.Rows -= 1
            flxGrid4.Col = 0
            ' flxGrid4.Sort = flexSortNumericAscending
        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
            RefreshLog()
        Finally

            flxGrid4.Redraw = True

        End Try
    End Sub

    Private Sub butGetLocationStatusData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butGetLocationStatusData.Click
        FillLocation()
        DisplayLocationArray()
    End Sub


    Private Sub flxGrid4_MouseDownEvent(ByVal sender As Object, ByVal e As AxMSFlexGridLib.DMSFlexGridEvents_MouseDownEvent) Handles flxGrid4.MouseDownEvent
        ProcessGridMouseDown(CType(sender, AxMSFlexGrid), e.button)
    End Sub


    Private Sub SearchLogToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchLogToolStripMenuItem.Click
        Dim UserSearchText As String = String.Empty

        UserSearchText = InputBox("Search Text:", "Specify Case Sensitive Search Text", String.Empty)

        If Len(UserSearchText) > 0 Then
            SearchLog(UserSearchText, Color.Green)
        End If

    End Sub

    Private Sub RemoveAToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveAToolStripMenuItem.Click
        DeleteEmulatorDBReplenData()
        DeleteEmulatorDBLocationData()
        DeleteEmulatorDBPBLWave()
        DeleteEmulatorDBIgnoreErrorData()
    End Sub

    Private Sub PromptForUserConfirmationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PromptForUserConfirmationToolStripMenuItem.Click
        If PromptForUserConfirmationToolStripMenuItem.Checked = True Then
            PromptForUserConfirmation = True

        Else
            PromptForUserConfirmation = False


        End If
    End Sub

    Private Sub SendHeartbeatAutomaticallyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SendHeartbeatAutomaticallyToolStripMenuItem.Click
        If SendHeartbeatAutomaticallyToolStripMenuItem.Checked = True Then
            SendHeartbeatAutomatically = True
            ToolStripStatusLabelHeartBeatOn.Visible = True
            SendHeartbeat()

        Else
            SendHeartbeatAutomatically = False
            ToolStripStatusLabelHeartBeatOn.Visible = False


        End If
    End Sub

    Private Sub tmrHeartbeat_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrHeartbeat.Tick
        tmrHeartbeat.Interval = giAutoHeartBeatSendIntervalMilliSeconds

        If SendHeartbeatAutomatically = True Then
            SendHeartbeat()
        End If
    End Sub


    Private Sub butGetIgnore_ErrorData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butGetIgnore_ErrorData.Click
        FillIgnoreError()
        DisplayIgnoreErrorArray()
    End Sub

    Private Sub FillIgnoreError()
        Dim strSQL As String

        strSQL = "select SSCC, ERROR_CODE, CTRL_DATE " & _
            "from z_PBL_IGNORE_ERROR " & _
            "order by CTRL_DATE desc"

        ' Open the Recordset using the select string:
        dbrec1.Open(strSQL, DBCON1)

        IgnoredErrorsRecordCount = 0
        ReDim IgnoredErrors(0)

        Do Until dbrec1.EOF

            ' Populate the Location array by parsing through the recordset one row at a time:
            IgnoredErrorsRecordCount += 1
            ReDim Preserve IgnoredErrors(IgnoredErrorsRecordCount)

            With IgnoredErrors(IgnoredErrorsRecordCount)

                .SSCC = Convert.ToString(dbrec1.Fields("SSCC").Value)
                .ERROR_CODE = Convert.ToString(dbrec1.Fields("ERROR_CODE").Value)
                .CTRL_DATE = Convert.ToString(dbrec1.Fields("CTRL_DATE").Value)
            End With

            dbrec1.MoveNext()

        Loop

        'Close Recordset:
        dbrec1.Close()

    End Sub

    Private Sub DisplayIgnoreErrorArray()
        Dim x As Integer
        Dim y As Integer

        Try
            flxGrid5.Rows = 1
            flxGrid5.Rows = 2
            flxGrid5.Cols = 4
            flxGrid5.Row = 0
            For y = 1 To flxGrid5.Cols
                flxGrid5.Col = y - 1
                flxGrid5.Text = vbNullString

                Select Case flxGrid5.Col

                    Case 0
                        flxGrid5.set_ColWidth(flxGrid5.Col, 500)

                    Case 1
                        flxGrid5.set_ColWidth(flxGrid5.Col, 2000)

                    Case Else
                        flxGrid5.set_ColWidth(flxGrid5.Col, 2000)

                End Select

            Next

            flxGrid5.Redraw = False

            ' Initialize the Grid by defining the headers:
            flxGrid5.Rows = 2
            flxGrid5.Row = 0

            flxGrid5.Col = 0
            flxGrid5.Text = "Sel"
            flxGrid5.Col = 1
            flxGrid5.Text = "Ctrl_Date"
            flxGrid5.Col = 2
            flxGrid5.Text = "CSSN"
            flxGrid5.Col = 3
            flxGrid5.Text = "ERROR_CODE"


            For x = 1 To IgnoredErrorsRecordCount

                flxGrid5.Row += 1

                flxGrid5.Col = 1
                flxGrid5.CellBackColor = colorBack
                flxGrid5.CellForeColor = colorFore
                flxGrid5.Text = vbNullString & IgnoredErrors(x).CTRL_DATE

                flxGrid5.Col = 2
                flxGrid5.CellBackColor = colorBack
                flxGrid5.CellForeColor = colorFore
                flxGrid5.Text = vbNullString & IgnoredErrors(x).SSCC

                flxGrid5.Col = 3
                flxGrid5.CellBackColor = colorBack
                flxGrid5.CellForeColor = colorFore
                flxGrid5.Text = vbNullString & IgnoredErrors(x).ERROR_CODE

                flxGrid5.Rows += 1

            Next


            'remove last blank row
            flxGrid5.Rows -= 1
            flxGrid5.Col = 0
            ' flxGrid5.Sort = flexSortNumericAscending
        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
            RefreshLog()
        Finally

            flxGrid5.Redraw = True

        End Try
    End Sub

    Private Sub DeleteEmulatorDBIgnoreErrorDataToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteEmulatorDBIgnoreErrorDataToolStripMenuItem.Click
        DeleteEmulatorDBIgnoreErrorData()
    End Sub
    Private Sub DeleteEmulatorDBIgnoreErrorData()
        Dim strSQL As String
        Dim iMsgResult As DialogResult

        Try

            iMsgResult = MessageBox.Show("Ok to Delete Ignore Error Data?", "Confirm Emulator Data Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
            If iMsgResult = Windows.Forms.DialogResult.No Then Exit Sub

            strSQL = "delete from Z_PBL_IGNORE_ERROR "

            DBCON1.Execute(strSQL)

            WriteLog("Success", GetCurrentMethod.Name)

        Catch
            WriteLog(gcstrError, GetCurrentMethod.Name() & Space(1) & Err.Description)
            RefreshLog()

        Finally

        End Try

    End Sub

    Private Sub SocketListeningPortsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SocketListeningPortsToolStripMenuItem.Click
        'ensure sync with ini file
        Call Ini_Main()
        gstrPassIniSection = "SocketListeningPorts"
        Dim formConfig As New frmConfig
        formConfig.ShowDialog()
    End Sub
End Class
