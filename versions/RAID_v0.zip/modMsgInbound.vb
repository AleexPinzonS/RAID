Option Explicit On
Option Strict On

Imports System
Imports System.IO
Imports System.Xml
Imports System.Xml.Schema


Module modMsgInbound
    '$PROBHIDE NOT_READ
    Public Structure Confirm_Heartbeat

        Dim HDR_SESSIONKEY As String
        Dim HDR_MESSAGEID As String
        Dim HDR_TIMESTAMP As String

        Dim strText As String
    End Structure

    Public Structure MessageHeader
        Dim WCS_ID As String
        Dim Message_Id As String
        Dim TimeStamp As String
    End Structure

    Public Structure Set_Carton_Status

        Dim HDR_SESSIONKEY As String
        Dim HDR_MESSAGEID As String
        Dim HDR_TIMESTAMP As String

        Dim strSSCC As String
        Dim strStatus As String

    End Structure

    Public Structure Set_Location_Status

        Dim HDR_SESSIONKEY As String
        Dim HDR_MESSAGEID As String
        Dim HDR_TIMESTAMP As String

        Dim strLocation As String
        Dim strWH_ID As String
        Dim strStatus As String
        Dim strReason As String

    End Structure
 

    Public NotInheritable Class XMLReadIt

        Public Sub ParseXML(ByVal strData As String)
            Dim XMLContext As New XmlParserContext(Nothing, Nothing, String.Empty, XmlSpace.None, System.Text.Encoding.UTF8)
            Dim reader As New XmlTextReader(strData, XmlNodeType.Document, XMLContext)


            Dim strCSSN As String

            Try
                Dim x As Integer
                Dim strSSCC As String

                Dim strOK As String

                gbNewInboundData = True

                If Len(gstrXSDFileName) > 0 And gstrXSDFileName <> "NA" Then
                    'verify the XML against a XSD

                    'Create the XmlSchemaSet class.
                    Dim sc As XmlSchemaSet = New XmlSchemaSet()

                    ' Add the schema to the collection.
                    sc.Add(Nothing, My.Application.Info.DirectoryPath & "\" & gstrXSDFileName)

                    ' Set the validation settings.
                    Dim settings As XmlReaderSettings = New XmlReaderSettings()
                    settings.ValidationType = ValidationType.Schema
                    settings.Schemas = sc
                    AddHandler settings.ValidationEventHandler, AddressOf ValidationCallBack

                    ' Create the XmlReader object.
                    Dim parsereader As System.Xml.XmlReader = System.Xml.XmlReader.Create(New System.IO.StringReader(strData), settings)

                    ' Parse the file. 
                    'this just validatres if the XML matches the XSD specification
                    'errors trigger the ValidationCallBack routine
                    While parsereader.Read()
                    End While
                End If

                'use the XML Text Reader

                'Disable whitespace so that you don't have to read over whitespaces
                reader.WhitespaceHandling = WhitespaceHandling.None

                'read the xml declaration and advance to root tag
                reader.Read()


                If Strings.InStr(reader.Name.ToUpper, "XML") > 0 Then
                    'if this line is the xml declaration then need to read another line
                    'read the root tag
                    reader.Read()
                    'reader.ReadString()
                Else
                    'no xml declaration, we have the root tag
                End If

                'determine what the xml is and route to its routine
                Select Case reader.Name.ToUpper

                    Case "Confirm_HeartBeat".ToUpper
                        Dim structXML As Confirm_Heartbeat
                        structXML = ReadXML_Confirm_Heartbeat(reader)

                        WriteLog(gcstrProcessed, "Heartbeat Message = " & structXML.strText)

                    Case "Request_Case_Move".ToUpper

                        strOK = ReadXML_Request_Case_Move(reader)

                        If strOK <> "-1" Then
                            For x = 1 To RequestCaseMoveRecordCount
                                InsertReplenSSCCtoDB(x)

                            Next
                            WriteLog(gcstrProcessed, "Processed Request_Case_Moves for " & RequestCaseMoveRecordCount & " SSCCs")
                        Else
                            WriteLog(gcstrError, "Request_Case_Move Parsing Failed")
                        End If

                    Case "Pick_Carton".ToUpper

                        strSSCC = ReadXML_Pick_Carton(reader)

                        If strSSCC <> "-2" Then    'dave need to fix  and put error handlign back in
                            'values with (1)  are necessary because the xml parsed insert array only ahse the header values for the first record
                            For x = 1 To InsertRepackWaveRecordCount
                                InsertRepackWavetoDB(x)

                            Next
                            WriteLog(gcstrProcessed, "Pick_Carton - Last SSCC: " & strSSCC)



                            'insert the services
                            For x = 1 To InsertServiceRecordCount
                                InsertServicetoDB(InsertService(x).SSCC, InsertService(x).Service)

                            Next



                        Else
                            WriteLog(gcstrError, "Pick Carton Parsing Failed")
                        End If

                    Case gcstrSet_Carton_Status.ToUpper

                        Dim structXML As Set_Carton_Status
                        structXML = ReadXML_Set_Carton_Status(reader)


                        'call the processing routine
                        If Process_Set_Carton_Status(structXML) = False Then

                            WriteLog(gcstrError, gcstrSet_Carton_Status & Space(1) & structXML.strSSCC & " to " & structXML.strStatus)

                        End If

                    Case gcstrSet_Location_Status.ToUpper

                        Dim structXML As Set_Location_Status
                        structXML = ReadXML_Set_Location_Status(reader)


                        'call the processing routine
                        If Process_Set_Location_Status(structXML) = False Then

                            WriteLog(gcstrError, gcstrSet_Location_Status & structXML.strLocation & " to " & structXML.strStatus)

                        End If


                    Case gcstrIgnore_Error.ToUpper


                        strCSSN = ReadXML_Ignore_Error(reader)


                        'call the processing routine
                        If strCSSN.Length > 0 Then

                            For x = 1 To Ignore_ErrorRecordCount

                                With Ignore_Error(x)
                                    InsertIgnore_ErrortoDB(.SSCC, .ERROR_CODE)
                                End With

                            Next

                            WriteLog(gcstrProcessed, Ignore_ErrorRecordCount.ToString & Space(1) & " Ignores " & " for CSSN " & strCSSN)

                        Else
                            WriteLog(gcstrError, gcstrIgnore_Error)

                        End If

                    
                        'End If



                End Select

            Catch

                WriteLog(gcstrError, "ParseXML: " & Err.Description)
            Finally

            End Try
        End Sub

        Private Function Process_Set_Carton_Status(ByVal structXML As Set_Carton_Status) As Boolean
            'determine if the message from WMS is pertinent to the current PBL status
            Dim strCurrentOpStep As String
            Dim strNextStep As String

            Try
                'having some contention issues with this call whiel in auto mode ?  multi-thread issues?
                'so just accept what we get

                strCurrentOpStep = GetCurrentOpStepForSSCC(structXML.strSSCC)
                If strCurrentOpStep = "-1" Then
                    'couldn't get opstep
                    WriteLog("CONTENTION", structXML.strSSCC & " Current Step Not Retrieved will Force to Next Step")
                End If

                Select Case structXML.strStatus.ToUpper
                    Case "PICK_ERROR"
                        strNextStep = gcstrE04
                        'expected only durign pickign process
                        If strCurrentOpStep = gcstrG04 Then

                            WriteLog(gcstrProcessed, gcstrSet_Carton_Status & Space(1) & structXML.strStatus & " for " & structXML.strSSCC)

                        Else
                            WriteLog(gcstrUNEXPECTED, "In " & SSCCServicesDescriptionFromOpStep(strCurrentOpStep) & " - Received " & gcstrSet_Carton_Status & structXML.strStatus & " for " & structXML.strSSCC)

                        End If


                        UpdateDBWithCartonAdvanceStep(structXML.strSSCC, strNextStep)


                    Case "PICK_COMPLETE"
                        strNextStep = gcstrG06
                        If strCurrentOpStep = gcstrG05 Then


                            WriteLog(gcstrProcessed, gcstrSet_Carton_Status & Space(1) & structXML.strStatus & " for " & structXML.strSSCC)

                        Else
                            WriteLog(gcstrUNEXPECTED, "In " & SSCCServicesDescriptionFromOpStep(strCurrentOpStep) & " - Received " & gcstrSet_Carton_Status & structXML.strStatus & " for " & structXML.strSSCC)

                        End If

                        UpdateDBWithCartonAdvanceStep(structXML.strSSCC, strNextStep)


                    Case "EXCEPTION"
                        strNextStep = gcstrE06

                        If strCurrentOpStep = gcstrG05 Then

                            strNextStep = gcstrE06

                            WriteLog(gcstrProcessed, gcstrSet_Carton_Status & Space(1) & structXML.strStatus & " for " & structXML.strSSCC)
                        ElseIf strCurrentOpStep = gcstrG09 Then
                            strNextStep = gcstrE10

                            WriteLog(gcstrProcessed, gcstrSet_Carton_Status & Space(1) & structXML.strStatus & " for " & structXML.strSSCC)

                        Else
                            WriteLog(gcstrUNEXPECTED, "In " & SSCCServicesDescriptionFromOpStep(strCurrentOpStep) & " - Received " & gcstrSet_Carton_Status & " of " & structXML.strStatus & " for " & structXML.strSSCC)

                        End If

                        UpdateDBWithCartonAdvanceStep(structXML.strSSCC, strNextStep)


                    Case "LABEL", "NOLABEL"
                        strNextStep = gcstrG10
                        If strCurrentOpStep = gcstrG09 Then

                            WriteLog(gcstrProcessed, gcstrSet_Carton_Status & Space(1) & structXML.strStatus & " for " & structXML.strSSCC)

                        Else
                            WriteLog(gcstrUNEXPECTED, "In " & SSCCServicesDescriptionFromOpStep(strCurrentOpStep) & " - Received " & gcstrSet_Carton_Status & structXML.strStatus & " for " & structXML.strSSCC)

                        End If

                        UpdateDBWithCartonAdvanceStep(structXML.strSSCC, strNextStep)


                    Case Else

                        WriteLog("UNDEFINED", "Received " & gcstrSet_Carton_Status & " with Unknown Status: " & structXML.strStatus & " for " & structXML.strSSCC)

                End Select

                Process_Set_Carton_Status = True
            Catch ex As Exception
                Process_Set_Carton_Status = False
            End Try

        End Function
        Private Function GetCurrentOpStepForSSCC(ByVal strSSCC As String) As String
            Dim strOpstep As String = String.Empty

            Try


                Dim strSQL As String
                strSQL = "select distinct WAVE, SSCC, OpStep " & _
                    "from z_pbl_wave where " & _
                    "SSCC='" & strSSCC & "' " & _
                    "order by Wave, SSCC, opstep"

                'use the first record returned
                'did not use db min() fucntion to avoid dealing with different db types  (Access/oracle etc)


                ' Open the Recordset using the select string:
                dbrec1.Open(strSQL, DBCON1)


                Do Until dbrec1.EOF
                    strOpstep = Convert.ToString(dbrec1.Fields("OPSTEP").Value)
                    If Len(strOpstep) > 0 Then Exit Do
                Loop
                dbrec1.MoveNext()


                'Close Recordset:
                dbrec1.Close()


            Catch ex As Exception
                strOpstep = "-1"
                WriteLog("GetCurrentOpStepForSSCC", Err.Description)
            Finally
                GetCurrentOpStepForSSCC = strOpstep

            End Try
        End Function

        ' Display any validation errors.
        Private Shared Sub ValidationCallBack(ByVal sender As Object, ByVal e As ValidationEventArgs)
            WriteLog(gcstrError, "InvalidXML: " & e.Message)
        End Sub

    End Class

    Public Function ReadXML_Confirm_Heartbeat(ByVal myReader As XmlReader) As Confirm_Heartbeat

        Dim strElement As String = vbNullString
        Dim strTextString As String = String.Empty
        Dim struct As New Confirm_Heartbeat
        Dim structXMLMessageHeader As MessageHeader

        'Load the Loop
        While Not myReader.EOF

            'Go to the next line
            myReader.Read()

            strElement = myReader.Name.ToUpper

            If myReader.IsStartElement = True Then

                If myReader.Depth > 1 Then
                    strTextString = myReader.ReadString
                End If

                Select Case strElement

                    Case gcstrMessageHeaderElement

                        structXMLMessageHeader = ReadXML_MessageHeader(myReader)

                        struct.HDR_SESSIONKEY = structXMLMessageHeader.WCS_ID
                        struct.HDR_MESSAGEID = structXMLMessageHeader.Message_Id
                        struct.HDR_TIMESTAMP = structXMLMessageHeader.TimeStamp

                    Case "TEXT"
                        struct.strText = strTextString


                End Select
            End If



        End While

        Return struct

    End Function

    Public Function ReadXML_MessageHeader(ByVal myReader As XmlReader) As MessageHeader
        Dim strElement As String
        Dim strTextString As String
        Dim struct As New MessageHeader



        'Load the Loop
        While Not myReader.EOF
            'Go to the next line
            myReader.Read()


            strTextString = myReader.ReadString
            strElement = myReader.Name.ToUpper


            ' If Len(strElement) = 0 And Len(strTextString) > 0 Then
            ' strElement = "WCS_ID"
            'End If

            Select Case strElement

                Case "WCS_ID"
                    struct.WCS_ID = strTextString
                Case "MESSAGE_ID"
                    struct.Message_Id = strTextString
                Case "TIMESTAMP"
                    struct.TimeStamp = strTextString


                    Exit While

            End Select

        End While

        Return struct
    End Function



    Public Sub InsertReplenSSCCtoDB(ByVal ArrayIndex As Integer)

        Dim strSSCC As String = String.Empty
        Dim strSql As String
        Dim strCtrl_Date As String

        Try

            strCtrl_Date = Format(Now, gcstrOracleDateTimeFormat)

            With RequestCaseMove(ArrayIndex)
                strSSCC = .SSCC
                'prevent duplicates
                strSql = "INSERT INTO Z_PBL_REPLEN " & _
                "(SSCC, LOCATN, CTRL_DATE) " & _
                "SELECT '" & .SSCC & "','" & .Locatn & "','" & strCtrl_Date & "' " & _
                "FROM dual " & _
                "WHERE not exists (select * from Z_PBL_REPLEN " & _
                "where SSCC = '" & .SSCC & "') "
            End With

            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If

            With RequestCaseMove(ArrayIndex)
                strSql = "update z_pbl_replen set " & _
                    "SSCC='" & .SSCC & "'," & _
                    "locatn='" & .Locatn & "'," & _
                    "ctrl_date='" & strCtrl_Date & "'," & _
                    "stepnumber='', " & _
                    "WH_ID='" & .WH_ID & "'," & _
                    "pbl_locatn='' " & _
                    "where SSCC = '" & .SSCC & "'"

                If Len(strSql) > 0 Then
                    DBCON1.Execute(strSql)
                End If
            End With

        Catch

            WriteLog(gcstrError, "(InsertReplenSSCCtoDB) " & Space(1) & strSSCC & Space(1) & Err.Description)

        End Try

    End Sub
    Public Sub InsertSetLocationStatustoDB(ByVal strLocation As String, ByVal strWH_ID As String, ByVal strStatus As String, ByVal strReason As String)

        Dim strSSCC As String = String.Empty
        Dim strSql As String
        Dim strCtrl_Date As String

        Try

            strCtrl_Date = Format(Now, gcstrOracleDateTimeFormat)


            'insert the primary key values
            strSql = "INSERT INTO Z_PBL_LOCATION " & _
            "(WH_ID, LOCATION) " & _
            "SELECT '" & strWH_ID & "','" & strLocation & "' " & _
            "FROM dual " & _
            "WHERE not exists (select * from Z_PBL_LOCATION " & _
            "where WH_ID = '" & strWH_ID & "' and LOCATION='" & strLocation & "')"


            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If


            'update all values
            strSql = "update z_pbl_LOCATION set " & _
                "ctrl_date='" & strCtrl_Date & "'," & _
                "STATUS='" & strStatus & "', " & _
                "REASON='" & strReason & "' " & _
                 "where WH_ID = '" & strWH_ID & "' and LOCATION='" & strLocation & "'"

            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If


        Catch

            WriteLog(gcstrError, "(InsertSetLocationtoDB) " & Space(1) & strSSCC & Space(1) & Err.Description)

        End Try

    End Sub

    Private Sub WriteLog(ByVal strAction As String, ByVal strText As String)
        Dim FilePath As String

        Try
            FilePath = LogFileName()
            My.Computer.FileSystem.WriteAllText(FilePath, Now & " | " & strAction.PadRight(15, Convert.ToChar(" ")) & strText.Trim & vbCrLf, True)
        Catch

        Finally

        End Try
    End Sub


    Public Function ReadXML_Request_Case_Move(ByVal myReader As XmlReader) As String

        Dim strElement As String
        Dim strTextString As String = vbNullString
        Dim strStartElement As String = vbNullString
        Dim iSSCCDataCount As Integer = 0
        Dim bIncrementArray As Boolean
        Dim iPreviousReadNestDepth As Integer = 99    'force high
        Dim structXMLMessageHeader As MessageHeader

        Try

            'initialize the array
            RequestCaseMoveRecordCount = 0
            ReDim RequestCaseMove(0)


            RequestCaseMoveRecordCount += 1
            ReDim Preserve RequestCaseMove(RequestCaseMoveRecordCount)


            'Load the Loop
            While Not myReader.EOF
                'Go to the next line
                myReader.Read()


                If myReader.IsStartElement = True Then
                    strStartElement = myReader.Name.ToUpper


                    'storing as a flat file any of these Start Elements 
                    Select Case strStartElement

                        Case "Case_Data".ToUpper
                            iSSCCDataCount += 1
                            If iSSCCDataCount > 1 Then
                                bIncrementArray = True
                            End If
                            'No child records - this is the last in the nest

                        Case Else
                            bIncrementArray = False
                    End Select

                    If bIncrementArray = True Then
                        'increment the array to the next record
                        RequestCaseMoveRecordCount += 1
                        ReDim Preserve RequestCaseMove(RequestCaseMoveRecordCount)

                    End If

                End If

                'if the xml depth is less than the previous read, then back at a element without data
                'if a ReadString would be executed  things get hosed up, so avoid that via following check
                strElement = myReader.Name.ToUpper

                If myReader.IsStartElement = True Then
                    If myReader.Depth > 1 And myReader.Depth >= iPreviousReadNestDepth Then
                        strTextString = myReader.ReadString
                    End If


                    Select Case strElement
                        Case "Location".ToUpper
                            RequestCaseMove(RequestCaseMoveRecordCount).Locatn = strTextString
                        Case "SSCC".ToUpper
                            RequestCaseMove(RequestCaseMoveRecordCount).SSCC = strTextString
                        Case "WH_ID".ToUpper
                            RequestCaseMove(RequestCaseMoveRecordCount).WH_ID = strTextString

                        Case gcstrMessageHeaderElement

                            structXMLMessageHeader = ReadXML_MessageHeader(myReader)

                            'struct.HDR_SESSIONKEY = structXMLMessageHeader.WCS_ID
                            'struct.HDR_MESSAGEID = structXMLMessageHeader.Message_Id
                            'struct.HDR_TIMESTAMP = structXMLMessageHeader.TimeStamp
                    End Select
                End If

                iPreviousReadNestDepth = myReader.Depth

            End While


            ReadXML_Request_Case_Move = "0"
        Catch
            ReadXML_Request_Case_Move = "-1"
        End Try
    End Function
    Public Function ReadXML_Set_Carton_Status(ByVal myReader As XmlReader) As Set_Carton_Status

        Dim strElement As String = vbNullString
        Dim strTextString As String = String.Empty
        Dim struct As New Set_Carton_Status
        Dim iPreviousReadNestDepth As Integer = 99    'force high
        Dim structXMLMessageHeader As MessageHeader

        'Load the Loop
        While Not myReader.EOF

            'Go to the next line
            myReader.Read()

            'if the xml depth is less than the previous read, then back at a element without data
            'if a ReadString would be executed  things get hosed up, so avoid that via following check
            strElement = myReader.Name.ToUpper

            If myReader.IsStartElement = True Then
                If myReader.Depth > 1 And myReader.Depth >= iPreviousReadNestDepth Then
                    strTextString = myReader.ReadString
                End If

                Select Case strElement

                    Case gcstrMessageHeaderElement

                        structXMLMessageHeader = ReadXML_MessageHeader(myReader)

                        struct.HDR_SESSIONKEY = structXMLMessageHeader.WCS_ID
                        struct.HDR_MESSAGEID = structXMLMessageHeader.Message_Id
                        struct.HDR_TIMESTAMP = structXMLMessageHeader.TimeStamp

                    Case "SSCC"
                        struct.strSSCC = strTextString

                    Case "STATUS"
                        struct.strStatus = strTextString


                End Select

            End If

            iPreviousReadNestDepth = myReader.Depth

        End While

        Return struct

    End Function

    Public Function ReadXML_Pick_Carton(ByVal myReader As XmlTextReader) As String

        Dim strElement As String
        Dim strTextString As String
        Dim strStartElement As String = vbNullString
        Dim iItemDataCount As Integer = 0
        Dim bIncrementArray As Boolean
        Dim strSSCC As String = "-1"
        Dim strCarton As String = String.Empty
        Dim iCartonArrayIndex As Integer = 1
        Dim iCartonDataCount As Integer = 0
        Dim iPreviousReadNestDepth As Integer = 99    'force high
        Dim x As Integer
        Dim bFound As Boolean

        ReadXML_Pick_Carton = "-1"


        'initialize the arrays
        InsertRepackWaveRecordCount = 0
        ReDim InsertRepackWave(0)

        InsertServiceRecordCount = 0
        ReDim InsertService(0)


        'Go to the next line   - Segment tag
        myReader.MoveToContent()

        InsertRepackWaveRecordCount += 1
        ReDim Preserve InsertRepackWave(InsertRepackWaveRecordCount)

        InsertRepackWave(InsertRepackWaveRecordCount).iCartonRecordIndex = InsertRepackWaveRecordCount
        iCartonArrayIndex = InsertRepackWaveRecordCount

        'Load the Loop
        While Not myReader.EOF

            'Go to the next line
            myReader.Read()
            If myReader.IsStartElement = True Then
                strStartElement = myReader.Name.ToUpper

                Select Case strStartElement
                    Case "CARTON_DATA"
                        iCartonDataCount += 1
                        If iCartonDataCount > 1 Then
                            iCartonArrayIndex = InsertRepackWaveRecordCount + 1
                            bIncrementArray = True
                        End If

                        'set all the child counts to 0 so that the first read of each won't
                        'trigger a new array record
                        iItemDataCount = 0

                    Case "ITEM_DATA"
                        iItemDataCount += 1
                        If iItemDataCount > 1 Then
                            bIncrementArray = True
                        End If
                        'No child records - this is the last in the nest

                    Case Else
                        bIncrementArray = False
                End Select

                If bIncrementArray = True Then
                    'increment the array to the next record
                    InsertRepackWaveRecordCount += 1
                    ReDim Preserve InsertRepackWave(InsertRepackWaveRecordCount)

                    'set the recordindexs
                    With InsertRepackWave(InsertRepackWaveRecordCount)
                        .iCartonRecordIndex = iCartonArrayIndex
                    End With

                    bIncrementArray = False   'reinitialize

                End If

            End If

            'if the xml depth is less than the previous read, then back at a element without data
            'if a ReadString would be executed  things get hosed up, so avoid that via following check
            If myReader.Depth >= iPreviousReadNestDepth Then
                strTextString = myReader.ReadString
                strElement = myReader.Name.ToUpper


                Select Case strElement
                    Case "WAVE".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Wave = strTextString
                    Case "SSCC".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).SSCC = strTextString
                        strCarton = strTextString   'last SSCC
                    Case "ITEM".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Itmcod = strTextString
                    Case "PICK_QTY".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Pick_Quantity = strTextString
                    Case "SERVICE"
                        'increment the array to the next record
                        InsertServiceRecordCount += 1
                        ReDim Preserve InsertService(InsertServiceRecordCount)

                        With InsertService(InsertServiceRecordCount)
                            .SSCC = strCarton
                            .Service = strTextString
                        End With
                    Case "CARTON_TYPE".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Carton_Type = strTextString
                    Case "CARRIER_ID".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Carrier_ID = strTextString
                    Case "CARRIER_MOVE".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Carrier_Move = strTextString
                    Case "CARRIER_TYPE".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Carrier_Type = strTextString
                    Case "CUSTOMER".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Customer = strTextString
                    Case "ORDER".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Order = strTextString
                    Case "LATE_SHIP".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Late_Ship = strTextString
                    Case "EARLY_SHIP".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Early_Ship = strTextString
                    Case "PRIORITY".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Priority = strTextString
                    Case "STATUS".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Status = strTextString
                    Case "LABEL_URL".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Label_Url = strTextString
                    Case "WH_ID".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).WH_ID = strTextString
                    Case "APPLIED_QTY".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Applied_Qty = strTextString
                    Case "LOCATION".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Location = strTextString
                    Case "UOM".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).UOM = strTextString
                    Case "WEIGHT".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).Weight = strTextString
                    Case "GMS_FLAG".ToUpper
                        bFound = False
                        If gbValidatePickCartonGMS_FLAG = True Then
                            For x = 1 To PickCartonGMS_FLAGRecordCount
                                With PickCartonGMS_FLAG(x)
                                    If strTextString = .GMS_FLAG Then
                                        bFound = True
                                        Exit For
                                    End If
                                End With
                            Next

                            If bFound = False Then
                                WriteLog(gcstrError, "GMS_FLAG Not Found: " & strTextString)
                            End If
                        End If
                        InsertRepackWave(InsertRepackWaveRecordCount).GMS_FLAG = strTextString

                    Case "TOT_PICK_WEIGHT".ToUpper
                        InsertRepackWave(InsertRepackWaveRecordCount).TOT_PICK_WEIGHT = strTextString
                    Case "BUSINESS".ToUpper

                        bFound = False
                        If gbValidatePickCartonBusiness = True Then
                            For x = 1 To PickCartonBusinessRecordCount
                                With PickCartonBusiness(x)
                                    If strTextString = .Business Then
                                        bFound = True
                                        Exit For
                                    End If
                                End With
                            Next

                            If bFound = False Then
                                WriteLog(gcstrError, "Business Not Found: " & strTextString)
                            End If
                        End If
                        InsertRepackWave(InsertRepackWaveRecordCount).BUSINESS = strTextString
                End Select

            End If

            iPreviousReadNestDepth = myReader.Depth

        End While

        ReadXML_Pick_Carton = strCarton

    End Function


    Public Sub InsertRepackWavetoDB(ByVal ArrayIndex As Integer)
        Dim strSql As String = String.Empty
        Dim strInitialStep As String

        Try

            With InsertRepackWave(InsertRepackWave(ArrayIndex).iCartonRecordIndex)
                'prevent duplicates
                strSql = "INSERT INTO Z_PBL_WAVE " & _
                "(SSCC, ITMCOD) " & _
                "SELECT '" & .SSCC & "','" & InsertRepackWave(ArrayIndex).Itmcod & "' " & _
                "FROM dual " & _
                "WHERE not exists (select * from Z_PBL_WAVE " & _
                "where SSCC = '" & .SSCC & "' and itmcod ='" & InsertRepackWave(ArrayIndex).Itmcod & "' ) "


            End With

            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If

            strInitialStep = gcstrG01     '  Good Step 1

            'the cartonrecordindex is used for all items that appear at the root of carton data
            With InsertRepackWave(InsertRepackWave(ArrayIndex).iCartonRecordIndex)
                strSql = "update z_pbl_wave set " & _
                    "wave='" & .Wave & "'," & _
                    "SSCC='" & .SSCC & "'," & _
                    "itmcod='" & InsertRepackWave(ArrayIndex).Itmcod & "'," & _
                    "OPSTEP='" & strInitialStep & "'," & _
                    "Pick_Quantity='" & InsertRepackWave(ArrayIndex).Pick_Quantity & "', " & _
                     "CARTON_TYPE='" & .Carton_Type & "', " & _
                     "CARRIER_ID='" & .Carrier_ID & "', " & _
                     "CARRIER_MOVE='" & .Carrier_Move & "', " & _
                     "CARRIER_TYPE='" & .Carrier_Type & "', " & _
                     "CUSTOMER='" & .Customer & "', " & _
                     "ORDERNUMBER='" & .Order & "', " & _
                     "LATE_SHIP='" & .Late_Ship & "', " & _
                     "EARLY_SHIP='" & .Early_Ship & "', " & _
                     "PRIORITY='" & .Priority & "', " & _
                     "STATUS='" & .Status & "', " & _
                     "LABEL_URL='" & .Label_Url & " ', " & _
                     "WH_ID='" & .WH_ID & "', " & _
                     "APPLIED_QTY='" & InsertRepackWave(ArrayIndex).Applied_Qty & "', " & _
                     "LOCATION='" & InsertRepackWave(ArrayIndex).Location & "', " & _
                     "UOM='" & InsertRepackWave(ArrayIndex).UOM & "', " & _
                     "WEIGHT='" & InsertRepackWave(ArrayIndex).Weight & "', " & _
                     "GMS_FLAG='" & InsertRepackWave(ArrayIndex).GMS_FLAG & "', " & _
                     "TOT_PICK_WEIGHT='" & InsertRepackWave(ArrayIndex).TOT_PICK_WEIGHT & "', " & _
                     "BUSINESS='" & InsertRepackWave(ArrayIndex).BUSINESS & "' " & _
                    "where SSCC = '" & .SSCC & "' and itmcod ='" & InsertRepackWave(ArrayIndex).Itmcod & "' "

            End With

            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If

        Catch
            WriteLog(gcstrError, "(InsertRepackWavetoDB)  " & InsertRepackWave(ArrayIndex).SSCC & Space(1) & Err.Description)
            WriteLog(gcstrError, strSql)
        End Try

    End Sub

    Public Sub InsertServicetoDB(ByVal strSSCC As String, ByVal strService As String)

        Dim strSql As String
       
        Try

            'prevent duplicates
            strSql = "INSERT INTO Z_PBL_Service " & _
            "(SSCC,SERVICE,SERVICE_STATUS) " & _
            "SELECT '" & strSSCC & "','" & strService & "','A'" & _
            "FROM dual " & _
            "WHERE not exists (select * from Z_PBL_SERVICE " & _
            "where SSCC = '" & strSSCC & "' and service ='" & strService & "' ) "



            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If

            'strInitialStep = gcstrG01     '  Good Step 1

            'strSql = "update z_pbl_wave set " & _
            '    "wave='" & strWave & "'," & _
            '    "SSCC='" & strSSCC & "'," & _
            '    "itmcod='" & strItmcod & "'," & _
            '    "OPSTEP='" & strInitialStep & "'," & _
            '    "Pick_Quantity='" & strPick_Quantity & "' " & _
            '    "where SSCC = '" & strSSCC & "' and itmcod ='" & strItmcod & "' "

            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If

        Catch
            WriteLog(gcstrError, "(InsertServicetoDB)  " & strSSCC & Space(1) & Err.Description)

        End Try

    End Sub

    Public Function ReadXML_Set_Location_Status(ByVal myReader As XmlReader) As Set_Location_Status

        Dim strElement As String = vbNullString
        Dim strTextString As String = String.Empty
        Dim struct As New Set_Location_Status
        Dim iPreviousReadNestDepth As Integer = 99    'force high
        Dim structXMLMessageHeader As MessageHeader

        'Load the Loop
        While Not myReader.EOF

            'Go to the next line
            myReader.Read()

            'if the xml depth is less than the previous read, then back at a element without data
            'if a ReadString would be executed  things get hosed up, so avoid that via following check

            strElement = myReader.Name.ToUpper

            If myReader.IsStartElement = True Then
                If myReader.Depth > 1 And myReader.Depth >= iPreviousReadNestDepth Then
                    strTextString = myReader.ReadString
                End If


                Select Case strElement

                    Case "LOCATION"
                        struct.strLocation = strTextString

                    Case "WH_ID"
                        struct.strWH_ID = strTextString

                    Case "STATUS"
                        struct.strStatus = strTextString

                    Case "REASON"
                        struct.strReason = strTextString

                    Case gcstrMessageHeaderElement

                        structXMLMessageHeader = ReadXML_MessageHeader(myReader)

                        struct.HDR_SESSIONKEY = structXMLMessageHeader.WCS_ID
                        struct.HDR_MESSAGEID = structXMLMessageHeader.Message_Id
                        struct.HDR_TIMESTAMP = structXMLMessageHeader.TimeStamp


                End Select


            End If

            iPreviousReadNestDepth = myReader.Depth


        End While

        Return struct

    End Function

    Private Function Process_Set_Location_Status(ByVal structXML As Set_Location_Status) As Boolean


        Try
            
            Select Case structXML.strStatus.ToUpper
                Case "LOCKED"
                  

                    InsertSetLocationStatustoDB(structXML.strLocation, structXML.strWH_ID, structXML.strStatus, structXML.strReason)



                    Beep()   ' Sound a tone.



                Case Else

                    WriteLog("UNDEFINED", "Received " & gcstrSet_Location_Status & " with Unknown Status: " & structXML.strStatus & " for " & structXML.strLocation)

            End Select

            Process_Set_Location_Status = True
        Catch ex As Exception
            Process_Set_Location_Status = False
        End Try

    End Function

    Public Function ReadXML_Ignore_Error(ByVal myReader As XmlReader) As String

        Dim strElement As String = vbNullString
        Dim strTextString As String = String.Empty

        Dim iPreviousReadNestDepth As Integer = 99    'force high

        'Load the Loop

        'init the arrays
        Ignore_ErrorRecordCount = 0
        ReDim Ignore_Error(0)

        While Not myReader.EOF

            'Go to the next line
            myReader.Read()

            'if the xml depth is less than the previous read, then back at a element without data
            'if a ReadString would be executed  things get hosed up, so avoid that via following check
            strElement = myReader.Name.ToUpper

            If myReader.IsStartElement = True Then
                If myReader.Depth > 1 And myReader.Depth >= iPreviousReadNestDepth Then
                    strTextString = myReader.ReadString
                End If

                Select Case strElement

                    Case gcstrMessageHeaderElement

                     
                    Case "SSCC"
                        Ignore_ErrorRecordCount += 1
                        ReDim Preserve Ignore_Error(Ignore_ErrorRecordCount)
                        Ignore_Error(Ignore_ErrorRecordCount).SSCC = strTextString


                    Case "ERROR_CODE"
                        Ignore_Error(Ignore_ErrorRecordCount).ERROR_CODE = strTextString


                End Select

            End If

            iPreviousReadNestDepth = myReader.Depth

        End While

        ReadXML_Ignore_Error = Ignore_Error(Ignore_ErrorRecordCount).SSCC   'return the first or null

    End Function
    Public Sub InsertIgnore_ErrortoDB(ByVal strSSCC As String, ByVal strERROR_CODE As String)


        Dim strSql As String
        Dim strCtrl_Date As String

        Try

            strCtrl_Date = Format(Now, gcstrOracleDateTimeFormat)


            'insert the primary key values
            strSql = "INSERT INTO Z_PBL_IGNORE_ERROR " & _
            "(SSCC, ERROR_CODE) " & _
            "SELECT '" & strSSCC & "','" & strERROR_CODE & "' " & _
            "FROM dual " & _
            "WHERE not exists (select * from Z_PBL_IGNORE_ERROR " & _
            "where SSCC = '" & strSSCC & "' and ERROR_CODE='" & strERROR_CODE & "')"


            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If


            'update all values
            strSql = "update Z_PBL_IGNORE_ERROR set " & _
                "ctrl_date='" & strCtrl_Date & "'," & _
                "SSCC='" & strSSCC & "', " & _
                "ERROR_CODE='" & strERROR_CODE & "' " & _
                 "where SSCC = '" & strSSCC & "' and ERROR_CODE='" & strERROR_CODE & "'"

            If Len(strSql) > 0 Then
                DBCON1.Execute(strSql)
            End If


        Catch

            WriteLog(gcstrError, "(InsertIgnoreErrortoDB) " & Space(1) & strSSCC & Space(1) & Err.Description)

        End Try

    End Sub
End Module
