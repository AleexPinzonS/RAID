<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.tmrRefreshLog = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.ConfigurationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MainToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SocketCommunicationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PickingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReplenishmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LogsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteOldLogsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteEmulatorDBLocationStatusDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteEmulatorPBLDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteEmulatorDBReplenDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteEmulatorDBIgnoreErrorDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RemoveAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PromptForUserConfirmationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SearchLogToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SendHeartbeatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SendHeartbeatAutomaticallyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SendXMLFromFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.XMLEditorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ServiceStepsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Label1 = New System.Windows.Forms.Label
        Me.tmrBlink = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabelRefresh = New System.Windows.Forms.ToolStripStatusLabel
        Me.lblWait = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolStripStatusLabelHeartBeatOn = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolStripStatusLblConnections = New System.Windows.Forms.ToolStripStatusLabel
        Me.Label15 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.TextBox4 = New System.Windows.Forms.TextBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.TextBox5 = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.TextBox6 = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.tmrReplenScan = New System.Windows.Forms.Timer(Me.components)
        Me.tmrPicking = New System.Windows.Forms.Timer(Me.components)
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.linMain = New System.Windows.Forms.Panel
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Button2 = New System.Windows.Forms.Button
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.btnReplenAutoScanOff = New System.Windows.Forms.Button
        Me.btnReplenAutoScanOn = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.cmdReplenAdvance = New System.Windows.Forms.Button
        Me.cmdReplenSelectAll = New System.Windows.Forms.Button
        Me.cmdReplenDeSelectAll = New System.Windows.Forms.Button
        Me.cmdRefreshReplen = New System.Windows.Forms.Button
        Me.flxGrid1 = New AxMSFlexGridLib.AxMSFlexGrid
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.grpCartonWeighing = New System.Windows.Forms.GroupBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtCartonWeight = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btnCartonAutoScanOn = New System.Windows.Forms.Button
        Me.btnCartonAutoScanOff = New System.Windows.Forms.Button
        Me.grpPickControl = New System.Windows.Forms.GroupBox
        Me.txtDelayPick = New System.Windows.Forms.TextBox
        Me.chkDelayPick = New System.Windows.Forms.CheckBox
        Me.butPBLPick = New System.Windows.Forms.Button
        Me.butPickSelectAll = New System.Windows.Forms.Button
        Me.butPickDeSelectAll = New System.Windows.Forms.Button
        Me.grpCartonControl = New System.Windows.Forms.GroupBox
        Me.cmdCartonAdvanceError = New System.Windows.Forms.Button
        Me.cmdCartonAdvance = New System.Windows.Forms.Button
        Me.cmdCartonSelectAll = New System.Windows.Forms.Button
        Me.cmdCartonDeSelectAll = New System.Windows.Forms.Button
        Me.butGetRepackWaveData = New System.Windows.Forms.Button
        Me.flxGrid3 = New AxMSFlexGridLib.AxMSFlexGrid
        Me.flxGrid2 = New AxMSFlexGridLib.AxMSFlexGrid
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.butMoveErrorsToLastStep = New System.Windows.Forms.Button
        Me.lblE10Title = New System.Windows.Forms.Label
        Me.lblG10Title = New System.Windows.Forms.Label
        Me.lblE10 = New System.Windows.Forms.Label
        Me.linE10 = New System.Windows.Forms.Panel
        Me.linG10 = New System.Windows.Forms.Panel
        Me.lblG10 = New System.Windows.Forms.Label
        Me.lblE09Title = New System.Windows.Forms.Label
        Me.lblG09Title = New System.Windows.Forms.Label
        Me.lblE09 = New System.Windows.Forms.Label
        Me.linE09 = New System.Windows.Forms.Panel
        Me.linG09 = New System.Windows.Forms.Panel
        Me.lblG09 = New System.Windows.Forms.Label
        Me.butGetGraphicalData = New System.Windows.Forms.Button
        Me.lblE08Title = New System.Windows.Forms.Label
        Me.lblE07Title = New System.Windows.Forms.Label
        Me.lblE06Title = New System.Windows.Forms.Label
        Me.lblE05Title = New System.Windows.Forms.Label
        Me.lblE04Title = New System.Windows.Forms.Label
        Me.lblE03Title = New System.Windows.Forms.Label
        Me.lblE02Title = New System.Windows.Forms.Label
        Me.lblE01Title = New System.Windows.Forms.Label
        Me.lblG08Title = New System.Windows.Forms.Label
        Me.lblG07Title = New System.Windows.Forms.Label
        Me.lblG06Title = New System.Windows.Forms.Label
        Me.lblG05Title = New System.Windows.Forms.Label
        Me.lblG04Title = New System.Windows.Forms.Label
        Me.lblG03Title = New System.Windows.Forms.Label
        Me.lblG02Title = New System.Windows.Forms.Label
        Me.lblG01Title = New System.Windows.Forms.Label
        Me.lblE08 = New System.Windows.Forms.Label
        Me.lblE07 = New System.Windows.Forms.Label
        Me.lblE06 = New System.Windows.Forms.Label
        Me.lblE05 = New System.Windows.Forms.Label
        Me.lblE04 = New System.Windows.Forms.Label
        Me.lblE03 = New System.Windows.Forms.Label
        Me.lblE02 = New System.Windows.Forms.Label
        Me.lblE01 = New System.Windows.Forms.Label
        Me.linE08 = New System.Windows.Forms.Panel
        Me.linE07 = New System.Windows.Forms.Panel
        Me.linE06 = New System.Windows.Forms.Panel
        Me.linE05 = New System.Windows.Forms.Panel
        Me.linE04 = New System.Windows.Forms.Panel
        Me.linE03 = New System.Windows.Forms.Panel
        Me.Panel13 = New System.Windows.Forms.Panel
        Me.linE02 = New System.Windows.Forms.Panel
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.Panel9 = New System.Windows.Forms.Panel
        Me.Panel10 = New System.Windows.Forms.Panel
        Me.linE01 = New System.Windows.Forms.Panel
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.linG08 = New System.Windows.Forms.Panel
        Me.lblG08 = New System.Windows.Forms.Label
        Me.linG07 = New System.Windows.Forms.Panel
        Me.lblG07 = New System.Windows.Forms.Label
        Me.linG06 = New System.Windows.Forms.Panel
        Me.lblG06 = New System.Windows.Forms.Label
        Me.linG05 = New System.Windows.Forms.Panel
        Me.lblG05 = New System.Windows.Forms.Label
        Me.linG04 = New System.Windows.Forms.Panel
        Me.lblG04 = New System.Windows.Forms.Label
        Me.linG03 = New System.Windows.Forms.Panel
        Me.lblG03 = New System.Windows.Forms.Label
        Me.linG02 = New System.Windows.Forms.Panel
        Me.lblG02 = New System.Windows.Forms.Label
        Me.linG01 = New System.Windows.Forms.Panel
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.Panel7 = New System.Windows.Forms.Panel
        Me.Panel8 = New System.Windows.Forms.Panel
        Me.lblG01 = New System.Windows.Forms.Label
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.flxGrid4 = New AxMSFlexGridLib.AxMSFlexGrid
        Me.butGetLocationStatusData = New System.Windows.Forms.Button
        Me.TabPage5 = New System.Windows.Forms.TabPage
        Me.flxGrid5 = New AxMSFlexGridLib.AxMSFlexGrid
        Me.butGetIgnore_ErrorData = New System.Windows.Forms.Button
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer
        Me.txtLog2 = New System.Windows.Forms.RichTextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.chkAutoDataRefresh = New System.Windows.Forms.CheckBox
        Me.butRefresh = New System.Windows.Forms.Button
        Me.txtLog = New System.Windows.Forms.RichTextBox
        Me.chkAutoRefresh = New System.Windows.Forms.CheckBox
        Me.picWorking = New System.Windows.Forms.Panel
        Me.lblProgStatus = New System.Windows.Forms.Label
        Me.lblWorking = New System.Windows.Forms.Label
        Me.tmrHeartbeat = New System.Windows.Forms.Timer(Me.components)
        Me.SocketListeningPortsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.flxGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.grpCartonWeighing.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.grpPickControl.SuspendLayout()
        Me.grpCartonControl.SuspendLayout()
        CType(Me.flxGrid3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.flxGrid2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.linE03.SuspendLayout()
        Me.linE02.SuspendLayout()
        Me.linE01.SuspendLayout()
        Me.linG01.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.flxGrid4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        CType(Me.flxGrid5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.picWorking.SuspendLayout()
        Me.SuspendLayout()
        '
        'tmrRefreshLog
        '
        Me.tmrRefreshLog.Enabled = True
        Me.tmrRefreshLog.Interval = 2000
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConfigurationToolStripMenuItem, Me.LogsToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1272, 24)
        Me.MenuStrip1.TabIndex = 31
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ConfigurationToolStripMenuItem
        '
        Me.ConfigurationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MainToolStripMenuItem, Me.SocketCommunicationToolStripMenuItem, Me.SocketListeningPortsToolStripMenuItem, Me.PickingToolStripMenuItem, Me.ReplenishmentToolStripMenuItem})
        Me.ConfigurationToolStripMenuItem.Name = "ConfigurationToolStripMenuItem"
        Me.ConfigurationToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.ConfigurationToolStripMenuItem.Text = "Configuration"
        '
        'MainToolStripMenuItem
        '
        Me.MainToolStripMenuItem.Name = "MainToolStripMenuItem"
        Me.MainToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.MainToolStripMenuItem.Text = "Main"
        '
        'SocketCommunicationToolStripMenuItem
        '
        Me.SocketCommunicationToolStripMenuItem.Name = "SocketCommunicationToolStripMenuItem"
        Me.SocketCommunicationToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.SocketCommunicationToolStripMenuItem.Text = "Socket Communication"
        '
        'PickingToolStripMenuItem
        '
        Me.PickingToolStripMenuItem.Name = "PickingToolStripMenuItem"
        Me.PickingToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.PickingToolStripMenuItem.Text = "Picking"
        '
        'ReplenishmentToolStripMenuItem
        '
        Me.ReplenishmentToolStripMenuItem.Name = "ReplenishmentToolStripMenuItem"
        Me.ReplenishmentToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ReplenishmentToolStripMenuItem.Text = "Replenishment"
        '
        'LogsToolStripMenuItem
        '
        Me.LogsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeleteOldLogsToolStripMenuItem, Me.DeleteEmulatorDBLocationStatusDataToolStripMenuItem, Me.DeleteEmulatorPBLDataToolStripMenuItem, Me.DeleteEmulatorDBReplenDataToolStripMenuItem, Me.DeleteEmulatorDBIgnoreErrorDataToolStripMenuItem, Me.RemoveAToolStripMenuItem})
        Me.LogsToolStripMenuItem.Name = "LogsToolStripMenuItem"
        Me.LogsToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.LogsToolStripMenuItem.Text = "Maintenance"
        '
        'DeleteOldLogsToolStripMenuItem
        '
        Me.DeleteOldLogsToolStripMenuItem.Name = "DeleteOldLogsToolStripMenuItem"
        Me.DeleteOldLogsToolStripMenuItem.Size = New System.Drawing.Size(269, 22)
        Me.DeleteOldLogsToolStripMenuItem.Text = "Delete Old Logs"
        '
        'DeleteEmulatorDBLocationStatusDataToolStripMenuItem
        '
        Me.DeleteEmulatorDBLocationStatusDataToolStripMenuItem.Name = "DeleteEmulatorDBLocationStatusDataToolStripMenuItem"
        Me.DeleteEmulatorDBLocationStatusDataToolStripMenuItem.Size = New System.Drawing.Size(269, 22)
        Me.DeleteEmulatorDBLocationStatusDataToolStripMenuItem.Text = "Delete Emulator DB Location Status Data"
        '
        'DeleteEmulatorPBLDataToolStripMenuItem
        '
        Me.DeleteEmulatorPBLDataToolStripMenuItem.Name = "DeleteEmulatorPBLDataToolStripMenuItem"
        Me.DeleteEmulatorPBLDataToolStripMenuItem.Size = New System.Drawing.Size(269, 22)
        Me.DeleteEmulatorPBLDataToolStripMenuItem.Text = "Delete Emulator DB PBL Data"
        '
        'DeleteEmulatorDBReplenDataToolStripMenuItem
        '
        Me.DeleteEmulatorDBReplenDataToolStripMenuItem.Name = "DeleteEmulatorDBReplenDataToolStripMenuItem"
        Me.DeleteEmulatorDBReplenDataToolStripMenuItem.Size = New System.Drawing.Size(269, 22)
        Me.DeleteEmulatorDBReplenDataToolStripMenuItem.Text = "Delete Emulator DB Replen Data"
        '
        'DeleteEmulatorDBIgnoreErrorDataToolStripMenuItem
        '
        Me.DeleteEmulatorDBIgnoreErrorDataToolStripMenuItem.Name = "DeleteEmulatorDBIgnoreErrorDataToolStripMenuItem"
        Me.DeleteEmulatorDBIgnoreErrorDataToolStripMenuItem.Size = New System.Drawing.Size(269, 22)
        Me.DeleteEmulatorDBIgnoreErrorDataToolStripMenuItem.Text = "Delete Emulator DB Ignore Error Data"
        '
        'RemoveAToolStripMenuItem
        '
        Me.RemoveAToolStripMenuItem.Name = "RemoveAToolStripMenuItem"
        Me.RemoveAToolStripMenuItem.Size = New System.Drawing.Size(269, 22)
        Me.RemoveAToolStripMenuItem.Text = "Remove All Emulator Data"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.Checked = True
        Me.ToolsToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PromptForUserConfirmationToolStripMenuItem, Me.SearchLogToolStripMenuItem, Me.SendHeartbeatToolStripMenuItem, Me.SendHeartbeatAutomaticallyToolStripMenuItem, Me.SendXMLFromFileToolStripMenuItem, Me.XMLEditorToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'PromptForUserConfirmationToolStripMenuItem
        '
        Me.PromptForUserConfirmationToolStripMenuItem.Checked = True
        Me.PromptForUserConfirmationToolStripMenuItem.CheckOnClick = True
        Me.PromptForUserConfirmationToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.PromptForUserConfirmationToolStripMenuItem.Name = "PromptForUserConfirmationToolStripMenuItem"
        Me.PromptForUserConfirmationToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.PromptForUserConfirmationToolStripMenuItem.Text = "Advance Just The Case Selected"
        '
        'SearchLogToolStripMenuItem
        '
        Me.SearchLogToolStripMenuItem.Name = "SearchLogToolStripMenuItem"
        Me.SearchLogToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.SearchLogToolStripMenuItem.Text = "Search Log"
        '
        'SendHeartbeatToolStripMenuItem
        '
        Me.SendHeartbeatToolStripMenuItem.Name = "SendHeartbeatToolStripMenuItem"
        Me.SendHeartbeatToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.SendHeartbeatToolStripMenuItem.Text = "Send Heartbeat"
        '
        'SendHeartbeatAutomaticallyToolStripMenuItem
        '
        Me.SendHeartbeatAutomaticallyToolStripMenuItem.CheckOnClick = True
        Me.SendHeartbeatAutomaticallyToolStripMenuItem.Name = "SendHeartbeatAutomaticallyToolStripMenuItem"
        Me.SendHeartbeatAutomaticallyToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.SendHeartbeatAutomaticallyToolStripMenuItem.Text = "Send Heartbeat Automatically"
        '
        'SendXMLFromFileToolStripMenuItem
        '
        Me.SendXMLFromFileToolStripMenuItem.Name = "SendXMLFromFileToolStripMenuItem"
        Me.SendXMLFromFileToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.SendXMLFromFileToolStripMenuItem.Text = "Send XML From File"
        '
        'XMLEditorToolStripMenuItem
        '
        Me.XMLEditorToolStripMenuItem.Name = "XMLEditorToolStripMenuItem"
        Me.XMLEditorToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.XMLEditorToolStripMenuItem.Text = "XML Editor"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem, Me.ServiceStepsToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'ServiceStepsToolStripMenuItem
        '
        Me.ServiceStepsToolStripMenuItem.Name = "ServiceStepsToolStripMenuItem"
        Me.ServiceStepsToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.ServiceStepsToolStripMenuItem.Text = "Close All Popup Windows"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(920, 425)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 13)
        Me.Label1.TabIndex = 45
        Me.Label1.Text = " Don't Delete"
        Me.Label1.Visible = False
        '
        'tmrBlink
        '
        Me.tmrBlink.Interval = 500
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabelRefresh, Me.lblWait, Me.ToolStripStatusLabelHeartBeatOn, Me.ToolStripStatusLblConnections})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 654)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1272, 22)
        Me.StatusStrip1.TabIndex = 62
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabelRefresh
        '
        Me.ToolStripStatusLabelRefresh.Name = "ToolStripStatusLabelRefresh"
        Me.ToolStripStatusLabelRefresh.Size = New System.Drawing.Size(120, 17)
        Me.ToolStripStatusLabelRefresh.Text = "New Message Received"
        Me.ToolStripStatusLabelRefresh.Visible = False
        '
        'lblWait
        '
        Me.lblWait.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblWait.ForeColor = System.Drawing.Color.White
        Me.lblWait.Name = "lblWait"
        Me.lblWait.Size = New System.Drawing.Size(87, 17)
        Me.lblWait.Text = "...Please Wait..."
        Me.lblWait.Visible = False
        '
        'ToolStripStatusLabelHeartBeatOn
        '
        Me.ToolStripStatusLabelHeartBeatOn.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ToolStripStatusLabelHeartBeatOn.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ToolStripStatusLabelHeartBeatOn.Name = "ToolStripStatusLabelHeartBeatOn"
        Me.ToolStripStatusLabelHeartBeatOn.Size = New System.Drawing.Size(73, 17)
        Me.ToolStripStatusLabelHeartBeatOn.Text = "HeartBeat On"
        Me.ToolStripStatusLabelHeartBeatOn.Visible = False
        '
        'ToolStripStatusLblConnections
        '
        Me.ToolStripStatusLblConnections.Name = "ToolStripStatusLblConnections"
        Me.ToolStripStatusLblConnections.Size = New System.Drawing.Size(1257, 17)
        Me.ToolStripStatusLblConnections.Spring = True
        Me.ToolStripStatusLblConnections.Text = "IP etc"
        Me.ToolStripStatusLblConnections.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(10, 127)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(85, 13)
        Me.Label15.TabIndex = 101
        Me.Label15.Text = "Override Sitnam:"
        '
        'TextBox1
        '
        Me.TextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBox1.ForeColor = System.Drawing.Color.Blue
        Me.TextBox1.Location = New System.Drawing.Point(101, 124)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(120, 20)
        Me.TextBox1.TabIndex = 100
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(10, 179)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(36, 13)
        Me.Label23.TabIndex = 99
        Me.Label23.Text = "Sldflg:"
        '
        'TextBox2
        '
        Me.TextBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBox2.ForeColor = System.Drawing.Color.Blue
        Me.TextBox2.Location = New System.Drawing.Point(101, 176)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(120, 20)
        Me.TextBox2.TabIndex = 98
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(10, 101)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(37, 13)
        Me.Label24.TabIndex = 97
        Me.Label24.Text = "UlPall:"
        '
        'TextBox3
        '
        Me.TextBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBox3.ForeColor = System.Drawing.Color.Blue
        Me.TextBox3.Location = New System.Drawing.Point(101, 98)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(120, 20)
        Me.TextBox3.TabIndex = 96
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(10, 153)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(86, 13)
        Me.Label25.TabIndex = 95
        Me.Label25.Text = "Override Locatn:"
        '
        'TextBox4
        '
        Me.TextBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBox4.ForeColor = System.Drawing.Color.Blue
        Me.TextBox4.Location = New System.Drawing.Point(101, 150)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(120, 20)
        Me.TextBox4.TabIndex = 94
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(10, 23)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(28, 13)
        Me.Label26.TabIndex = 93
        Me.Label26.Text = "Ulid:"
        '
        'TextBox5
        '
        Me.TextBox5.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBox5.ForeColor = System.Drawing.Color.Blue
        Me.TextBox5.Location = New System.Drawing.Point(101, 20)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(228, 20)
        Me.TextBox5.TabIndex = 92
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(10, 49)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(42, 13)
        Me.Label27.TabIndex = 90
        Me.Label27.Text = "Sitnam:"
        '
        'TextBox6
        '
        Me.TextBox6.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBox6.ForeColor = System.Drawing.Color.Blue
        Me.TextBox6.Location = New System.Drawing.Point(101, 46)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(120, 20)
        Me.TextBox6.TabIndex = 89
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(10, 75)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(43, 13)
        Me.Label28.TabIndex = 88
        Me.Label28.Text = "Locatn:"
        '
        'TextBox7
        '
        Me.TextBox7.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBox7.ForeColor = System.Drawing.Color.Blue
        Me.TextBox7.Location = New System.Drawing.Point(101, 72)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(120, 20)
        Me.TextBox7.TabIndex = 87
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(39, 326)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(84, 39)
        Me.Button1.TabIndex = 77
        Me.Button1.Text = "Identify UL"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'tmrReplenScan
        '
        Me.tmrReplenScan.Interval = 5000
        '
        'tmrPicking
        '
        Me.tmrPicking.Interval = 5000
        '
        'linMain
        '
        Me.linMain.BackColor = System.Drawing.SystemColors.ControlText
        Me.linMain.Location = New System.Drawing.Point(36, 205)
        Me.linMain.Name = "linMain"
        Me.linMain.Size = New System.Drawing.Size(882, 10)
        Me.linMain.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.linMain, "Click On Error Path to Force SSCC Error")
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer1.Location = New System.Drawing.Point(12, 27)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.SplitContainer1.Panel1.Controls.Add(Me.TabControl1)
        Me.SplitContainer1.Panel1MinSize = 125
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Panel2MinSize = 75
        Me.SplitContainer1.Size = New System.Drawing.Size(1245, 625)
        Me.SplitContainer1.SplitterDistance = 440
        Me.SplitContainer1.TabIndex = 63
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Location = New System.Drawing.Point(3, 3)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1274, 439)
        Me.TabControl1.TabIndex = 59
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Transparent
        Me.TabPage1.Controls.Add(Me.Button2)
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.cmdRefreshReplen)
        Me.TabPage1.Controls.Add(Me.flxGrid1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1266, 413)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Replenishment"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(605, 21)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(65, 48)
        Me.Button2.TabIndex = 61
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnReplenAutoScanOff)
        Me.GroupBox3.Controls.Add(Me.btnReplenAutoScanOn)
        Me.GroupBox3.Location = New System.Drawing.Point(482, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(80, 68)
        Me.GroupBox3.TabIndex = 60
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Auto Mode"
        '
        'btnReplenAutoScanOff
        '
        Me.btnReplenAutoScanOff.Location = New System.Drawing.Point(14, 41)
        Me.btnReplenAutoScanOff.Name = "btnReplenAutoScanOff"
        Me.btnReplenAutoScanOff.Size = New System.Drawing.Size(40, 23)
        Me.btnReplenAutoScanOff.TabIndex = 66
        Me.btnReplenAutoScanOff.Text = "Off"
        '
        'btnReplenAutoScanOn
        '
        Me.btnReplenAutoScanOn.Location = New System.Drawing.Point(14, 15)
        Me.btnReplenAutoScanOn.Name = "btnReplenAutoScanOn"
        Me.btnReplenAutoScanOn.Size = New System.Drawing.Size(40, 23)
        Me.btnReplenAutoScanOn.TabIndex = 64
        Me.btnReplenAutoScanOn.Text = "On"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmdReplenAdvance)
        Me.GroupBox1.Controls.Add(Me.cmdReplenSelectAll)
        Me.GroupBox1.Controls.Add(Me.cmdReplenDeSelectAll)
        Me.GroupBox1.Location = New System.Drawing.Point(105, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(372, 68)
        Me.GroupBox1.TabIndex = 59
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Replen Control "
        '
        'cmdReplenAdvance
        '
        Me.cmdReplenAdvance.Location = New System.Drawing.Point(186, 18)
        Me.cmdReplenAdvance.Name = "cmdReplenAdvance"
        Me.cmdReplenAdvance.Size = New System.Drawing.Size(84, 34)
        Me.cmdReplenAdvance.TabIndex = 57
        Me.cmdReplenAdvance.Text = "Advance"
        Me.cmdReplenAdvance.UseVisualStyleBackColor = True
        '
        'cmdReplenSelectAll
        '
        Me.cmdReplenSelectAll.Location = New System.Drawing.Point(6, 18)
        Me.cmdReplenSelectAll.Name = "cmdReplenSelectAll"
        Me.cmdReplenSelectAll.Size = New System.Drawing.Size(84, 34)
        Me.cmdReplenSelectAll.TabIndex = 55
        Me.cmdReplenSelectAll.Text = "Select All"
        Me.cmdReplenSelectAll.UseVisualStyleBackColor = True
        '
        'cmdReplenDeSelectAll
        '
        Me.cmdReplenDeSelectAll.Location = New System.Drawing.Point(96, 18)
        Me.cmdReplenDeSelectAll.Name = "cmdReplenDeSelectAll"
        Me.cmdReplenDeSelectAll.Size = New System.Drawing.Size(84, 34)
        Me.cmdReplenDeSelectAll.TabIndex = 56
        Me.cmdReplenDeSelectAll.Text = "DeSelectAll"
        Me.cmdReplenDeSelectAll.UseVisualStyleBackColor = True
        '
        'cmdRefreshReplen
        '
        Me.cmdRefreshReplen.Location = New System.Drawing.Point(15, 24)
        Me.cmdRefreshReplen.Name = "cmdRefreshReplen"
        Me.cmdRefreshReplen.Size = New System.Drawing.Size(84, 34)
        Me.cmdRefreshReplen.TabIndex = 56
        Me.cmdRefreshReplen.Text = "Get Data"
        Me.cmdRefreshReplen.UseVisualStyleBackColor = True
        '
        'flxGrid1
        '
        Me.flxGrid1.Location = New System.Drawing.Point(15, 80)
        Me.flxGrid1.Name = "flxGrid1"
        Me.flxGrid1.OcxState = CType(resources.GetObject("flxGrid1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.flxGrid1.Size = New System.Drawing.Size(924, 236)
        Me.flxGrid1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.grpCartonWeighing)
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.Controls.Add(Me.grpPickControl)
        Me.TabPage2.Controls.Add(Me.grpCartonControl)
        Me.TabPage2.Controls.Add(Me.butGetRepackWaveData)
        Me.TabPage2.Controls.Add(Me.flxGrid3)
        Me.TabPage2.Controls.Add(Me.flxGrid2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(1266, 413)
        Me.TabPage2.TabIndex = 4
        Me.TabPage2.Text = "Carton Control"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'grpCartonWeighing
        '
        Me.grpCartonWeighing.Controls.Add(Me.Label2)
        Me.grpCartonWeighing.Controls.Add(Me.txtCartonWeight)
        Me.grpCartonWeighing.Location = New System.Drawing.Point(1049, 6)
        Me.grpCartonWeighing.Name = "grpCartonWeighing"
        Me.grpCartonWeighing.Size = New System.Drawing.Size(182, 68)
        Me.grpCartonWeighing.TabIndex = 74
        Me.grpCartonWeighing.TabStop = False
        Me.grpCartonWeighing.Text = "Carton Weigh"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 13)
        Me.Label2.TabIndex = 61
        Me.Label2.Text = "Weight Multiplier"
        '
        'txtCartonWeight
        '
        Me.txtCartonWeight.Location = New System.Drawing.Point(97, 19)
        Me.txtCartonWeight.Name = "txtCartonWeight"
        Me.txtCartonWeight.Size = New System.Drawing.Size(59, 20)
        Me.txtCartonWeight.TabIndex = 60
        Me.txtCartonWeight.Text = "1"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnCartonAutoScanOn)
        Me.GroupBox2.Controls.Add(Me.btnCartonAutoScanOff)
        Me.GroupBox2.Location = New System.Drawing.Point(482, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(80, 68)
        Me.GroupBox2.TabIndex = 73
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Auto Mode"
        '
        'btnCartonAutoScanOn
        '
        Me.btnCartonAutoScanOn.Location = New System.Drawing.Point(14, 15)
        Me.btnCartonAutoScanOn.Name = "btnCartonAutoScanOn"
        Me.btnCartonAutoScanOn.Size = New System.Drawing.Size(40, 23)
        Me.btnCartonAutoScanOn.TabIndex = 70
        Me.btnCartonAutoScanOn.Text = "On"
        '
        'btnCartonAutoScanOff
        '
        Me.btnCartonAutoScanOff.Location = New System.Drawing.Point(14, 41)
        Me.btnCartonAutoScanOff.Name = "btnCartonAutoScanOff"
        Me.btnCartonAutoScanOff.Size = New System.Drawing.Size(40, 23)
        Me.btnCartonAutoScanOff.TabIndex = 72
        Me.btnCartonAutoScanOff.Text = "Off"
        '
        'grpPickControl
        '
        Me.grpPickControl.Controls.Add(Me.txtDelayPick)
        Me.grpPickControl.Controls.Add(Me.chkDelayPick)
        Me.grpPickControl.Controls.Add(Me.butPBLPick)
        Me.grpPickControl.Controls.Add(Me.butPickSelectAll)
        Me.grpPickControl.Controls.Add(Me.butPickDeSelectAll)
        Me.grpPickControl.Location = New System.Drawing.Point(566, 6)
        Me.grpPickControl.Name = "grpPickControl"
        Me.grpPickControl.Size = New System.Drawing.Size(479, 68)
        Me.grpPickControl.TabIndex = 61
        Me.grpPickControl.TabStop = False
        Me.grpPickControl.Text = "Pick Control "
        '
        'txtDelayPick
        '
        Me.txtDelayPick.Location = New System.Drawing.Point(363, 24)
        Me.txtDelayPick.Name = "txtDelayPick"
        Me.txtDelayPick.Size = New System.Drawing.Size(35, 20)
        Me.txtDelayPick.TabIndex = 59
        Me.txtDelayPick.Text = "200"
        '
        'chkDelayPick
        '
        Me.chkDelayPick.AutoSize = True
        Me.chkDelayPick.Location = New System.Drawing.Point(276, 26)
        Me.chkDelayPick.Name = "chkDelayPick"
        Me.chkDelayPick.Size = New System.Drawing.Size(91, 17)
        Me.chkDelayPick.TabIndex = 58
        Me.chkDelayPick.Text = "Delay Interval"
        Me.chkDelayPick.UseVisualStyleBackColor = True
        '
        'butPBLPick
        '
        Me.butPBLPick.Location = New System.Drawing.Point(186, 18)
        Me.butPBLPick.Name = "butPBLPick"
        Me.butPBLPick.Size = New System.Drawing.Size(84, 34)
        Me.butPBLPick.TabIndex = 57
        Me.butPBLPick.Text = "Pick"
        Me.butPBLPick.UseVisualStyleBackColor = True
        '
        'butPickSelectAll
        '
        Me.butPickSelectAll.Location = New System.Drawing.Point(6, 18)
        Me.butPickSelectAll.Name = "butPickSelectAll"
        Me.butPickSelectAll.Size = New System.Drawing.Size(84, 34)
        Me.butPickSelectAll.TabIndex = 55
        Me.butPickSelectAll.Text = "Select All"
        Me.butPickSelectAll.UseVisualStyleBackColor = True
        '
        'butPickDeSelectAll
        '
        Me.butPickDeSelectAll.Location = New System.Drawing.Point(96, 18)
        Me.butPickDeSelectAll.Name = "butPickDeSelectAll"
        Me.butPickDeSelectAll.Size = New System.Drawing.Size(84, 34)
        Me.butPickDeSelectAll.TabIndex = 56
        Me.butPickDeSelectAll.Text = "DeSelectAll"
        Me.butPickDeSelectAll.UseVisualStyleBackColor = True
        '
        'grpCartonControl
        '
        Me.grpCartonControl.Controls.Add(Me.cmdCartonAdvanceError)
        Me.grpCartonControl.Controls.Add(Me.cmdCartonAdvance)
        Me.grpCartonControl.Controls.Add(Me.cmdCartonSelectAll)
        Me.grpCartonControl.Controls.Add(Me.cmdCartonDeSelectAll)
        Me.grpCartonControl.Location = New System.Drawing.Point(105, 6)
        Me.grpCartonControl.Name = "grpCartonControl"
        Me.grpCartonControl.Size = New System.Drawing.Size(372, 68)
        Me.grpCartonControl.TabIndex = 60
        Me.grpCartonControl.TabStop = False
        Me.grpCartonControl.Text = "Carton Control "
        '
        'cmdCartonAdvanceError
        '
        Me.cmdCartonAdvanceError.Location = New System.Drawing.Point(276, 18)
        Me.cmdCartonAdvanceError.Name = "cmdCartonAdvanceError"
        Me.cmdCartonAdvanceError.Size = New System.Drawing.Size(84, 34)
        Me.cmdCartonAdvanceError.TabIndex = 58
        Me.cmdCartonAdvanceError.Text = "Advance-Error"
        Me.cmdCartonAdvanceError.UseVisualStyleBackColor = True
        '
        'cmdCartonAdvance
        '
        Me.cmdCartonAdvance.Location = New System.Drawing.Point(186, 18)
        Me.cmdCartonAdvance.Name = "cmdCartonAdvance"
        Me.cmdCartonAdvance.Size = New System.Drawing.Size(84, 34)
        Me.cmdCartonAdvance.TabIndex = 57
        Me.cmdCartonAdvance.Text = "Advance"
        Me.cmdCartonAdvance.UseVisualStyleBackColor = True
        '
        'cmdCartonSelectAll
        '
        Me.cmdCartonSelectAll.Location = New System.Drawing.Point(6, 18)
        Me.cmdCartonSelectAll.Name = "cmdCartonSelectAll"
        Me.cmdCartonSelectAll.Size = New System.Drawing.Size(84, 34)
        Me.cmdCartonSelectAll.TabIndex = 55
        Me.cmdCartonSelectAll.Text = "Select All"
        Me.cmdCartonSelectAll.UseVisualStyleBackColor = True
        '
        'cmdCartonDeSelectAll
        '
        Me.cmdCartonDeSelectAll.Location = New System.Drawing.Point(96, 18)
        Me.cmdCartonDeSelectAll.Name = "cmdCartonDeSelectAll"
        Me.cmdCartonDeSelectAll.Size = New System.Drawing.Size(84, 34)
        Me.cmdCartonDeSelectAll.TabIndex = 56
        Me.cmdCartonDeSelectAll.Text = "DeSelectAll"
        Me.cmdCartonDeSelectAll.UseVisualStyleBackColor = True
        '
        'butGetRepackWaveData
        '
        Me.butGetRepackWaveData.Location = New System.Drawing.Point(15, 24)
        Me.butGetRepackWaveData.Name = "butGetRepackWaveData"
        Me.butGetRepackWaveData.Size = New System.Drawing.Size(84, 34)
        Me.butGetRepackWaveData.TabIndex = 57
        Me.butGetRepackWaveData.Text = "Get Data"
        Me.butGetRepackWaveData.UseVisualStyleBackColor = True
        '
        'flxGrid3
        '
        Me.flxGrid3.Location = New System.Drawing.Point(566, 80)
        Me.flxGrid3.Name = "flxGrid3"
        Me.flxGrid3.OcxState = CType(resources.GetObject("flxGrid3.OcxState"), System.Windows.Forms.AxHost.State)
        Me.flxGrid3.Size = New System.Drawing.Size(665, 249)
        Me.flxGrid3.TabIndex = 62
        '
        'flxGrid2
        '
        Me.flxGrid2.Location = New System.Drawing.Point(15, 80)
        Me.flxGrid2.Name = "flxGrid2"
        Me.flxGrid2.OcxState = CType(resources.GetObject("flxGrid2.OcxState"), System.Windows.Forms.AxHost.State)
        Me.flxGrid2.Size = New System.Drawing.Size(515, 249)
        Me.flxGrid2.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.Transparent
        Me.TabPage3.Controls.Add(Me.butMoveErrorsToLastStep)
        Me.TabPage3.Controls.Add(Me.lblE10Title)
        Me.TabPage3.Controls.Add(Me.lblG10Title)
        Me.TabPage3.Controls.Add(Me.lblE10)
        Me.TabPage3.Controls.Add(Me.linE10)
        Me.TabPage3.Controls.Add(Me.linG10)
        Me.TabPage3.Controls.Add(Me.lblG10)
        Me.TabPage3.Controls.Add(Me.lblE09Title)
        Me.TabPage3.Controls.Add(Me.lblG09Title)
        Me.TabPage3.Controls.Add(Me.lblE09)
        Me.TabPage3.Controls.Add(Me.linE09)
        Me.TabPage3.Controls.Add(Me.linG09)
        Me.TabPage3.Controls.Add(Me.lblG09)
        Me.TabPage3.Controls.Add(Me.butGetGraphicalData)
        Me.TabPage3.Controls.Add(Me.lblE08Title)
        Me.TabPage3.Controls.Add(Me.lblE07Title)
        Me.TabPage3.Controls.Add(Me.lblE06Title)
        Me.TabPage3.Controls.Add(Me.lblE05Title)
        Me.TabPage3.Controls.Add(Me.lblE04Title)
        Me.TabPage3.Controls.Add(Me.lblE03Title)
        Me.TabPage3.Controls.Add(Me.lblE02Title)
        Me.TabPage3.Controls.Add(Me.lblE01Title)
        Me.TabPage3.Controls.Add(Me.lblG08Title)
        Me.TabPage3.Controls.Add(Me.lblG07Title)
        Me.TabPage3.Controls.Add(Me.lblG06Title)
        Me.TabPage3.Controls.Add(Me.lblG05Title)
        Me.TabPage3.Controls.Add(Me.lblG04Title)
        Me.TabPage3.Controls.Add(Me.lblG03Title)
        Me.TabPage3.Controls.Add(Me.lblG02Title)
        Me.TabPage3.Controls.Add(Me.lblG01Title)
        Me.TabPage3.Controls.Add(Me.lblE08)
        Me.TabPage3.Controls.Add(Me.lblE07)
        Me.TabPage3.Controls.Add(Me.lblE06)
        Me.TabPage3.Controls.Add(Me.lblE05)
        Me.TabPage3.Controls.Add(Me.lblE04)
        Me.TabPage3.Controls.Add(Me.lblE03)
        Me.TabPage3.Controls.Add(Me.lblE02)
        Me.TabPage3.Controls.Add(Me.lblE01)
        Me.TabPage3.Controls.Add(Me.linE08)
        Me.TabPage3.Controls.Add(Me.linE07)
        Me.TabPage3.Controls.Add(Me.linE06)
        Me.TabPage3.Controls.Add(Me.linE05)
        Me.TabPage3.Controls.Add(Me.linE04)
        Me.TabPage3.Controls.Add(Me.linE03)
        Me.TabPage3.Controls.Add(Me.linE02)
        Me.TabPage3.Controls.Add(Me.linE01)
        Me.TabPage3.Controls.Add(Me.linG08)
        Me.TabPage3.Controls.Add(Me.lblG08)
        Me.TabPage3.Controls.Add(Me.linG07)
        Me.TabPage3.Controls.Add(Me.lblG07)
        Me.TabPage3.Controls.Add(Me.linG06)
        Me.TabPage3.Controls.Add(Me.lblG06)
        Me.TabPage3.Controls.Add(Me.linG05)
        Me.TabPage3.Controls.Add(Me.lblG05)
        Me.TabPage3.Controls.Add(Me.linG04)
        Me.TabPage3.Controls.Add(Me.lblG04)
        Me.TabPage3.Controls.Add(Me.linG03)
        Me.TabPage3.Controls.Add(Me.lblG03)
        Me.TabPage3.Controls.Add(Me.linG02)
        Me.TabPage3.Controls.Add(Me.lblG02)
        Me.TabPage3.Controls.Add(Me.linG01)
        Me.TabPage3.Controls.Add(Me.linMain)
        Me.TabPage3.Controls.Add(Me.lblG01)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1266, 413)
        Me.TabPage3.TabIndex = 3
        Me.TabPage3.Text = "Carton Status Summary"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'butMoveErrorsToLastStep
        '
        Me.butMoveErrorsToLastStep.Location = New System.Drawing.Point(120, 24)
        Me.butMoveErrorsToLastStep.Name = "butMoveErrorsToLastStep"
        Me.butMoveErrorsToLastStep.Size = New System.Drawing.Size(116, 34)
        Me.butMoveErrorsToLastStep.TabIndex = 83
        Me.butMoveErrorsToLastStep.Text = "Last Good Step SSCC Delete"
        Me.butMoveErrorsToLastStep.UseVisualStyleBackColor = True
        '
        'lblE10Title
        '
        Me.lblE10Title.Location = New System.Drawing.Point(875, 332)
        Me.lblE10Title.Name = "lblE10Title"
        Me.lblE10Title.Size = New System.Drawing.Size(78, 48)
        Me.lblE10Title.TabIndex = 82
        Me.lblE10Title.Text = "NA"
        Me.lblE10Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE10Title.Visible = False
        '
        'lblG10Title
        '
        Me.lblG10Title.Location = New System.Drawing.Point(875, 52)
        Me.lblG10Title.Name = "lblG10Title"
        Me.lblG10Title.Size = New System.Drawing.Size(78, 38)
        Me.lblG10Title.TabIndex = 81
        Me.lblG10Title.Text = "NA"
        Me.lblG10Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblE10
        '
        Me.lblE10.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblE10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblE10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblE10.Location = New System.Drawing.Point(875, 255)
        Me.lblE10.Name = "lblE10"
        Me.lblE10.Size = New System.Drawing.Size(78, 69)
        Me.lblE10.TabIndex = 80
        Me.lblE10.Text = "0"
        Me.lblE10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE10.Visible = False
        '
        'linE10
        '
        Me.linE10.BackColor = System.Drawing.SystemColors.ControlText
        Me.linE10.Location = New System.Drawing.Point(908, 215)
        Me.linE10.Name = "linE10"
        Me.linE10.Size = New System.Drawing.Size(10, 40)
        Me.linE10.TabIndex = 79
        Me.linE10.Visible = False
        '
        'linG10
        '
        Me.linG10.BackColor = System.Drawing.SystemColors.ControlText
        Me.linG10.Location = New System.Drawing.Point(908, 166)
        Me.linG10.Name = "linG10"
        Me.linG10.Size = New System.Drawing.Size(10, 40)
        Me.linG10.TabIndex = 78
        '
        'lblG10
        '
        Me.lblG10.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblG10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblG10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblG10.Location = New System.Drawing.Point(875, 97)
        Me.lblG10.Name = "lblG10"
        Me.lblG10.Size = New System.Drawing.Size(78, 69)
        Me.lblG10.TabIndex = 77
        Me.lblG10.Text = "0"
        Me.lblG10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblE09Title
        '
        Me.lblE09Title.Location = New System.Drawing.Point(782, 332)
        Me.lblE09Title.Name = "lblE09Title"
        Me.lblE09Title.Size = New System.Drawing.Size(78, 48)
        Me.lblE09Title.TabIndex = 76
        Me.lblE09Title.Text = "NA"
        Me.lblE09Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE09Title.Visible = False
        '
        'lblG09Title
        '
        Me.lblG09Title.Location = New System.Drawing.Point(782, 52)
        Me.lblG09Title.Name = "lblG09Title"
        Me.lblG09Title.Size = New System.Drawing.Size(78, 38)
        Me.lblG09Title.TabIndex = 75
        Me.lblG09Title.Text = "NA"
        Me.lblG09Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblE09
        '
        Me.lblE09.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblE09.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblE09.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblE09.Location = New System.Drawing.Point(782, 255)
        Me.lblE09.Name = "lblE09"
        Me.lblE09.Size = New System.Drawing.Size(78, 69)
        Me.lblE09.TabIndex = 74
        Me.lblE09.Text = "0"
        Me.lblE09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE09.Visible = False
        '
        'linE09
        '
        Me.linE09.BackColor = System.Drawing.SystemColors.ControlText
        Me.linE09.Location = New System.Drawing.Point(815, 215)
        Me.linE09.Name = "linE09"
        Me.linE09.Size = New System.Drawing.Size(10, 40)
        Me.linE09.TabIndex = 73
        Me.linE09.Visible = False
        '
        'linG09
        '
        Me.linG09.BackColor = System.Drawing.SystemColors.ControlText
        Me.linG09.Location = New System.Drawing.Point(815, 166)
        Me.linG09.Name = "linG09"
        Me.linG09.Size = New System.Drawing.Size(10, 40)
        Me.linG09.TabIndex = 72
        '
        'lblG09
        '
        Me.lblG09.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblG09.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblG09.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblG09.Location = New System.Drawing.Point(782, 97)
        Me.lblG09.Name = "lblG09"
        Me.lblG09.Size = New System.Drawing.Size(78, 69)
        Me.lblG09.TabIndex = 71
        Me.lblG09.Text = "0"
        Me.lblG09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'butGetGraphicalData
        '
        Me.butGetGraphicalData.Location = New System.Drawing.Point(15, 24)
        Me.butGetGraphicalData.Name = "butGetGraphicalData"
        Me.butGetGraphicalData.Size = New System.Drawing.Size(84, 34)
        Me.butGetGraphicalData.TabIndex = 58
        Me.butGetGraphicalData.Text = "Get Data"
        Me.butGetGraphicalData.UseVisualStyleBackColor = True
        '
        'lblE08Title
        '
        Me.lblE08Title.Location = New System.Drawing.Point(689, 332)
        Me.lblE08Title.Name = "lblE08Title"
        Me.lblE08Title.Size = New System.Drawing.Size(78, 48)
        Me.lblE08Title.TabIndex = 52
        Me.lblE08Title.Text = "NA"
        Me.lblE08Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE08Title.Visible = False
        '
        'lblE07Title
        '
        Me.lblE07Title.Location = New System.Drawing.Point(594, 332)
        Me.lblE07Title.Name = "lblE07Title"
        Me.lblE07Title.Size = New System.Drawing.Size(78, 48)
        Me.lblE07Title.TabIndex = 51
        Me.lblE07Title.Text = "NA"
        Me.lblE07Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE07Title.Visible = False
        '
        'lblE06Title
        '
        Me.lblE06Title.Location = New System.Drawing.Point(500, 332)
        Me.lblE06Title.Name = "lblE06Title"
        Me.lblE06Title.Size = New System.Drawing.Size(78, 48)
        Me.lblE06Title.TabIndex = 50
        Me.lblE06Title.Text = "NA"
        Me.lblE06Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE06Title.Visible = False
        '
        'lblE05Title
        '
        Me.lblE05Title.Location = New System.Drawing.Point(405, 332)
        Me.lblE05Title.Name = "lblE05Title"
        Me.lblE05Title.Size = New System.Drawing.Size(78, 48)
        Me.lblE05Title.TabIndex = 49
        Me.lblE05Title.Text = "NA"
        Me.lblE05Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE05Title.Visible = False
        '
        'lblE04Title
        '
        Me.lblE04Title.Location = New System.Drawing.Point(312, 332)
        Me.lblE04Title.Name = "lblE04Title"
        Me.lblE04Title.Size = New System.Drawing.Size(78, 48)
        Me.lblE04Title.TabIndex = 48
        Me.lblE04Title.Text = "NA"
        Me.lblE04Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE04Title.Visible = False
        '
        'lblE03Title
        '
        Me.lblE03Title.Location = New System.Drawing.Point(217, 332)
        Me.lblE03Title.Name = "lblE03Title"
        Me.lblE03Title.Size = New System.Drawing.Size(78, 48)
        Me.lblE03Title.TabIndex = 47
        Me.lblE03Title.Text = "NA"
        Me.lblE03Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE03Title.Visible = False
        '
        'lblE02Title
        '
        Me.lblE02Title.Location = New System.Drawing.Point(120, 332)
        Me.lblE02Title.Name = "lblE02Title"
        Me.lblE02Title.Size = New System.Drawing.Size(78, 48)
        Me.lblE02Title.TabIndex = 46
        Me.lblE02Title.Text = "NA"
        Me.lblE02Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE02Title.Visible = False
        '
        'lblE01Title
        '
        Me.lblE01Title.Location = New System.Drawing.Point(25, 332)
        Me.lblE01Title.Name = "lblE01Title"
        Me.lblE01Title.Size = New System.Drawing.Size(78, 48)
        Me.lblE01Title.TabIndex = 45
        Me.lblE01Title.Text = "NA"
        Me.lblE01Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE01Title.Visible = False
        '
        'lblG08Title
        '
        Me.lblG08Title.Location = New System.Drawing.Point(689, 52)
        Me.lblG08Title.Name = "lblG08Title"
        Me.lblG08Title.Size = New System.Drawing.Size(78, 38)
        Me.lblG08Title.TabIndex = 44
        Me.lblG08Title.Text = "NA"
        Me.lblG08Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblG07Title
        '
        Me.lblG07Title.Location = New System.Drawing.Point(594, 52)
        Me.lblG07Title.Name = "lblG07Title"
        Me.lblG07Title.Size = New System.Drawing.Size(78, 38)
        Me.lblG07Title.TabIndex = 43
        Me.lblG07Title.Text = "NA"
        Me.lblG07Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblG06Title
        '
        Me.lblG06Title.Location = New System.Drawing.Point(500, 52)
        Me.lblG06Title.Name = "lblG06Title"
        Me.lblG06Title.Size = New System.Drawing.Size(78, 38)
        Me.lblG06Title.TabIndex = 42
        Me.lblG06Title.Text = "NA"
        Me.lblG06Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblG05Title
        '
        Me.lblG05Title.Location = New System.Drawing.Point(405, 52)
        Me.lblG05Title.Name = "lblG05Title"
        Me.lblG05Title.Size = New System.Drawing.Size(78, 38)
        Me.lblG05Title.TabIndex = 41
        Me.lblG05Title.Text = "NA"
        Me.lblG05Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblG04Title
        '
        Me.lblG04Title.Location = New System.Drawing.Point(312, 52)
        Me.lblG04Title.Name = "lblG04Title"
        Me.lblG04Title.Size = New System.Drawing.Size(78, 38)
        Me.lblG04Title.TabIndex = 40
        Me.lblG04Title.Text = "NA"
        Me.lblG04Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblG03Title
        '
        Me.lblG03Title.Location = New System.Drawing.Point(217, 52)
        Me.lblG03Title.Name = "lblG03Title"
        Me.lblG03Title.Size = New System.Drawing.Size(78, 38)
        Me.lblG03Title.TabIndex = 39
        Me.lblG03Title.Text = "NA"
        Me.lblG03Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblG02Title
        '
        Me.lblG02Title.Location = New System.Drawing.Point(120, 52)
        Me.lblG02Title.Name = "lblG02Title"
        Me.lblG02Title.Size = New System.Drawing.Size(78, 38)
        Me.lblG02Title.TabIndex = 38
        Me.lblG02Title.Text = "NA"
        Me.lblG02Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblG01Title
        '
        Me.lblG01Title.Location = New System.Drawing.Point(25, 52)
        Me.lblG01Title.Name = "lblG01Title"
        Me.lblG01Title.Size = New System.Drawing.Size(78, 38)
        Me.lblG01Title.TabIndex = 37
        Me.lblG01Title.Text = "NA"
        Me.lblG01Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblE08
        '
        Me.lblE08.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblE08.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblE08.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblE08.Location = New System.Drawing.Point(689, 255)
        Me.lblE08.Name = "lblE08"
        Me.lblE08.Size = New System.Drawing.Size(78, 69)
        Me.lblE08.TabIndex = 36
        Me.lblE08.Text = "0"
        Me.lblE08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE08.Visible = False
        '
        'lblE07
        '
        Me.lblE07.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblE07.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblE07.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblE07.Location = New System.Drawing.Point(594, 255)
        Me.lblE07.Name = "lblE07"
        Me.lblE07.Size = New System.Drawing.Size(78, 69)
        Me.lblE07.TabIndex = 35
        Me.lblE07.Text = "0"
        Me.lblE07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE07.Visible = False
        '
        'lblE06
        '
        Me.lblE06.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblE06.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblE06.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblE06.Location = New System.Drawing.Point(500, 255)
        Me.lblE06.Name = "lblE06"
        Me.lblE06.Size = New System.Drawing.Size(78, 69)
        Me.lblE06.TabIndex = 34
        Me.lblE06.Text = "0"
        Me.lblE06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE06.Visible = False
        '
        'lblE05
        '
        Me.lblE05.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblE05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblE05.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblE05.Location = New System.Drawing.Point(405, 255)
        Me.lblE05.Name = "lblE05"
        Me.lblE05.Size = New System.Drawing.Size(78, 69)
        Me.lblE05.TabIndex = 33
        Me.lblE05.Text = "0"
        Me.lblE05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE05.Visible = False
        '
        'lblE04
        '
        Me.lblE04.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblE04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblE04.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblE04.Location = New System.Drawing.Point(312, 255)
        Me.lblE04.Name = "lblE04"
        Me.lblE04.Size = New System.Drawing.Size(78, 69)
        Me.lblE04.TabIndex = 32
        Me.lblE04.Text = "0"
        Me.lblE04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE04.Visible = False
        '
        'lblE03
        '
        Me.lblE03.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblE03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblE03.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblE03.Location = New System.Drawing.Point(217, 255)
        Me.lblE03.Name = "lblE03"
        Me.lblE03.Size = New System.Drawing.Size(78, 69)
        Me.lblE03.TabIndex = 31
        Me.lblE03.Text = "0"
        Me.lblE03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE03.Visible = False
        '
        'lblE02
        '
        Me.lblE02.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblE02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblE02.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblE02.Location = New System.Drawing.Point(120, 255)
        Me.lblE02.Name = "lblE02"
        Me.lblE02.Size = New System.Drawing.Size(78, 69)
        Me.lblE02.TabIndex = 30
        Me.lblE02.Text = "0"
        Me.lblE02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE02.Visible = False
        '
        'lblE01
        '
        Me.lblE01.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblE01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblE01.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblE01.Location = New System.Drawing.Point(25, 255)
        Me.lblE01.Name = "lblE01"
        Me.lblE01.Size = New System.Drawing.Size(78, 69)
        Me.lblE01.TabIndex = 29
        Me.lblE01.Text = "0"
        Me.lblE01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblE01.Visible = False
        '
        'linE08
        '
        Me.linE08.BackColor = System.Drawing.SystemColors.ControlText
        Me.linE08.Location = New System.Drawing.Point(722, 215)
        Me.linE08.Name = "linE08"
        Me.linE08.Size = New System.Drawing.Size(10, 40)
        Me.linE08.TabIndex = 28
        Me.linE08.Visible = False
        '
        'linE07
        '
        Me.linE07.BackColor = System.Drawing.SystemColors.ControlText
        Me.linE07.Location = New System.Drawing.Point(627, 215)
        Me.linE07.Name = "linE07"
        Me.linE07.Size = New System.Drawing.Size(10, 40)
        Me.linE07.TabIndex = 27
        Me.linE07.Visible = False
        '
        'linE06
        '
        Me.linE06.BackColor = System.Drawing.SystemColors.ControlText
        Me.linE06.Location = New System.Drawing.Point(534, 215)
        Me.linE06.Name = "linE06"
        Me.linE06.Size = New System.Drawing.Size(10, 40)
        Me.linE06.TabIndex = 26
        Me.linE06.Visible = False
        '
        'linE05
        '
        Me.linE05.BackColor = System.Drawing.SystemColors.ControlText
        Me.linE05.Location = New System.Drawing.Point(441, 215)
        Me.linE05.Name = "linE05"
        Me.linE05.Size = New System.Drawing.Size(10, 40)
        Me.linE05.TabIndex = 25
        Me.linE05.Visible = False
        '
        'linE04
        '
        Me.linE04.BackColor = System.Drawing.SystemColors.ControlText
        Me.linE04.Location = New System.Drawing.Point(349, 215)
        Me.linE04.Name = "linE04"
        Me.linE04.Size = New System.Drawing.Size(10, 40)
        Me.linE04.TabIndex = 24
        Me.linE04.Visible = False
        '
        'linE03
        '
        Me.linE03.BackColor = System.Drawing.SystemColors.ControlText
        Me.linE03.Controls.Add(Me.Panel13)
        Me.linE03.Location = New System.Drawing.Point(250, 215)
        Me.linE03.Name = "linE03"
        Me.linE03.Size = New System.Drawing.Size(10, 40)
        Me.linE03.TabIndex = 23
        Me.linE03.Visible = False
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.SystemColors.ControlText
        Me.Panel13.Location = New System.Drawing.Point(-317, 9)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(10, 40)
        Me.Panel13.TabIndex = 19
        '
        'linE02
        '
        Me.linE02.BackColor = System.Drawing.SystemColors.ControlText
        Me.linE02.Controls.Add(Me.Panel5)
        Me.linE02.Controls.Add(Me.Panel9)
        Me.linE02.Controls.Add(Me.Panel10)
        Me.linE02.Location = New System.Drawing.Point(149, 215)
        Me.linE02.Name = "linE02"
        Me.linE02.Size = New System.Drawing.Size(10, 40)
        Me.linE02.TabIndex = 22
        Me.linE02.Visible = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.SystemColors.ControlText
        Me.Panel5.Location = New System.Drawing.Point(-125, 9)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(10, 40)
        Me.Panel5.TabIndex = 21
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.SystemColors.ControlText
        Me.Panel9.Location = New System.Drawing.Point(-222, 9)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(10, 40)
        Me.Panel9.TabIndex = 20
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.SystemColors.ControlText
        Me.Panel10.Location = New System.Drawing.Point(-317, 9)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(10, 40)
        Me.Panel10.TabIndex = 19
        '
        'linE01
        '
        Me.linE01.BackColor = System.Drawing.SystemColors.ControlText
        Me.linE01.Controls.Add(Me.Panel2)
        Me.linE01.Controls.Add(Me.Panel3)
        Me.linE01.Controls.Add(Me.Panel4)
        Me.linE01.Location = New System.Drawing.Point(58, 215)
        Me.linE01.Name = "linE01"
        Me.linE01.Size = New System.Drawing.Size(10, 40)
        Me.linE01.TabIndex = 19
        Me.linE01.Visible = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ControlText
        Me.Panel2.Location = New System.Drawing.Point(-125, 9)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(10, 40)
        Me.Panel2.TabIndex = 21
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.ControlText
        Me.Panel3.Location = New System.Drawing.Point(-222, 9)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(10, 40)
        Me.Panel3.TabIndex = 20
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.ControlText
        Me.Panel4.Location = New System.Drawing.Point(-317, 9)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(10, 40)
        Me.Panel4.TabIndex = 19
        '
        'linG08
        '
        Me.linG08.BackColor = System.Drawing.SystemColors.ControlText
        Me.linG08.Location = New System.Drawing.Point(722, 166)
        Me.linG08.Name = "linG08"
        Me.linG08.Size = New System.Drawing.Size(10, 40)
        Me.linG08.TabIndex = 18
        '
        'lblG08
        '
        Me.lblG08.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblG08.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblG08.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblG08.Location = New System.Drawing.Point(689, 97)
        Me.lblG08.Name = "lblG08"
        Me.lblG08.Size = New System.Drawing.Size(78, 69)
        Me.lblG08.TabIndex = 17
        Me.lblG08.Text = "0"
        Me.lblG08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'linG07
        '
        Me.linG07.BackColor = System.Drawing.SystemColors.ControlText
        Me.linG07.Location = New System.Drawing.Point(627, 166)
        Me.linG07.Name = "linG07"
        Me.linG07.Size = New System.Drawing.Size(10, 40)
        Me.linG07.TabIndex = 16
        '
        'lblG07
        '
        Me.lblG07.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblG07.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblG07.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblG07.Location = New System.Drawing.Point(594, 97)
        Me.lblG07.Name = "lblG07"
        Me.lblG07.Size = New System.Drawing.Size(78, 69)
        Me.lblG07.TabIndex = 15
        Me.lblG07.Text = "0"
        Me.lblG07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'linG06
        '
        Me.linG06.BackColor = System.Drawing.SystemColors.ControlText
        Me.linG06.Location = New System.Drawing.Point(534, 166)
        Me.linG06.Name = "linG06"
        Me.linG06.Size = New System.Drawing.Size(10, 40)
        Me.linG06.TabIndex = 14
        '
        'lblG06
        '
        Me.lblG06.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblG06.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblG06.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblG06.Location = New System.Drawing.Point(500, 97)
        Me.lblG06.Name = "lblG06"
        Me.lblG06.Size = New System.Drawing.Size(78, 69)
        Me.lblG06.TabIndex = 13
        Me.lblG06.Text = "0"
        Me.lblG06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'linG05
        '
        Me.linG05.BackColor = System.Drawing.SystemColors.ControlText
        Me.linG05.Location = New System.Drawing.Point(441, 166)
        Me.linG05.Name = "linG05"
        Me.linG05.Size = New System.Drawing.Size(10, 40)
        Me.linG05.TabIndex = 12
        '
        'lblG05
        '
        Me.lblG05.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblG05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblG05.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblG05.Location = New System.Drawing.Point(405, 97)
        Me.lblG05.Name = "lblG05"
        Me.lblG05.Size = New System.Drawing.Size(78, 69)
        Me.lblG05.TabIndex = 11
        Me.lblG05.Text = "0"
        Me.lblG05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'linG04
        '
        Me.linG04.BackColor = System.Drawing.SystemColors.ControlText
        Me.linG04.Location = New System.Drawing.Point(349, 166)
        Me.linG04.Name = "linG04"
        Me.linG04.Size = New System.Drawing.Size(10, 40)
        Me.linG04.TabIndex = 10
        '
        'lblG04
        '
        Me.lblG04.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblG04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblG04.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblG04.Location = New System.Drawing.Point(312, 97)
        Me.lblG04.Name = "lblG04"
        Me.lblG04.Size = New System.Drawing.Size(78, 69)
        Me.lblG04.TabIndex = 9
        Me.lblG04.Text = "0"
        Me.lblG04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'linG03
        '
        Me.linG03.BackColor = System.Drawing.SystemColors.ControlText
        Me.linG03.Location = New System.Drawing.Point(250, 166)
        Me.linG03.Name = "linG03"
        Me.linG03.Size = New System.Drawing.Size(10, 40)
        Me.linG03.TabIndex = 8
        '
        'lblG03
        '
        Me.lblG03.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblG03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblG03.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblG03.Location = New System.Drawing.Point(217, 97)
        Me.lblG03.Name = "lblG03"
        Me.lblG03.Size = New System.Drawing.Size(78, 69)
        Me.lblG03.TabIndex = 7
        Me.lblG03.Text = "0"
        Me.lblG03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'linG02
        '
        Me.linG02.BackColor = System.Drawing.SystemColors.ControlText
        Me.linG02.Location = New System.Drawing.Point(149, 166)
        Me.linG02.Name = "linG02"
        Me.linG02.Size = New System.Drawing.Size(10, 40)
        Me.linG02.TabIndex = 6
        '
        'lblG02
        '
        Me.lblG02.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblG02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblG02.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblG02.Location = New System.Drawing.Point(120, 97)
        Me.lblG02.Name = "lblG02"
        Me.lblG02.Size = New System.Drawing.Size(78, 69)
        Me.lblG02.TabIndex = 5
        Me.lblG02.Text = "0"
        Me.lblG02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'linG01
        '
        Me.linG01.BackColor = System.Drawing.SystemColors.ControlText
        Me.linG01.Controls.Add(Me.Panel6)
        Me.linG01.Controls.Add(Me.Panel7)
        Me.linG01.Controls.Add(Me.Panel8)
        Me.linG01.Location = New System.Drawing.Point(58, 166)
        Me.linG01.Name = "linG01"
        Me.linG01.Size = New System.Drawing.Size(10, 40)
        Me.linG01.TabIndex = 4
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.ControlText
        Me.Panel6.Location = New System.Drawing.Point(-125, 9)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(10, 40)
        Me.Panel6.TabIndex = 21
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.SystemColors.ControlText
        Me.Panel7.Location = New System.Drawing.Point(-222, 9)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(10, 40)
        Me.Panel7.TabIndex = 20
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.SystemColors.ControlText
        Me.Panel8.Location = New System.Drawing.Point(-317, 9)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(10, 40)
        Me.Panel8.TabIndex = 19
        '
        'lblG01
        '
        Me.lblG01.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblG01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblG01.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblG01.Location = New System.Drawing.Point(25, 97)
        Me.lblG01.Name = "lblG01"
        Me.lblG01.Size = New System.Drawing.Size(78, 69)
        Me.lblG01.TabIndex = 2
        Me.lblG01.Text = "0"
        Me.lblG01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.flxGrid4)
        Me.TabPage4.Controls.Add(Me.butGetLocationStatusData)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1266, 413)
        Me.TabPage4.TabIndex = 5
        Me.TabPage4.Text = "Location Status"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'flxGrid4
        '
        Me.flxGrid4.Location = New System.Drawing.Point(15, 80)
        Me.flxGrid4.Name = "flxGrid4"
        Me.flxGrid4.OcxState = CType(resources.GetObject("flxGrid4.OcxState"), System.Windows.Forms.AxHost.State)
        Me.flxGrid4.Size = New System.Drawing.Size(549, 231)
        Me.flxGrid4.TabIndex = 58
        '
        'butGetLocationStatusData
        '
        Me.butGetLocationStatusData.Location = New System.Drawing.Point(15, 24)
        Me.butGetLocationStatusData.Name = "butGetLocationStatusData"
        Me.butGetLocationStatusData.Size = New System.Drawing.Size(84, 34)
        Me.butGetLocationStatusData.TabIndex = 57
        Me.butGetLocationStatusData.Text = "Get Data"
        Me.butGetLocationStatusData.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.flxGrid5)
        Me.TabPage5.Controls.Add(Me.butGetIgnore_ErrorData)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1266, 413)
        Me.TabPage5.TabIndex = 6
        Me.TabPage5.Text = "Ignore Error"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'flxGrid5
        '
        Me.flxGrid5.Location = New System.Drawing.Point(15, 80)
        Me.flxGrid5.Name = "flxGrid5"
        Me.flxGrid5.OcxState = CType(resources.GetObject("flxGrid5.OcxState"), System.Windows.Forms.AxHost.State)
        Me.flxGrid5.Size = New System.Drawing.Size(560, 275)
        Me.flxGrid5.TabIndex = 59
        '
        'butGetIgnore_ErrorData
        '
        Me.butGetIgnore_ErrorData.Location = New System.Drawing.Point(15, 24)
        Me.butGetIgnore_ErrorData.Name = "butGetIgnore_ErrorData"
        Me.butGetIgnore_ErrorData.Size = New System.Drawing.Size(84, 34)
        Me.butGetIgnore_ErrorData.TabIndex = 58
        Me.butGetIgnore_ErrorData.Text = "Get Data"
        Me.butGetIgnore_ErrorData.UseVisualStyleBackColor = True
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer2.Location = New System.Drawing.Point(-2, -1)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.txtLog2)
        Me.SplitContainer2.Panel1.Controls.Add(Me.Label9)
        Me.SplitContainer2.Panel1.Controls.Add(Me.chkAutoDataRefresh)
        Me.SplitContainer2.Panel1.Controls.Add(Me.butRefresh)
        Me.SplitContainer2.Panel1.Controls.Add(Me.txtLog)
        Me.SplitContainer2.Panel1.Controls.Add(Me.chkAutoRefresh)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.picWorking)
        Me.SplitContainer2.Size = New System.Drawing.Size(1245, 180)
        Me.SplitContainer2.SplitterDistance = 1121
        Me.SplitContainer2.TabIndex = 62
        '
        'txtLog2
        '
        Me.txtLog2.AcceptsTab = True
        Me.txtLog2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtLog2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtLog2.Font = New System.Drawing.Font("r_ansi", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLog2.Location = New System.Drawing.Point(643, 3)
        Me.txtLog2.Name = "txtLog2"
        Me.txtLog2.Size = New System.Drawing.Size(471, 167)
        Me.txtLog2.TabIndex = 70
        Me.txtLog2.Text = ""
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(3, 53)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 13)
        Me.Label9.TabIndex = 69
        Me.Label9.Text = "Auto Refresh"
        '
        'chkAutoDataRefresh
        '
        Me.chkAutoDataRefresh.AutoSize = True
        Me.chkAutoDataRefresh.Location = New System.Drawing.Point(8, 93)
        Me.chkAutoDataRefresh.Name = "chkAutoDataRefresh"
        Me.chkAutoDataRefresh.Size = New System.Drawing.Size(49, 17)
        Me.chkAutoDataRefresh.TabIndex = 68
        Me.chkAutoDataRefresh.Text = "Data"
        Me.chkAutoDataRefresh.UseVisualStyleBackColor = True
        Me.chkAutoDataRefresh.Visible = False
        '
        'butRefresh
        '
        Me.butRefresh.Location = New System.Drawing.Point(3, 3)
        Me.butRefresh.Name = "butRefresh"
        Me.butRefresh.Size = New System.Drawing.Size(57, 45)
        Me.butRefresh.TabIndex = 38
        Me.butRefresh.Text = "Refresh Log"
        Me.butRefresh.UseVisualStyleBackColor = True
        '
        'txtLog
        '
        Me.txtLog.AcceptsTab = True
        Me.txtLog.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtLog.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtLog.Font = New System.Drawing.Font("r_ansi", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLog.Location = New System.Drawing.Point(72, 3)
        Me.txtLog.Name = "txtLog"
        Me.txtLog.Size = New System.Drawing.Size(565, 167)
        Me.txtLog.TabIndex = 19
        Me.txtLog.Text = ""
        '
        'chkAutoRefresh
        '
        Me.chkAutoRefresh.AutoSize = True
        Me.chkAutoRefresh.Location = New System.Drawing.Point(8, 70)
        Me.chkAutoRefresh.Name = "chkAutoRefresh"
        Me.chkAutoRefresh.Size = New System.Drawing.Size(44, 17)
        Me.chkAutoRefresh.TabIndex = 61
        Me.chkAutoRefresh.Text = "Log"
        Me.chkAutoRefresh.UseVisualStyleBackColor = True
        '
        'picWorking
        '
        Me.picWorking.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.picWorking.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picWorking.Controls.Add(Me.lblProgStatus)
        Me.picWorking.Controls.Add(Me.lblWorking)
        Me.picWorking.Cursor = System.Windows.Forms.Cursors.Default
        Me.picWorking.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.picWorking.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picWorking.Location = New System.Drawing.Point(3, 3)
        Me.picWorking.Name = "picWorking"
        Me.picWorking.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.picWorking.Size = New System.Drawing.Size(127, 193)
        Me.picWorking.TabIndex = 3
        Me.picWorking.TabStop = True
        Me.picWorking.Visible = False
        '
        'lblProgStatus
        '
        Me.lblProgStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblProgStatus.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblProgStatus.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProgStatus.ForeColor = System.Drawing.Color.White
        Me.lblProgStatus.Location = New System.Drawing.Point(6, 32)
        Me.lblProgStatus.Name = "lblProgStatus"
        Me.lblProgStatus.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblProgStatus.Size = New System.Drawing.Size(110, 133)
        Me.lblProgStatus.TabIndex = 11
        Me.lblProgStatus.Text = "..."
        Me.lblProgStatus.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblWorking
        '
        Me.lblWorking.BackColor = System.Drawing.Color.Transparent
        Me.lblWorking.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblWorking.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWorking.ForeColor = System.Drawing.Color.White
        Me.lblWorking.Location = New System.Drawing.Point(13, 8)
        Me.lblWorking.Name = "lblWorking"
        Me.lblWorking.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblWorking.Size = New System.Drawing.Size(100, 24)
        Me.lblWorking.TabIndex = 4
        Me.lblWorking.Text = "Working..."
        Me.lblWorking.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'tmrHeartbeat
        '
        Me.tmrHeartbeat.Enabled = True
        Me.tmrHeartbeat.Interval = 60000
        '
        'SocketListeningPortsToolStripMenuItem
        '
        Me.SocketListeningPortsToolStripMenuItem.Name = "SocketListeningPortsToolStripMenuItem"
        Me.SocketListeningPortsToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.SocketListeningPortsToolStripMenuItem.Text = "Socket Listening Ports"
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1272, 676)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "RAID"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.flxGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.grpCartonWeighing.ResumeLayout(False)
        Me.grpCartonWeighing.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.grpPickControl.ResumeLayout(False)
        Me.grpPickControl.PerformLayout()
        Me.grpCartonControl.ResumeLayout(False)
        CType(Me.flxGrid3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.flxGrid2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.linE03.ResumeLayout(False)
        Me.linE02.ResumeLayout(False)
        Me.linE01.ResumeLayout(False)
        Me.linG01.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        CType(Me.flxGrid4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        CType(Me.flxGrid5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.PerformLayout()
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.picWorking.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtLog As System.Windows.Forms.RichTextBox
    Friend WithEvents tmrRefreshLog As System.Windows.Forms.Timer
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ConfigurationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MainToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteOldLogsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents butRefresh As System.Windows.Forms.Button
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SendXMLFromFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SendHeartbeatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServiceStepsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents chkAutoRefresh As System.Windows.Forms.CheckBox
    Friend WithEvents tmrBlink As System.Windows.Forms.Timer
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabelRefresh As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents lblWait As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents SocketCommunicationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents chkAutoDataRefresh As System.Windows.Forms.CheckBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents tmrReplenScan As System.Windows.Forms.Timer
    Public WithEvents picWorking As System.Windows.Forms.Panel
    Public WithEvents lblProgStatus As System.Windows.Forms.Label
    Public WithEvents lblWorking As System.Windows.Forms.Label
    Friend WithEvents flxGrid1 As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents cmdRefreshReplen As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdReplenAdvance As System.Windows.Forms.Button
    Friend WithEvents cmdReplenSelectAll As System.Windows.Forms.Button
    Friend WithEvents cmdReplenDeSelectAll As System.Windows.Forms.Button
    Friend WithEvents ReplenishmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteEmulatorDBReplenDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnReplenAutoScanOff As System.Windows.Forms.Button
    Friend WithEvents btnReplenAutoScanOn As System.Windows.Forms.Button
    Friend WithEvents butGetRepackWaveData As System.Windows.Forms.Button
    Friend WithEvents flxGrid2 As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents PickingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents grpCartonControl As System.Windows.Forms.GroupBox
    Friend WithEvents cmdCartonAdvance As System.Windows.Forms.Button
    Friend WithEvents cmdCartonSelectAll As System.Windows.Forms.Button
    Friend WithEvents cmdCartonDeSelectAll As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents linG08 As System.Windows.Forms.Panel
    Friend WithEvents lblG08 As System.Windows.Forms.Label
    Friend WithEvents linG07 As System.Windows.Forms.Panel
    Friend WithEvents lblG07 As System.Windows.Forms.Label
    Friend WithEvents linG06 As System.Windows.Forms.Panel
    Friend WithEvents lblG06 As System.Windows.Forms.Label
    Friend WithEvents linG05 As System.Windows.Forms.Panel
    Friend WithEvents lblG05 As System.Windows.Forms.Label
    Friend WithEvents linG04 As System.Windows.Forms.Panel
    Friend WithEvents lblG04 As System.Windows.Forms.Label
    Friend WithEvents linG03 As System.Windows.Forms.Panel
    Friend WithEvents lblG03 As System.Windows.Forms.Label
    Friend WithEvents linG02 As System.Windows.Forms.Panel
    Friend WithEvents lblG02 As System.Windows.Forms.Label
    Friend WithEvents linG01 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents linMain As System.Windows.Forms.Panel
    Friend WithEvents lblG01 As System.Windows.Forms.Label
    Friend WithEvents linE08 As System.Windows.Forms.Panel
    Friend WithEvents linE07 As System.Windows.Forms.Panel
    Friend WithEvents linE06 As System.Windows.Forms.Panel
    Friend WithEvents linE05 As System.Windows.Forms.Panel
    Friend WithEvents linE04 As System.Windows.Forms.Panel
    Friend WithEvents linE03 As System.Windows.Forms.Panel
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents linE02 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents linE01 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents lblE08 As System.Windows.Forms.Label
    Friend WithEvents lblE07 As System.Windows.Forms.Label
    Friend WithEvents lblE06 As System.Windows.Forms.Label
    Friend WithEvents lblE05 As System.Windows.Forms.Label
    Friend WithEvents lblE04 As System.Windows.Forms.Label
    Friend WithEvents lblE03 As System.Windows.Forms.Label
    Friend WithEvents lblE02 As System.Windows.Forms.Label
    Friend WithEvents lblE01 As System.Windows.Forms.Label
    Friend WithEvents lblG02Title As System.Windows.Forms.Label
    Friend WithEvents lblG01Title As System.Windows.Forms.Label
    Friend WithEvents lblG08Title As System.Windows.Forms.Label
    Friend WithEvents lblG07Title As System.Windows.Forms.Label
    Friend WithEvents lblG06Title As System.Windows.Forms.Label
    Friend WithEvents lblG05Title As System.Windows.Forms.Label
    Friend WithEvents lblG04Title As System.Windows.Forms.Label
    Friend WithEvents lblG03Title As System.Windows.Forms.Label
    Friend WithEvents lblE08Title As System.Windows.Forms.Label
    Friend WithEvents lblE07Title As System.Windows.Forms.Label
    Friend WithEvents lblE06Title As System.Windows.Forms.Label
    Friend WithEvents lblE05Title As System.Windows.Forms.Label
    Friend WithEvents lblE04Title As System.Windows.Forms.Label
    Friend WithEvents lblE03Title As System.Windows.Forms.Label
    Friend WithEvents lblE02Title As System.Windows.Forms.Label
    Friend WithEvents lblE01Title As System.Windows.Forms.Label
    Friend WithEvents butGetGraphicalData As System.Windows.Forms.Button
    Friend WithEvents cmdCartonAdvanceError As System.Windows.Forms.Button
    Friend WithEvents lblE09Title As System.Windows.Forms.Label
    Friend WithEvents lblG09Title As System.Windows.Forms.Label
    Friend WithEvents lblE09 As System.Windows.Forms.Label
    Friend WithEvents linE09 As System.Windows.Forms.Panel
    Friend WithEvents linG09 As System.Windows.Forms.Panel
    Friend WithEvents lblG09 As System.Windows.Forms.Label
    Friend WithEvents lblE10Title As System.Windows.Forms.Label
    Friend WithEvents lblG10Title As System.Windows.Forms.Label
    Friend WithEvents lblE10 As System.Windows.Forms.Label
    Friend WithEvents linE10 As System.Windows.Forms.Panel
    Friend WithEvents linG10 As System.Windows.Forms.Panel
    Friend WithEvents lblG10 As System.Windows.Forms.Label
    Friend WithEvents flxGrid3 As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents grpPickControl As System.Windows.Forms.GroupBox
    Friend WithEvents butPBLPick As System.Windows.Forms.Button
    Friend WithEvents butPickSelectAll As System.Windows.Forms.Button
    Friend WithEvents butPickDeSelectAll As System.Windows.Forms.Button
    Friend WithEvents txtDelayPick As System.Windows.Forms.TextBox
    Friend WithEvents chkDelayPick As System.Windows.Forms.CheckBox
    Friend WithEvents tmrPicking As System.Windows.Forms.Timer
    Friend WithEvents btnCartonAutoScanOff As System.Windows.Forms.Button
    Friend WithEvents btnCartonAutoScanOn As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents DeleteEmulatorPBLDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents XMLEditorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLblConnections As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents butMoveErrorsToLastStep As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents DeleteEmulatorDBLocationStatusDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents butGetLocationStatusData As System.Windows.Forms.Button
    Friend WithEvents flxGrid4 As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents SearchLogToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PromptForUserConfirmationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents tmrHeartbeat As System.Windows.Forms.Timer
    Friend WithEvents SendHeartbeatAutomaticallyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabelHeartBeatOn As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents butGetIgnore_ErrorData As System.Windows.Forms.Button
    Friend WithEvents flxGrid5 As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents DeleteEmulatorDBIgnoreErrorDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents grpCartonWeighing As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtCartonWeight As System.Windows.Forms.TextBox
    Friend WithEvents txtLog2 As System.Windows.Forms.RichTextBox
    Friend WithEvents SocketListeningPortsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
