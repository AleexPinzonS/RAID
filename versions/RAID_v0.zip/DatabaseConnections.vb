Option Strict On
Option Explicit On
Public NotInheritable Class DatabaseConnections


    Public Function ConnectToDB(ByVal UserName As String, ByVal Password As String) As Integer
        '* If successful, return 0, if error, return -1
        '*
        '* Global Variables Referenced:
        '*       DBCon1
        '*       dbrec1
        '*

        On Error GoTo DBConnectError
        '
        'Define ADO Objects:
        DBCON1 = New ADODB.Connection
        dbrec1 = New ADODB.Recordset

        'Open The connection to Oracle:

        Dim TNS_INFO As String

        TNS_INFO = "(DESCRIPTION=" & _
                           "(ADDRESS_LIST=" & _
                           "(ADDRESS=(PROTOCOL=TCP)" & _
                           "(HOST=" & DBServer & ")" & _
                           "(PORT=1521)))" & _
                           "(CONNECT_DATA=(SID=" & DBSid & ")" & _
                           "(SERVER=DEDICATED)))"

        DBCON1.Open("Provider=MSDAORA.1;" & _
                           "Data Source=" & TNS_INFO & ";" & _
                           "user id=" & UserName & ";" & _
                           "password=" & Password)


        'Define the recordset objects:
        dbrec1 = New ADODB.Recordset

        'Set Return Code:
        ConnectToDB = 0
        '
        Exit Function
        '
DBConnectError:

        '    MsgBox "Error encountered when connecting to database:  " + Err.Description, , _
        '"Database Connection Error"

        ConnectToDB = -1

    End Function

    Public Function ConnectToDB2(ByVal UserName As String, ByVal Password As String) As Integer
        '* If successful, return 0, if error, return -1
        '*
        '* Global Variables Referenced:
        '*       DBCon1
        '*       dbrec1
        '*

        On Error GoTo DBConnectError
        '
        'Define ADO Objects:
        DBCON2 = New ADODB.Connection
        dbrec2 = New ADODB.Recordset

        'Open The connection to Oracle:

        Dim TNS_INFO As String

        TNS_INFO = "(DESCRIPTION=" & _
                           "(ADDRESS_LIST=" & _
                           "(ADDRESS=(PROTOCOL=TCP)" & _
                           "(HOST=" & DBServer & ")" & _
                           "(PORT=1521)))" & _
                           "(CONNECT_DATA=(SID=" & DBSid & ")" & _
                           "(SERVER=DEDICATED)))"

        DBCON1.Open("Provider=MSDAORA.1;" & _
                           "Data Source=" & TNS_INFO & ";" & _
                           "user id=" & UserName & ";" & _
                           "password=" & Password)


        'Define the recordset objects:
        dbrec2 = New ADODB.Recordset

        'Set Return Code:
        ConnectToDB2 = 0
        '
        Exit Function
        '
DBConnectError:

        '    MsgBox "Error encountered when connecting to database:  " + Err.Description, , _
        '"Database Connection Error"

        ConnectToDB2 = -1

    End Function



    Public Sub DisplayDatabaseConnectionError(ByVal strDB As String)
        MsgBox("Error encountered when connecting to " & strDB & " Database  " & vbCrLf & vbCrLf & Err.Description, , "Database Connection Error")
    End Sub

    Public Function ConnectToAccessDB(ByVal strCompletePathAndFileName As String) As Integer
        '* If successful, return 0, if error, return -1
        '*
        '* Global Variables Referenced:
        '*       DBConAccess
        '*       dbRecAccess
        '*

        Dim strConnectString As String

        On Error GoTo DBConnectError
        '
        'Define ADO Objects:
        DBCON1 = New ADODB.Connection
        dbrec1 = New ADODB.Recordset

        strConnectString = "Provider=Microsoft.Jet.OLEDB.4.0;" & _
                      "Data Source=" & strCompletePathAndFileName & ";" & _
                      "User Id=admin;" & _
                      "Password=;"

        'Open The connection to Access:
        DBCON1.Open(strConnectString)
        'Define the recordset object:
        dbrec1 = New ADODB.Recordset


        'Set Return Code:
        ConnectToAccessDB = 0
        '
        Exit Function
        '
DBConnectError:

        '  MsgBox "Error encountered when connecting to Access database:  " + Err.Description, , _
        '           "Database Connection Error"

        ConnectToAccessDB = -1

    End Function

    
End Class